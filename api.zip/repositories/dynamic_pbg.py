from database.models import PressureBg
from schemas.pressure_bg import PressureBgScheme, PressureBgSchemeGet
from interfaces.repository import SQLAlchemyRepository


class PressureBGRepository(SQLAlchemyRepository):
    model = PressureBg
    scheme = PressureBgScheme
    scheme_get = PressureBgSchemeGet
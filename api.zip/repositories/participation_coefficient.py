from database.models import ParticipationCoefficients
from schemas.participation_coefficients import ParticipationCoefficientsScheme, ParticipationCoefficientsSchemeGet
from interfaces.repository import SQLAlchemyRepository


class ParticipationCoefficientsRepository(SQLAlchemyRepository):
    model = ParticipationCoefficients
    scheme = ParticipationCoefficientsScheme
    scheme_get = ParticipationCoefficientsSchemeGet
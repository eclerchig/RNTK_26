from database.models import CellPolygons
from schemas.cells import CellPolygonsScheme, CellPolygonsSchemeGet
from interfaces.repository import SQLAlchemyRepository


class CellPolygonsRepository(SQLAlchemyRepository):
    model = CellPolygons
    scheme = CellPolygonsScheme
    scheme_get = CellPolygonsSchemeGet
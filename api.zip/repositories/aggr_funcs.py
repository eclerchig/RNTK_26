from database.models import AggrFuncs
from schemas.charts import AggrFuncScheme, AggrFuncSchemeGet
from interfaces.repository import SQLAlchemyRepository


class AggrFuncRepository(SQLAlchemyRepository):
    model = AggrFuncs
    scheme = AggrFuncScheme
    scheme_get = AggrFuncSchemeGet
from database.models import Solids
from schemas.solids import SolidsSchemeGet, SolidsScheme
from interfaces.repository import SQLAlchemyRepository


class SolidsRepository(SQLAlchemyRepository):
    model = Solids
    scheme = SolidsScheme
    scheme_get = SolidsSchemeGet
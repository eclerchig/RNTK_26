from database.models import RecommendedInjection
from schemas.recommended_injection import RecommendedInjectionScheme, RecommendedInjectionSchemeGet
from interfaces.repository import SQLAlchemyRepository


class RecommendedInjectionRepository(SQLAlchemyRepository):
    model = RecommendedInjection
    scheme = RecommendedInjectionScheme
    scheme_get = RecommendedInjectionSchemeGet
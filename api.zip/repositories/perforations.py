from database.models import Perforations
from schemas.perforations import PerforationsScheme, PerforationsSchemeGet
from interfaces.repository import SQLAlchemyRepository


class PerforationsRepository(SQLAlchemyRepository):
    model = Perforations
    scheme = PerforationsScheme
    scheme_get = PerforationsSchemeGet
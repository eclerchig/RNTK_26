from database.models import WellsDictionary, WellNameExceptions
from schemas.wells import WellsDictionaryScheme, WellNameExceptionsScheme, WellsDictionarySchemeGet, WellNameExceptionsSchemeGet
from interfaces.repository import SQLAlchemyRepository


class WellsRepository(SQLAlchemyRepository):
    model = WellsDictionary
    scheme = WellsDictionaryScheme
    scheme_get = WellsDictionarySchemeGet


class WellNameExceptionsRepository(SQLAlchemyRepository):
    model = WellNameExceptions
    scheme = WellNameExceptionsScheme
    scheme_get = WellNameExceptionsSchemeGet
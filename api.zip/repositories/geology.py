from database.models import Geology
from schemas.geology import GeologyScheme, GeologySchemeGet
from interfaces.repository import SQLAlchemyRepository


class GeologyRepository(SQLAlchemyRepository):
    model = Geology
    scheme = GeologyScheme
    scheme_get = GeologySchemeGet
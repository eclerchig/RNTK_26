from database.models import MLModels
from schemas.models import MLModelsScheme, MLModelsSchemeGet
from interfaces.repository import SQLAlchemyRepository


class MLModelsRepository(SQLAlchemyRepository):
    model = MLModels
    scheme = MLModelsScheme
    scheme_get = MLModelsSchemeGet
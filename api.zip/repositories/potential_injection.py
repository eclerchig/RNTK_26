from database.models import PotentialInjection
from schemas.potential_injection import PotentialInjectionScheme, PotentialInjectionSchemeGet
from interfaces.repository import SQLAlchemyRepository


class PotentialInjectionRepository(SQLAlchemyRepository):
    model = PotentialInjection
    scheme = PotentialInjectionScheme
    scheme_get = PotentialInjectionSchemeGet
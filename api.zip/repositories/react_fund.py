from database.models import ReactFund
from schemas.react_fund import ReactFundScheme, ReactFundSchemeGet
from interfaces.repository import SQLAlchemyRepository


class ReactFundRepository(SQLAlchemyRepository):
    model = ReactFund
    scheme = ReactFundScheme
    scheme_get = ReactFundSchemeGet
from database.models import TargetInjection
from schemas.target_injection import TargetInjectionScheme, TargetInjectionSchemeGet
from interfaces.repository import SQLAlchemyRepository


class TargetInjectionRepository(SQLAlchemyRepository):
    model = TargetInjection
    scheme = TargetInjectionScheme
    scheme_get = TargetInjectionSchemeGet
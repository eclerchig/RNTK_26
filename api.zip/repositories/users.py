from database.models import Users
from interfaces.repository import SQLAlchemyRepository
from schemas.users import UsersScheme, UsersSchemeGet


class UsersRepository(SQLAlchemyRepository):
    model = Users
    scheme = UsersScheme
    scheme_get = UsersSchemeGet

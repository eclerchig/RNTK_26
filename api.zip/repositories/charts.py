from database.models import Charts
from schemas.charts import ChartsScheme, ChartsSchemeGet
from interfaces.repository import SQLAlchemyRepository


class ChartRepository(SQLAlchemyRepository):
    model = Charts
    scheme = ChartsScheme
    scheme_get = ChartsSchemeGet
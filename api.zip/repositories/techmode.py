from database.models import TechModes
from schemas.techmode import TechModeScheme, TechModeSchemeGet
from interfaces.repository import SQLAlchemyRepository


class TechModeRepository(SQLAlchemyRepository):
    model = TechModes
    scheme = TechModeScheme
    scheme_get = TechModeSchemeGet
from stratagies.UnitConversionStratagies import ThousandTonsToThousandCubicMetersStrategy, \
                                                ThousandTonsToCubicMetersPerDayStrategy, \
                                                ThousandCubicMetersToCubicMetersPerDayStrategy, \
                                                MillionCubicMetersToThousandCubicMetersStrategy, \
                                                MillionCubicMetersToThousandToCubicMetersPerDayStrategy
from interfaces.exception import APIException
from enum import Enum


class ValidUnits(str, Enum):
    thous_tons = 'тыс. тн'
    thous_m3 = 'тыс. м3'
    milliom_m3 = 'млн. м3'
    thous_m3_per_day = 'тыс. м3/сут'
    m3_per_day = 'м3/сут'
    number = 'шт.'
    pressure = 'атм.'

    def __str__(self):
        return self._value_

    def __repr__(self):
        return self._value_


class NotValidUnitName(APIException):
    def __init__(self, source_unit: str, new_unit: str):
        super().__init__(
            description=f"Получены в обработку не существующие единицы измерения: {[source_unit, new_unit]}. " \
                        f"Допустимые единицы измерения: {ValidUnits}",
            source="Обработчик единиц измерений",
            data={
                'source_unit': source_unit,
                'new_unit': new_unit,
                'valid_units': ValidUnits,
            })


class NotExistsConverter(APIException):
    def __init__(self, source_unit: str, new_unit: str):
        super().__init__(
            description=f"Не существует конвертора из {source_unit} в {new_unit}",
            source="Обработчик единиц измерений",
            data={
                'source_unit': source_unit,
                'new_unit': new_unit,
            })


class UnitConverterFactory:

    @staticmethod
    def get_converter(source_unit, new_unit, density):

        if not {source_unit, new_unit}.issubset([unit.value for unit in ValidUnits]):
            raise NotValidUnitName(
                source_unit=source_unit,
                new_unit=new_unit,
            )

        if source_unit == "тыс. тн" and new_unit == "тыс. м3":
            return ThousandTonsToThousandCubicMetersStrategy(density)
        elif source_unit == "тыс. тн" and new_unit == "м3/сут":
            return ThousandTonsToCubicMetersPerDayStrategy(density)
        elif source_unit == "тыс. м3" and new_unit == "м3/сут":
            return ThousandCubicMetersToCubicMetersPerDayStrategy()
        elif source_unit == "млн. м3" and new_unit == "тыс. м3":
            return MillionCubicMetersToThousandCubicMetersStrategy()
        elif source_unit == "млн. м3" and new_unit == "тыс. м3/сут":
            return MillionCubicMetersToThousandToCubicMetersPerDayStrategy()
        raise NotExistsConverter(
            source_unit=source_unit,
            new_unit=new_unit
        )
import time
from datetime import datetime
from typing import Union

from celery.contrib import rdb
from redis import Redis

from schemas.celery import UpdateInfoMeta, UpdateProgressMeta
from settings import settings


class ProgressTracker:
    def __init__(
        self,
        redis_url="redis://localhost:6379/0",
        cache_namespace="task-meta",
        expire_sec=7200,
    ):
        self._redis = Redis.from_url(redis_url, decode_responses=True)
        self._cache_namespace = cache_namespace
        self._expire_sec = expire_sec

    def update_meta(self, task_id, data: Union[UpdateInfoMeta, UpdateProgressMeta]):
        cache_key = f"{self._cache_namespace}:{task_id}"
        data = {
            **data.dict(),
            'timestamp': time.time(),
            'datetime': datetime.now().isoformat(),
        }
        for key in data:
            if not data[key] is None:
                self._redis.hset(cache_key, mapping={key: data[key]})
        self._redis.expire(cache_key, self._expire_sec)

    def get_meta(self, task_id,):
        cache_key = f"{self._cache_namespace}:{task_id}"
        return self._redis.hgetall(cache_key)

task_progress_tracker = ProgressTracker(redis_url=settings.REDIS_URL)

import pdb

from celery.contrib import rdb
from pathlib import Path
from asgiref.sync import async_to_sync

from api.celery import celery_app
from interfaces.unit_of_work import UnitOfWork
from logic.chunk_manager import chunk_storage
from schemas.celery import UpdateInfoMeta, UpdateProgressMeta
from schemas.general import SchemeGetFile, SchemeGetData

from services.OptionsStorage import optionsService
from services.wells import WellsService
from tasks.progress_tracker import task_progress_tracker

update_cache = optionsService().update_cache_on_success
uow = UnitOfWork()

@celery_app.task(bind=True)
def get_data(self, params: dict):
    params = SchemeGetData(**params)
    json_str = async_to_sync(WellsService().get_data)(uow,
                                                    result_type='json',
                                                    repository_name='wells',
                                                    name=params.well, )
    chunk_storage().parse_json_to_chunks(self.request.id, json_str)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
        )
    )

@celery_app.task(bind=True)
@update_cache(tables=['wells'])
def upload_file(self, file_path: Path):
    async_to_sync(WellsService().upload_wells_file)(uow, file_path, task_id=self.request.id)
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateProgressMeta(
            alert_msg="Загрузка данных завершена",
            current=100,
            total=100,
        )
    )

@celery_app.task(bind=True)
def get_file(self, params: dict):
    params = SchemeGetFile(**params)
    bytes_ = async_to_sync(WellsService().get_data)(uow,
                                                    result_type=params.file_type,
                                                    readable=True,
                                                    repository_name='wells',)
    chunk_storage().parse_file_to_chunks(self.request.id, bytes_)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            file_name=f"Скважина {params.well}" if params.well else "Скважины",
            file_type=params.file_type,
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
        )
    )
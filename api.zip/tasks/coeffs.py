from celery import shared_task

from api.web_socket_connection import WSConnectionManager
from interfaces.unit_of_work import IUnitOfWork
from logic.chunk_manager import chunk_storage
from schemas.participation_coefficients import DataForCalculateInputScheme
from schemas.users import UsersSchemeGet
from schemas.general import SchemeGetFile, SchemeGetData
from services.OptionsStorage import optionsService

from services.participation_coefficient import ParticipationCoefficientService as CoeffsService

manager = WSConnectionManager()

@shared_task()
def calculate_participation_coefficients(
        uow: IUnitOfWork,
        user_id: UsersSchemeGet,
        params: DataForCalculateInputScheme,):
    CoeffsService().build_participation_coeffs_df(uow, user_id, **params.dict())

@shared_task(bind=True)
async def get_participation_coefficients(
        self,
        uow: IUnitOfWork,
        user_id: UsersSchemeGet,
        params: SchemeGetData,):
    solid_id = optionsService().check_value_in_options(params.solid, 'solids')
    json = await CoeffsService().get_data(uow, result_type='json',
                                            solid_id=solid_id,
                                            user_id=user_id)
    chunk_storage().parse_json_to_chunks(json)
    # Сохранение метаданных для клиента
    self.update_state(
        meta={
            "type": "metadata",
            "total_chunks": chunk_storage().get_len_chunks(self.id),
        }
    )

@shared_task(bind=True)
async def get_participation_coefficients_file(
        self,
        uow: IUnitOfWork,
        user_id: int,
        params: SchemeGetFile):
    solid_id = optionsService().check_value_in_options(params.solid, 'solids')
    bytes_ = await CoeffsService().get_data(uow, result_type=params.file_type, readable=True,
                                            solid_id=solid_id,
                                            user_id=user_id)
    chunk_storage().parse_json_to_chunks(bytes_)
    # Сохранение метаданных для клиента
    self.update_state(
        meta={
            "type": "metadata",
            "file_name": f"Коэффициенты участия на объекте {params.solid}" if params.solid else "Коэффициенты участия",
            "total_chunks": chunk_storage().get_len_chunks(self.id),
        }
    )

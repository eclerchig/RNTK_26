import pdb

from celery.contrib import rdb
from asgiref.sync import async_to_sync

from api.celery import celery_app
from interfaces.unit_of_work import UnitOfWork
from logic.chunk_manager import chunk_storage
from schemas.celery import UpdateInfoMeta
from schemas.general import SchemeGetFile

from services.OptionsStorage import optionsService
from services.solids import SolidsService
from tasks.progress_tracker import task_progress_tracker

update_cache = optionsService().update_cache_on_success
uow = UnitOfWork()

@celery_app.task(bind=True)
def get_data(self):
    json_str = async_to_sync(SolidsService().get_data)(uow, result_type='json',)
    chunk_storage().parse_json_to_chunks(self.request.id, json_str)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
        )
    )

@celery_app.task(bind=True)
def get_file(self, params: dict):
    params = SchemeGetFile(**params)
    bytes_ = async_to_sync(SolidsService().get_data)(uow,
                                                     result_type=params.file_type,
                                                     readable=True,)
    chunk_storage().parse_file_to_chunks(self.request.id, bytes_)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            file_name="Объекты разработки",
            file_type=params.file_type,
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
        )
    )
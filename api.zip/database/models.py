from sqlalchemy import func, Boolean, Sequence, Column, Integer, String, Date, DateTime, Float, ForeignKey, Table, Index
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship

from .base import Base
from schemas.wells import WellsDictionaryScheme, WellsDictionarySchemeGet, WellNameExceptionsScheme, \
    WellNameExceptionsSchemeGet
from schemas.monitoring import ProductionMonitoringSchemeGet, WellsMonitoringSchemeGet, ProductionMonitoringScheme, \
    WellsMonitoringScheme
from schemas.inclinometry import InclinometriesSchemeGet, InclinometriesScheme
from schemas.perforations import PerforationsSchemeGet, PerforationsScheme
from schemas.react_fund import ReactFundSchemeGet, ReactFundScheme
from schemas.pressure_bg import PressureBgSchemeGet, PressureBgScheme
from schemas.techmode import TechModeSchemeGet, TechModeScheme
from schemas.participation_coefficients import ParticipationCoefficientsSchemeGet, ParticipationCoefficientsScheme
from schemas.solids import SolidsSchemeGet, SolidsScheme
from schemas.target_injection import TargetInjectionSchemeGet, TargetInjectionScheme
from schemas.potential_injection import PotentialInjectionSchemeGet, PotentialInjectionScheme
from schemas.recommended_injection import RecommendedInjectionSchemeGet, RecommendedInjectionScheme
from schemas.users import UsersScheme, UsersSchemeGet
from schemas.cells import CellsScheme, CellsSchemeGet, CellPolygonsScheme, CellPolygonsSchemeGet
from schemas.charts import ChartsSchemeGet, ChartsScheme, AggrFuncSchemeGet, AggrFuncScheme

# Таблица связи для реагирующих скважин
relations = Table('relations', Base.metadata,
    Column('injector_well_id', ForeignKey('wells_monitoring.id'), primary_key=True),
    Column('reactive_well_id', ForeignKey('wells_monitoring.id'), primary_key=True)
)


class Cells(Base):
    __tablename__ = 'cells'

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    solid_id = Column(Integer, ForeignKey('solids.id'))
    purpose_comp_coeff = Column(Float)

    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")

    def to_read_model(self) -> CellsSchemeGet:
        solid_name = self.solid.name
        return CellsSchemeGet(
            id=self.id,
            name=self.name,
            solid_id=self.solid_id,
            solid_name=solid_name,
            purpose_comp_coeff=self.purpose_comp_coeff
        )

    @staticmethod
    def get_dublicate_filter(data: CellsScheme):
        return {
            'name': data.name,
            'solid_id': data.solid_id,
        }


class CellPolygons(Base):
    __tablename__ = 'cell_polygons'

    id = Column(Integer, primary_key=True)
    cell_id = Column(Integer, ForeignKey('cells.id', ondelete='CASCADE'))
    order = Column(Integer, nullable=False)
    x = Column(Float, nullable=False)
    y = Column(Float, nullable=False)

    cell = relationship("Cells", foreign_keys=[cell_id], lazy="selectin")

    def to_read_model(self):
        cell_name = self.cell.name
        return CellPolygonsSchemeGet(
            id=self.id,
            cell_id=self.cell_id,
            cell_name=cell_name,
            order=self.order,
            x=self.x,
            y=self.y,
        )

    @staticmethod
    def get_dublicate_filter(data: CellPolygonsScheme):
        return {
            'cell_id': data.cell_id,
            'order': data.order,
            'x': data.x,
            'y': data.y,
        }


class Users(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    login = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    is_user = Column(Boolean, default=True, nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)

    def to_read_model(self) -> UsersSchemeGet:
        return UsersSchemeGet(
            id=self.id,
            login=self.login,
            password=self.password,
            is_user=self.is_user,
            is_admin=self.is_admin,
        )

    @staticmethod
    def get_dublicate_filter(data: UsersScheme):
        return {
            'login': data.login,
        }


class WellsDictionary(Base):
    __tablename__ = 'wells_dictionary'

    id = Column(Integer, Sequence(f'{__tablename__}_id_seq', start=1), primary_key=True)
    name = Column(String, index=True, nullable=False)
    pad = Column(String)
    solid = Column(String, nullable=False)
    xx = Column(Float)
    yy = Column(Float)
    zz = Column(Float)
    date_drilled = Column(Date)
    main_trunk = Column(String)
    char_work = Column(String)
    times_changed = Column(Integer)
    date_changes = Column(Date)
    drilling_status = Column(Boolean)
    number_trunk = Column(String)

    def to_read_model(self):
        solid = self.solid
        char_work = self.char_work
        number_trunk = self.number_trunk
        return WellsDictionarySchemeGet(
            id=self.id,
            name=self.name,
            pad=self.pad,
            solid=solid,
            xx=self.xx,
            yy=self.yy,
            zz=self.zz,
            date_drilled=self.date_drilled,
            main_trunk=self.main_trunk,
            char_work=char_work,
            times_changed=self.times_changed,
            date_changes=self.date_changes,
            drilling_status=self.drilling_status,
            number_trunk=number_trunk,
        )

    @staticmethod
    def get_dublicate_filter(data: WellsDictionaryScheme):
        return {
            'name': data.name,
            'times_changed': data.times_changed,
        }


class WellNameExceptions(Base):
    __tablename__ = 'well_name_exceptions'

    id = Column(Integer, primary_key=True)
    dev_name = Column(String)
    kin_name = Column(String)
    date_entry_encoding = Column(Date)
    date_end_encoding = Column(Date)

    def to_read_model(self) -> WellNameExceptionsSchemeGet:
        return WellNameExceptionsSchemeGet(
            id=self.id,
            dev_name=self.dev_name,
            kin_name=self.kin_name,
            date_entry_encoding=self.date_entry_encoding,
            date_end_encoding=self.date_end_encoding,
        )

    @staticmethod
    def get_dublicate_filter(data: WellNameExceptionsScheme):
        return {
            'dev_name': data.dev_name,
            'date_entry_encoding': data.date_entry_encoding,
        }


class Solids(Base):
    __tablename__ = 'solids'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    oil_density = Column(Float)
    condensate_density = Column(Float)
    water_density = Column(Float)
    oil_volume_coeff = Column(Float)
    water_volume_coeff = Column(Float)
    gas_volume_coeff = Column(Float)
    gas_content = Column(Float) #газосодержание

    def to_read_model(self) -> SolidsSchemeGet:
        return SolidsSchemeGet(
            id=self.id,
            name=self.name,
            oil_density=self.oil_density,
            condensate_density=self.condensate_density,
            water_density=self.water_density,
            oil_volume_coeff=self.oil_volume_coeff,
            water_volume_coeff=self.water_volume_coeff,
            gas_volume_coeff=self.gas_volume_coeff,
            gas_content=self.gas_content,
        )

    @staticmethod
    def get_dublicate_filter(data: SolidsScheme):
        return {
            'name': data.name,
        }


class Perforations(Base):
    __tablename__ = 'perforations'

    id = Column(Integer, primary_key=True)
    well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="SET NULL"))
    well_name = Column(String)
    solid_id = Column(Integer, ForeignKey('solids.id'))
    date = Column(Date)
    perforation_kind = Column(String)
    perforation_code = Column(String)
    top_interval_depth = Column(Float)
    bottom_interval_depth = Column(Float)
    number_holes = Column(Integer)
    date_open = Column(Date)
    date_close = Column(Date)
    main_trunk_name = Column(String)
    x1 = Column(Float)
    y1 = Column(Float)
    z1 = Column(Float)
    x2 = Column(Float)
    y2 = Column(Float)
    z2 = Column(Float)
    md1 = Column(Float)
    md2 = Column(Float)

    well = relationship("WellsMonitoring", back_populates="perforations", foreign_keys=[well_id], lazy="selectin")
    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")

    def to_read_model(self) -> PerforationsSchemeGet:
        solid_name = self.solid.name
        return PerforationsSchemeGet(
            id=self.id,
            well_id=self.well_id,
            well_name=self.well_name,
            solid_id=self.solid_id,
            solid_name=solid_name,
            date=self.date,
            perforation_kind=self.perforation_kind,
            perforation_code=self.perforation_code,
            top_interval_depth=self.top_interval_depth,
            bottom_interval_depth=self.bottom_interval_depth,
            number_holes=self.number_holes,
            date_open=self.date_open,
            date_close=self.date_close,
            main_trunk_name=self.main_trunk_name,
            x1=self.x1,
            y1=self.y1,
            z1=self.z1,
            x2=self.x2,
            y2=self.y2,
            z2=self.z2,
            md1=self.md1,
            md2=self.md2,
        )

    @staticmethod
    def get_dublicate_filter(data: PerforationsScheme):
        return {
            'well_name': data.well_name,
            'solid_id': data.solid_id,
            'date': data.date,
            'perforation_code': data.perforation_code,
            'perforation_kind': data.perforation_kind,
            'top_interval_depth': data.top_interval_depth,
            'bottom_interval_depth': data.bottom_interval_depth,
        }


class Inclinometries(Base):
    __tablename__ = 'inclinometries'

    id = Column(Integer, primary_key=True)
    well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="SET NULL"))
    well_name = Column(String)
    x = Column(Float)
    y = Column(Float)
    md = Column(Float)
    z = Column(Float)

    well = relationship("WellsMonitoring", back_populates="inclinometry_records", lazy="selectin")

    def to_read_model(self) -> InclinometriesSchemeGet:
        return InclinometriesSchemeGet(
            id=self.id,
            well_id=self.well_id,
            well_name=self.well_name,
            x=self.x,
            y=self.y,
            md=self.md,
            z=self.z,
        )

    @staticmethod
    def get_dublicate_filter(data: InclinometriesScheme):
        return {
            'well_name': data.well_name,
            'md': data.md,
        }


class ProductionMonitoring(Base):
    __tablename__ = 'production_monitoring'

    id = Column(Integer, primary_key=True)
    well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete='CASCADE'))
    solid_id = Column(Integer, ForeignKey('solids.id'))
    date = Column(Date)
    oil_production = Column(Float)
    liquid_production = Column(Float)
    gas_production = Column(Float)
    water_injection = Column(Float)
    reservoir_sampling = Column(Float)
    days = Column(Float)
    user_id = Column(Integer, ForeignKey('users.id'))

    well = relationship("WellsMonitoring", foreign_keys=[well_id],
                        back_populates="production_monitoring_records", lazy="selectin")
    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")

    def to_read_model(self) -> ProductionMonitoringSchemeGet:
        well_name = self.well.well_name
        solid_name = self.solid.name
        return ProductionMonitoringSchemeGet(
            id=self.id,
            well_id=self.well_id,
            well_name=well_name,
            solid_id=self.solid_id,
            solid_name=solid_name,
            date=self.date,
            oil_production=self.oil_production,
            liquid_production=self.liquid_production,
            gas_production=self.gas_production,
            water_injection=self.water_injection,
            reservoir_sampling=self.reservoir_sampling,
            days=self.days,
        )

    @staticmethod
    def get_dublicate_filter(data: ProductionMonitoringScheme):
        return {
            'well_id': data.well_id,
            'solid_id': data.solid_id,
            'date': data.date,
            'user_id': data.user_id,
        }


class WellsMonitoring(Base):
    __tablename__ = 'wells_monitoring'

    id = Column(Integer, primary_key=True)
    well_id = Column(Integer, ForeignKey('wells_dictionary.id'), nullable=True)
    well_name = Column(String)
    solid_id = Column(Integer, ForeignKey('solids.id'))
    purpose = Column(String)
    entry_date = Column(Date)
    ppd_conversion_date = Column(Date)
    user_id = Column(Integer, ForeignKey('users.id'))

    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")

    perforations = relationship("Perforations", back_populates="well",
                                primaryjoin="WellsMonitoring.id == Perforations.well_id")
    inclinometry_records = relationship("Inclinometries", back_populates="well")
    production_monitoring_records = relationship("ProductionMonitoring", back_populates="well",
                                                 cascade="all, delete-orphan")

    reactive_wells = relationship(
        "WellsMonitoring",
        secondary=relations,
        primaryjoin=id == relations.c.injector_well_id,
        secondaryjoin=id == relations.c.reactive_well_id,
        backref="injector_wells"
    )

    def to_read_model(self) -> WellsMonitoringSchemeGet:
        solid_name = self.solid.name
        purpose = self.purpose
        return WellsMonitoringSchemeGet(
            id=self.id,
            well_id=self.well_id,
            well_name=self.well_name,
            purpose=purpose,
            solid_id=self.solid_id,
            solid_name=solid_name,
            entry_date=self.entry_date,
            ppd_conversion_date=self.ppd_conversion_date,
        )

    @staticmethod
    def get_dublicate_filter(data: WellsMonitoringScheme):
        return {
            'well_name': data.well_name,
            'solid_id': data.solid_id,
            'user_id': data.user_id,
        }


class ParticipationCoefficients(Base):
    __tablename__ = 'participation_coefficients'

    id = Column(Integer, primary_key=True)
    react_fund_id = Column(Integer, ForeignKey('react_fund.id', ondelete="SET NULL"))
    around_well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="CASCADE"))
    center_well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="CASCADE"))
    center_well_purpose = Column(String)
    solid_id = Column(Integer, ForeignKey('solids.id', ondelete="CASCADE"))
    cell_id = Column(Integer, ForeignKey('cells.id', ondelete="CASCADE"), nullable=True)

    date = Column(Date)
    distance = Column(Float)
    distance_coefficient = Column(Float)
    correlation_coefficient = Column(Float)
    from_cell = Column(Boolean, default=False)
    user_id = Column(Integer, ForeignKey('users.id'))

    around_well = relationship("WellsMonitoring", foreign_keys=[around_well_id], lazy="selectin")
    center_well = relationship("WellsMonitoring", foreign_keys=[center_well_id], lazy="selectin")
    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")
    cell = relationship("Cells", foreign_keys=[cell_id], lazy="selectin")
    react_fund_record = relationship("ReactFund", lazy="selectin")

    def to_read_model(self) -> ParticipationCoefficientsSchemeGet:
        react_fund_record = self.react_fund_record.to_read_model() if self.react_fund_record else None
        around_well_record = self.around_well.to_read_model() if self.react_fund_record else None
        center_well_record = self.center_well.to_read_model()
        solid_name = self.solid.name
        cell_name = self.cell.name if self.cell else None
        center_well_purpose = self.center_well_purpose
        return ParticipationCoefficientsSchemeGet(
            id=self.id,
            react_fund_id=react_fund_record.id if react_fund_record else None,
            solid_id=self.solid_id,
            solid_name=solid_name,
            date=self.date,
            distance=self.distance,
            distance_coefficient=self.distance_coefficient,
            correlation_coefficient=self.correlation_coefficient,
            center_well_id=self.center_well_id,
            center_well=center_well_record.well_name,
            around_well_id=self.around_well_id,
            around_well=around_well_record.well_name if around_well_record else None,
            center_well_purpose=center_well_purpose,
            from_cell=self.from_cell,
            cell_id=self.cell_id,
            cell_name=cell_name
        )

    @staticmethod
    def get_dublicate_filter(data: ParticipationCoefficientsScheme):
        return {
            'center_well_id': data.center_well_id,
            'around_well_id': data.around_well_id,
            'solid_id': data.solid_id,
            'date': data.date,
            'from_cell': data.from_cell,
            'cell_id': data.cell_id,
            'user_id': data.user_id,
        }


class ReactFund(Base):
    __tablename__ = 'react_fund'

    id = Column(Integer, primary_key=True)
    around_well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="CASCADE"))
    center_well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="CASCADE"))
    solid_id = Column(Integer, ForeignKey('solids.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    for_delete = Column(Boolean, default=False)

    around_well = relationship("WellsMonitoring", foreign_keys=[around_well_id], lazy="selectin")
    center_well = relationship("WellsMonitoring", foreign_keys=[center_well_id], lazy="selectin")
    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")

    center_well_purpose = Column(String)

    __table_args__ = (Index('idx_solid_id_user_id', 'solid_id', 'user_id'),)

    def to_read_model(self) -> ReactFundSchemeGet:
        around_well = self.around_well
        center_well = self.center_well
        solid_name = self.solid.name
        center_well_purpose = self.center_well_purpose

        return ReactFundSchemeGet(
            id=self.id,
            around_well_id=self.around_well_id,
            around_well=around_well.well_name,
            center_well_id=self.center_well_id,
            center_well=center_well.well_name,
            solid_id=self.solid_id,
            solid_name=solid_name,
            center_well_purpose=center_well_purpose,
            for_delete=self.for_delete
        )

    @staticmethod
    def get_dublicate_filter(data: ReactFundScheme):
        return {
            'around_well_id': data.around_well_id,
            'center_well_id': data.center_well_id,
            'solid_id': data.solid_id,
            'center_well_purpose': data.center_well_purpose,
            'user_id': data.user_id,
            'for_delete': data.for_delete,
        }


class PressureBg(Base):
    __tablename__ = 'pressure_bg'

    id = Column(Integer, primary_key=True, index=True)
    kns = Column(String)
    pad = Column(String)
    date = Column(Date)
    pressure_bg = Column(Float)

    def to_read_model(self):
        return PressureBgSchemeGet(
            id=self.id,
            kns=self.kns,
            pad=self.pad,
            date=self.date,
            pressure_bg=self.pressure_bg,
        )

    @staticmethod
    def get_dublicate_filter(data: PressureBgScheme):
        return {
            'kns': data.kns,
            'pad': data.pad,
            'date': data.date,
        }


class TechModes(Base):
    __tablename__ = "tech_modes"

    id = Column(Integer, primary_key=True)
    well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete='SET NULL'))
    well_name = Column(String)
    pad_name = Column(String)
    solid_id = Column(Integer, ForeignKey('solids.id'))
    date = Column(Date)
    purpose = Column(String)
    q_injection = Column(Float)
    bottomhole_pressure = Column(Float)
    solid_pressure = Column(Float)
    bg_fact_pressure = Column(Float)
    wellhead_pressure = Column(Float)
    bg_forecast_pressure = Column(Float)

    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")

    def to_read_model(self):
        solid_name = self.solid.name
        return TechModeSchemeGet(
            id=self.id,
            well_id=self.well_id,
            well_name=self.well_name,
            pad_name=self.pad_name,
            solid_name=solid_name,
            solid_id=self.solid_id,
            date=self.date,
            purpose=self.purpose,
            q_injection=self.q_injection,
            bottomhole_pressure=self.bottomhole_pressure,
            solid_pressure=self.solid_pressure,
            bg_fact_pressure=self.bg_fact_pressure,
            wellhead_pressure=self.wellhead_pressure,
            bg_forecast_pressure=self.bg_forecast_pressure,
        )

    @staticmethod
    def get_dublicate_filter(data: TechModeScheme):
        return {
            'well_name': data.well_name,
            'date': data.date,
            'solid_id': data.solid_id,
            'purpose': data.purpose,
        }


class PotentialInjection(Base):
    __tablename__ = "potential_injection"

    id = Column(Integer, primary_key=True)
    well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="CASCADE"))
    well_name = Column(String)
    solid_id = Column(Integer, ForeignKey('solids.id'))
    techmode_id = Column(Integer, ForeignKey('tech_modes.id'))
    date = Column(Date)
    pickup_rate_coefficient = Column(Float)
    agrp_pressure = Column(Float)
    downhole_press_agrp = Column(Float)
    inj_agrp_potential = Column(Float)
    pressure_margin_infr = Column(Float)
    downhole_press_infr_potential = Column(Float)
    inj_infr_potential = Column(Float)
    user_id = Column(Integer, ForeignKey('users.id'))

    well = relationship("WellsMonitoring", foreign_keys=[well_id], lazy="selectin")
    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")
    tech_mode = relationship("TechModes", foreign_keys=[techmode_id], lazy="selectin")

    def to_read_model(self):
        solid_name = self.solid.name
        return PotentialInjectionSchemeGet(
            id=self.id,
            well_id=self.well_id,
            well_name=self.well_name,
            solid_id=self.solid_id,
            solid_name=solid_name,
            techmode_id=self.techmode_id,
            date=self.date,
            pickup_rate_coefficient=self.pickup_rate_coefficient,
            agrp_pressure=self.agrp_pressure,
            downhole_press_agrp=self.downhole_press_agrp,
            inj_agrp_potential=self.inj_agrp_potential,
            pressure_margin_infr=self.pressure_margin_infr,
            downhole_press_infr_potential=self.downhole_press_infr_potential,
            inj_infr_potential=self.inj_infr_potential,
        )

    @staticmethod
    def get_dublicate_filter(data: PotentialInjectionScheme):
        return {
            'well_name': data.well_name,
            'solid_id': data.solid_id,
            'date': data.date,
            'user_id': data.user_id,
        }


class TargetInjection(Base):
    __tablename__ = "target_injection"

    id = Column(Integer, primary_key=True)
    well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="CASCADE"))
    well_name = Column(String)
    solid_id = Column(Integer, ForeignKey('solids.id'))
    date = Column(Date)
    target_inj = Column(Float)
    user_id = Column(Integer, ForeignKey('users.id'))
    from_cell = Column(Boolean)
    cell_id = Column(Integer, ForeignKey('cells.id'))
    purpose = Column(String)

    well = relationship("WellsMonitoring", foreign_keys=[well_id], lazy="selectin")
    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")
    cell = relationship("Cells", foreign_keys=[cell_id], lazy="selectin")

    def to_read_model(self):
        solid_name = self.solid.name
        cell_name = self.cell.name if self.cell else None
        return TargetInjectionSchemeGet(
            id=self.id,
            well_id=self.well_id,
            well_name=self.well_name,
            solid_id=self.solid_id,
            solid_name=solid_name,
            cell_id=self.cell_id,
            cell_name=cell_name,
            date=self.date,
            target_inj=self.target_inj,
            from_cell=self.from_cell,
            purpose=self.purpose,
        )

    @staticmethod
    def get_dublicate_filter(data: TargetInjectionScheme):
        return {
            'well_id': data.well_id,
            'solid_id': data.solid_id,
            'cell_id': data.cell_id,
            'date': data.date,
            'user_id': data.user_id,
        }


class RecommendedInjection(Base):
    __tablename__ = "recommended_injection"

    id = Column(Integer, primary_key=True)
    well_id = Column(Integer, ForeignKey('wells_monitoring.id', ondelete="CASCADE"))
    solid_id = Column(Integer, ForeignKey('solids.id'))
    cell_id = Column(Integer, ForeignKey('cells.id'), nullable=True)
    date = Column(Date)
    record_target_injection_id = Column(Integer, ForeignKey('target_injection.id', ondelete="CASCADE"))
    record_potential_injection_id = Column(Integer, ForeignKey('potential_injection.id', ondelete="CASCADE"))
    techmode_id = Column(Integer, ForeignKey('tech_modes.id'))
    inj_agrp_recommended = Column(Float)
    inj_infr_recommended = Column(Float)
    user_id = Column(Integer, ForeignKey('users.id'))
    from_cell = Column(Boolean, default=False, nullable=True)

    well = relationship("WellsMonitoring", foreign_keys=[well_id], lazy="selectin")
    solid = relationship("Solids", foreign_keys=[solid_id], lazy="selectin")
    cell = relationship("Cells", foreign_keys=[cell_id], lazy="selectin")

    target_injection_rec = relationship("TargetInjection", foreign_keys=[record_target_injection_id], lazy="selectin")
    potential_injection_rec = relationship("PotentialInjection", foreign_keys=[record_potential_injection_id], lazy="selectin")
    techmode_rec = relationship("TechModes", foreign_keys=[techmode_id], lazy="selectin")

    def to_read_model(self):
        well_name = self.well.well_name
        solid_name = self.solid.name
        cell_name = self.cell.name if self.cell else None
        return RecommendedInjectionSchemeGet(
            id=self.id,
            well_id=self.well_id,
            well_name=well_name,
            solid_id=self.solid_id,
            solid_name=solid_name,
            cell_id=self.cell_id,
            cell_name=cell_name,
            date=self.date,
            record_target_injection_id=self.record_target_injection_id,
            record_potential_injection_id=self.record_potential_injection_id,
            techmode_id=self.techmode_id,
            inj_agrp_recommended=self.inj_agrp_recommended,
            inj_infr_recommended=self.inj_infr_recommended,
            from_cell=self.from_cell,
        )

    @staticmethod
    def get_dublicate_filter(data: RecommendedInjectionScheme):
        return {
            'well_id': data.well_id,
            'solid_id': data.solid_id,
            'cell_id': data.cell_id,
            'date': data.date,
            'user_id': data.user_id,
        }


class Charts(Base):
    __tablename__ = 'charts'
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True)
    data = Column(JSONB)
    datetime = Column(DateTime, server_default=func.now())
    user_id = Column(Integer, ForeignKey('users.id'))

    def to_read_model(self) -> ChartsSchemeGet:
        return ChartsSchemeGet(
            id=self.id,
            name=self.name,
            datetime=self.datetime,
            data=self.data,
            user_id=self.user_id,
        )

    @staticmethod
    def get_dublicate_filter(data: ChartsScheme):
        return {
            'name': data.name,
            'user_id': data.user_id,
        }


class AggrFuncs(Base):
    __tablename__ = 'aggr_funcs'
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True)
    latin_name = Column(String, unique=True)

    def to_read_model(self) -> AggrFuncSchemeGet:
        return AggrFuncSchemeGet(
            id=self.id,
            name=self.name,
            latin_name=self.latin_name,
        )

    @staticmethod
    def get_dublicate_filter(data: AggrFuncScheme):
        return {
            'latin_name': data.latin_name,
        }
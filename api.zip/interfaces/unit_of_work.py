# import pdb
# from abc import ABC, abstractmethod
# from sqlalchemy import text
# from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
#
# from database.session import async_session_maker, async_engine
# from repositories.wells import WellsRepository, WellNameExceptionsRepository
# from repositories.cells import CellsRepository
# from repositories.cell_polygons import CellPolygonsRepository
# from repositories.perforations import PerforationsRepository
# from repositories.monitoring import WellsMonitoringRepository, ProductionMonitoringRepository
# from repositories.inclinometry import InclinometryRepository
# from repositories.react_fund import ReactFundRepository
# from repositories.dynamic_pbg import PressureBGRepository
# from repositories.techmode import TechModeRepository
# from repositories.participation_coefficient import ParticipationCoefficientsRepository
# from repositories.solids import SolidsRepository
# from repositories.target_injection import TargetInjectionRepository
# from repositories.potential_injection import PotentialInjectionRepository
# from repositories.recommended_injection import RecommendedInjectionRepository
# from repositories.users import UsersRepository
# from repositories.charts import ChartRepository
# from repositories.aggr_funcs import AggrFuncRepository
#
# from settings import settings
#
#
# class IUnitOfWork(ABC):
#
#     @abstractmethod
#     def __init__(self):
#         ...
#
#     @abstractmethod
#     async def __aenter__(self):
#         ...
#
#     @abstractmethod
#     async def __aexit__(self, *args):
#         ...
#
#     @abstractmethod
#     async def commit(self):
#         ...
#
#     @abstractmethod
#     async def rollback(self):
#         ...
#
#     def set_isolation_level(self, level: str):
#         pass
#
#
# class UnitOfWork:
#     def __init__(self):
#         self.session_factory = async_session_maker
#         self.engine = async_engine
#         self.is_open = False
#
#     async def __aenter__(self):
#         self.engine = create_async_engine(settings.DATABASE_URL_POSTGRES, echo=True)
#         self.session = AsyncSession(self.engine, expire_on_commit=False)
#         self.users = UsersRepository(self.session, self.engine)
#         self.wells = WellsRepository(self.session, self.engine)
#         self.well_name_exceptions = WellNameExceptionsRepository(self.session, self.engine)
#         self.cells = CellsRepository(self.session, self.engine)
#         self.cell_polygons = CellPolygonsRepository(self.session, self.engine)
#         self.perforations = PerforationsRepository(self.session, self.engine)
#         self.inclinometries = InclinometryRepository(self.session, self.engine)
#         self.wells_monitoring = WellsMonitoringRepository(self.session, self.engine)
#         self.prod_monitoring = ProductionMonitoringRepository(self.session, self.engine)
#         self.react_fund = ReactFundRepository(self.session, self.engine)
#         self.pressure_bg = PressureBGRepository(self.session, self.engine)
#         self.techmodes = TechModeRepository(self.session, self.engine)
#         self.participation_coeffs = ParticipationCoefficientsRepository(self.session, self.engine)
#         self.solids = SolidsRepository(self.session, self.engine)
#         self.target_injections = TargetInjectionRepository(self.session, self.engine)
#         self.potential_injections = PotentialInjectionRepository(self.session, self.engine)
#         self.recommended_injections = RecommendedInjectionRepository(self.session, self.engine)
#         self.charts = ChartRepository(self.session, self.engine)
#         self.aggr_funcs = AggrFuncRepository(self.session, self.engine)
#         self.is_open = True
#
#     async def __aexit__(self, *args):
#         await self.rollback()
#         await self.session.close()
#         await self.engine.dispose()
#         self.is_open = False
#
#     async def commit(self):
#         await self.session.commit()
#         await self.engine.dispose()
#         self.is_open = False
#
#     async def rollback(self):
#         await self.session.rollback()
#         self.is_open = False
#
#     async def set_isolation_level(self, level: str):
#         await self.session.execute(
#             text(f"SET TRANSACTION ISOLATION LEVEL {level}")
#         )
#         result = await self.session.execute(text('SHOW transaction_isolation'))
#         print(result.scalar())
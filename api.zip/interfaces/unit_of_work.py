import pdb
from abc import ABC, abstractmethod
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

from database.session import async_session_maker, async_engine
from repositories.month_report import MonthReportRepository, StatisticsRepository
from repositories.geology import GeologyRepository
from repositories.calculations import CalculationsRepository
from repositories.ml_models import MLModelsRepository


class IUnitOfWork(ABC):

    @abstractmethod
    def __init__(self):
        ...

    @abstractmethod
    async def __aenter__(self):
        ...

    @abstractmethod
    async def __aexit__(self, *args):
        ...

    @abstractmethod
    async def commit(self):
        ...

    @abstractmethod
    async def rollback(self):
        ...

    def set_isolation_level(self, level: str):
        pass


class UnitOfWork:
    def __init__(self):
        self.session_factory = async_session_maker
        self.engine = async_engine
        self.is_open = False

    async def __aenter__(self):
        self.engine = create_async_engine(
            'postgresql+asyncpg://postgres:postgres@debian:5432/gtm_predictor',
            echo=True
        )
        self.session = AsyncSession(self.engine, expire_on_commit=False)

        self.month_report = MonthReportRepository(self.session, self.engine)
        self.geology = GeologyRepository(self.session, self.engine)
        self.statistics = StatisticsRepository(self.session, self.engine)
        self.calculations = CalculationsRepository(self.session, self.engine)
        self.models = MLModelsRepository(self.session, self.engine)

        self.is_open = True

    async def __aexit__(self, *args):
        await self.rollback()
        await self.session.close()
        await self.engine.dispose()
        self.is_open = False

    async def commit(self):
        await self.session.commit()
        await self.engine.dispose()
        self.is_open = False

    async def rollback(self):
        await self.session.rollback()
        self.is_open = False

    async def set_isolation_level(self, level: str):
        await self.session.execute(
            text(f"SET TRANSACTION ISOLATION LEVEL {level}")
        )
        result = await self.session.execute(text('SHOW transaction_isolation'))
        print(result.scalar())
import asyncio
import json
from abc import ABC
import pdb
from enum import Enum

import pandas as pd

from factories.UnitConverterFactory import UnitConverterFactory
from logic.decorators import service_error_handler, async_service_error_handler
from logic.utilities import dataframe_to_bytes_buffer_by_excel, dataframe_to_bytes_buffer_by_csv
from interfaces.exception import APIException


class AggregateFunctionEnum(str, Enum):
    sum = 'Сумма'
    mean = 'Среднее'
    median = 'Медиана'
    max = 'Максимум'
    min = 'Минимум'


class ServiceWorkException(APIException, ABC):
    def __init__(self, description, data=None, child_exc=None):
        data = child_exc.get_data() if child_exc and isinstance(child_exc, APIException) and data is not None else data
        user_friendly = child_exc and isinstance(child_exc, APIException)
        super().__init__(description=description, data=data, source="Слой сервиса", user_friendly=user_friendly)


class BaseDataService(ABC):
    def __init__(self, repository_name):
        self.repository_name = repository_name

    def __init_subclass__(cls, **kwargs):
        '''
        Назначает декоратор service_error_handler на каждую функцию сервиса
        :param kwargs:
        :return:
        '''
        super().__init_subclass__(**kwargs)
        for attr, value in cls.__dict__.items():
            if callable(value):
                if asyncio.iscoroutinefunction(value):
                    setattr(cls, attr, async_service_error_handler(value, cls.__name__))
                else:
                    setattr(cls, attr, service_error_handler(value, cls.__name__))

    async def get_data(self, uow, result_type='scheme', repository_name=None, readable=False,
                       config_sort=None, **filter_by):
        '''
        :param uow: UnitOfWork object
        :param result_type: может принимать значения:
                'scheme' - данные в виде схемы Pydentic,
                'dataframe' - данные в виде схемы pd.Dataframe,
                'dict' - данные в виде словаря,
                'json' - данные в формате json,
                'excel' - данные в виде байтов файла excel,
        :param repository_name: имя репозитория
                (если не задано, то берется имя репозитория по-умолчанию из self.repository_name,
                иначе берется значения из входного параметра (требуется для сервисов, использующих более 2 таблиц))
        :param readable: bool, нуобходимость переводить названия колонок на русский язык
        :param config_sort: dict, настройки сортировки колонок.
            Например, [
                ('well_name', True),
                ('entry_date', False),
            ], позволяет остортировать по возрастанию по имени скважины и по убыванию по дате.
        :param filter_by: dict, задание фильтрации данных.
            Например, { cell_name: "1.1", "solid_name": "Як 3-7" }.
            Фильтрация только на соответствие значению!
        :return:
        '''
        async with uow:
            repo = getattr(uow, repository_name if repository_name else self.repository_name)
            datas = await repo.find_all(mode='scheme', config_sort=config_sort, filter_by=filter_by)
        if result_type == 'scheme':
            return datas
        elif result_type == 'dataframe':
            return repo.schemes_to_dataframe(datas, readable=readable)
        elif result_type == 'dict':
            return [data.dict() for data in datas]
        elif result_type == 'json':
            return json.dumps([data.json() for data in datas])
        elif result_type == 'excel':
            df = repo.schemes_to_dataframe(datas, readable=readable)
            return dataframe_to_bytes_buffer_by_excel(df)
        elif result_type == 'csv':
            df: pd.DataFrame = repo.schemes_to_dataframe(datas, readable=readable)
            return dataframe_to_bytes_buffer_by_csv(df)
        else:
            raise ServiceWorkException(
                description=f"Недопустимый тип результата при получении данных о скважинах: {result_type}",
                data={
                    'result_type': result_type
                }
            )

    @staticmethod
    async def get_data_for_graph(uow, column, unit, aggr_func, filters,
                                 getter_func, source_unit, converter_params):
        data_df = await getter_func(uow, filters)

        if unit != source_unit:
            unit_converter = UnitConverterFactory().get_converter(source_unit, unit,
                                                                  **converter_params)
            data_df[column] = data_df.apply(
                lambda row: unit_converter.convert(value=row[column], days=row['days']),
                axis=1
            )

        if filters.get('cell_id') and not data_df.empty:
            data_df[column] = data_df.apply(lambda row: row[column] * row['distance_coefficient'], axis=1)

        data_df = data_df[['date', column]]

        # Использование агрегирующей функции
        if not data_df.empty:
            if aggr_func == AggregateFunctionEnum.sum:
                data_df = data_df.groupby(['date']).sum().reset_index()
            elif aggr_func == AggregateFunctionEnum.mean:
                data_df = data_df[data_df[column] != 0]
                data_df = data_df.groupby(['date']).mean().reset_index()
            elif aggr_func == AggregateFunctionEnum.median:
                data_df = data_df[data_df[column] != 0]
                data_df = data_df.groupby(['date']).median().reset_index()
            elif aggr_func == AggregateFunctionEnum.max:
                data_df = data_df.groupby(['date']).max().reset_index()
            elif aggr_func == AggregateFunctionEnum.min:
                data_df = data_df.groupby(['date']).min().reset_index()

        data_df['date'] = pd.to_datetime(data_df['date']).dt.strftime('%Y-%m-%d')
        data_df = data_df.rename(columns={column: 'value'})
        return data_df
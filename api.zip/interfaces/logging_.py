import logging
from logging.handlers import RotatingFileHandler
import pdb
from contextvars import ContextVar
from pathlib import Path
from datetime import datetime

user_id_ctx = ContextVar('user_id', default=None)
trace_id_ctx = ContextVar('trace_id', default=None)
DATE_FORMAT = "%Y-%m-%d"
LOG_DIR = 'logs'


class UserContextFilter(logging.Filter):
    def filter(self, record):
        record.user_id = str(user_id_ctx.get())
        return True


class TraceContextFilter(logging.Filter):
    def filter(self, record):
        record.trace_id = str(trace_id_ctx.get())
        return True


class UserAwareFileHandler(logging.Handler):
    def __init__(self, dir):
        super().__init__()
        self.log_dir = Path(f"{LOG_DIR}/{dir}")
        self.log_dir.mkdir(exist_ok=True)
        self.handlers_cache = {}

    def get_handler(self, user_id: str):
        if user_id not in self.handlers_cache:
            date_dir = self.log_dir / datetime.now().strftime(DATE_FORMAT)
            date_dir.mkdir(exist_ok=True)
            log_file = date_dir / f"user_{user_id}.log"
            handler = RotatingFileHandler(log_file, mode='a', maxBytes=131072, backupCount=5)
            formatter = logging.Formatter(
                datefmt='%Y-%m-%d %H:%M:%S',
                fmt="[%(asctime)s.%(msecs)03d] "
                    "User %(user_id)-3s Process %(trace_id).8s "
                    "%(module)10s:%(lineno)-3d   %(levelname)-8s - %(message)s",
            )
            handler.setFormatter(formatter)
            self.handlers_cache[user_id] = handler
        return self.handlers_cache[user_id]

    def emit(self, record: logging.LogRecord):
        user_id = getattr(record, 'user_id', 'unknown')
        handler = self.get_handler(user_id)
        handler.emit(record)


class DateFileHandler(logging.Handler):
    def __init__(self, dir_name):
        super().__init__()
        self.log_dir = Path(f"{LOG_DIR}/{dir_name}")
        self.log_dir.mkdir(exist_ok=True)

    def get_handler(self):
        log_file = self.log_dir / f"{datetime.now().strftime(DATE_FORMAT)}.log"
        handler = RotatingFileHandler(log_file, mode='a', maxBytes=131072, backupCount=5)
        formatter = logging.Formatter(
            datefmt='%Y-%m-%d %H:%M:%S',
            fmt="[%(asctime)s.%(msecs)03d] Process %(trace_id).8s "
                "%(module)20s:%(lineno)-3d %(levelname)-8s - %(message)s",
        )
        handler.setFormatter(formatter)
        return handler

    def emit(self, record: logging.LogRecord):
        handler = self.get_handler()
        handler.emit(record)


def setup_logging(name: str, level: int, filters=None, handlers=None):
    logger = logging.getLogger(name)
    logger.setLevel(level)

    for handler in logger.handlers:
        logger.removeHandler(handler)

    if filters:
        for filter in filters:
            logger.addFilter(filter)
    if handlers:
        for handler in handlers:
            logger.addHandler(handler)

    return logger


Path(LOG_DIR).mkdir(exist_ok=True)

user_logger = setup_logging('user_logger', logging.INFO,
                            filters=[UserContextFilter(), TraceContextFilter()],
                            handlers=[UserAwareFileHandler('users')])
general_logger = setup_logging('general_logger', logging.INFO,
                               filters=[TraceContextFilter()],
                               handlers=[DateFileHandler('general')])
calc_logger = setup_logging('calc_logger', logging.INFO,
                            filters=[UserContextFilter(), TraceContextFilter()],
                            handlers=[UserAwareFileHandler('calc')])


def create_logger_for_parallel_calc(name: str):
    return setup_logging(name, logging.INFO,
                         filters=[UserContextFilter(), TraceContextFilter()],
                         handlers=[UserAwareFileHandler('calc')])

#
# def update_user_id_ctx(id: int):
#     user_id_ctx.set(user)
#     calc_logger_ctx.set(calc_logger)
import pdb
import traceback
from abc import ABC, abstractmethod


class APIException(Exception, ABC):
    def __init__(self, description: str, source: str = None, data: dict = None, service=None, user_friendly=True):
        self._description = description
        self._traceback = traceback.format_exc()
        self._source = source  # ['База данных', 'Сервис', 'Репозиторий', ...]
        self.__data = data
        self._service = service
        self.__user_friendly = user_friendly

        super().__init__(self._description)

    @abstractmethod
    def __str__(self, *args):
        return self._description

    def log(self):
        return f"Сервис: {self._service if self._service else 'Not defined'}. \n" \
               f"Источник: {self._source}. \n" \
               f"Описание: {self._description}. \n" \
               f"Данные: {self.__data if self.__data else 'Not defined'}"

    def set_service(self, service: str):
        self._service = service

    def set_source(self, source: str):
        self._source = source

    @property
    def get_data(self):
        return self.__data

    @property
    def is_user_friendly(self):
        return self.__user_friendly

import pdb
from abc import ABC, abstractmethod
from typing import List
import asyncio

from sqlalchemy.exc import MultipleResultsFound
from sqlalchemy import insert, select, delete, update, text, asc, desc, and_
from sqlalchemy.ext.asyncio import AsyncSession, AsyncEngine
from pydantic.error_wrappers import ValidationError
from pydantic import BaseModel
import pandas as pd


from interfaces.exception import APIException
from exceptions.reposiroty import DublicateRowException, ValidationDataException
from logic.decorators import async_repository_error_handler, repository_error_handler


class RepositoryException(APIException):
    def __init__(self, description: str, data: dict = None, service=None):
        super().__init__(description, source="Репозиторий", data=data, service=service)

    def __str__(self):
        return super().__str__()


class AbstractRepository(ABC):

    @abstractmethod
    async def add_one(self):
        raise NotImplementedError

    @abstractmethod
    async def find_all(self, *args):
        '''
        :param filter_by:
        :return:
        объект класса model или
        вернуть None при отсутствии строк, удовлетворяющим фильтрам
        '''
        raise NotImplementedError

    @abstractmethod
    async def delete_all(self):
        raise NotImplementedError

    def __init_subclass__(cls, **kwargs):
        '''
        Назначает декоратор repository_error_handler на каждую функцию репозитория
        :param kwargs:
        :return:
        '''
        super().__init_subclass__(**kwargs)
        for attr, value in cls.__dict__.items():
            if callable(value) and attr not in ['model', 'scheme', 'scheme_get']:
                if asyncio.iscoroutinefunction(value):
                    setattr(cls, attr, async_repository_error_handler(value))
                else:
                    setattr(cls, attr, repository_error_handler(value))


class SQLAlchemyRepository(AbstractRepository):
    model = None
    scheme:BaseModel = None
    scheme_get:BaseModel = None

    def __init__(self, session: AsyncSession, engine: AsyncEngine):
        self.session = session
        self.engine = engine

    async def add_one(self, data: dict, check_dublicate=True) -> int:
        try:
            self.scheme.validate(data)
        except ValidationError as e:
            pdb.set_trace()
            raise ValidationDataException(
                data=data, model=e.model,
                loc=e.errors()[0]['loc'], msg=e.errors()[0]['msg']
            ) from e
        dublicate = None
        try:
            if check_dublicate:
                dublicate = await self.find_one(**self.model.get_dublicate_filter(self.scheme(**data)))
        except KeyError as e:
            raise DublicateRowException(data) from e
        if dublicate:
            res = await self._update(dublicate, **data)
            id = res.id
            await self.session.flush()
        else:
            statement = insert(self.model).values(**data).returning(self.model.id)
            res = await self.session.execute(statement)
            id = res.scalar_one()
        return id

    async def _update(self, orm_obj, **kwargs):
        for key, value in kwargs.items():
            try:
                setattr(orm_obj, key, value)
            except Exception as e:
                raise RepositoryException(
                    description=f'Ошибка при обновлении данных: нельзя установить атрибуту {key} значение {value}',
                    data={
                        'orm_obj': orm_obj,
                        'kwargs': kwargs,
                    }) from e
        return orm_obj

    async def update_by_filter(self, filter_by: dict, values: dict):
        '''
        Обновляет данные values согласно фильтрам filter_by
        '''
        statement = (
            update(self.model)
            .where(and_(*(getattr(self.model, key) == value for key, value in filter_by.items())))
            .values(**values)
        )
        await self.session.execute(statement)
        await self.session.flush()

    async def find_all(self, filter_by=None, config_sort=None, mode='orm_model'):
        '''
        :param mode: при 'scheme' - возвращает объект класса pydentic.BaseModel,
                     при 'orm_model' (по ум.) - возвращает объект класса sqlalchemy.ext.declarative.declarative_base
                     при 'dict' (по ум.) - возвращает словарь, сгенерированный из pydentic.BaseModel
        :param filter_by: словарь значений параметров, по к-м необходима фильтрация в БД
        '''

        modes = ['orm_model', 'scheme', 'dict']
        if mode not in modes:
            raise RepositoryException(
                description=f"Ошибка при поиске записи: неверный режим выгрузки данных: {mode}. "
                            f"Возможные варианты: {modes}",
            )

        filter_by = {key: val for key, val in filter_by.items() if val is not None} if filter_by else {}
        statement = select(self.model).filter_by(**filter_by)

        if config_sort:
            statement = self.sort_by_columns(statement, config_sort)
        res = await self.session.execute(statement)
        res = res.all()
        if mode == 'orm_model':
            res = [row[0] for row in res]
        elif mode == 'scheme':
            res = [row[0].to_read_model() for row in res]
        elif mode == 'dict':
            res = [row[0].to_read_model().dict() for row in res]
        return res

    async def find_one(self, mode='orm_model', **filter_by):
        '''
        :param mode: при 'scheme' - возвращает объект класса pydantic.BaseModel,
                     при 'orm_model' (по ум.) - возвращает объект класса sqlalchemy.ext.declarative.declarative_base
                     при 'dict' (по ум.) - возвращает словарь, сгенерированный из pydentic.BaseModel
        :param filter_by:
        '''
        modes = ['orm_model', 'scheme', 'dict']
        if mode not in modes:
            raise RepositoryException(
                description=f"Ошибка при поиске записи: неверный режим выгрузки данных: {mode}. "
                            f"Возможные варианты: {modes}",
            )
        statement = select(self.model).filter_by(**filter_by)
        res = await self.session.execute(statement)
        try:
            res = res.one_or_none()
        except MultipleResultsFound:
            raise RepositoryException(
                description=f"Дублирование строк во время поиска в БД по фильтру",
                data=filter_by,
            )

        if res:
            if mode == 'scheme':
                res = res[0].to_read_model()
            elif mode == 'orm_model':
                res = res[0]
            elif mode == 'dict':
                res = res[0].to_read_model().dict()

        return res

    async def delete_all(self, **filter_by):
        filter_by = {key: val for key, val in filter_by.items() if val is not None} if filter_by else {}
        statement = delete(self.model).filter_by(**filter_by).execution_options(synchronize_session=False)
        await self.session.execute(statement)
        await self.session.flush()

    async def reset_ai(self, column_name, start_id):
        '''
        Зависимость от БД (!!!)
        Текущая: postgres
        :return:
        '''
        async with self.engine.connect() as con:
            await con.execute(text(f"ALTER SEQUENCE {self.model.__tablename__}_{column_name}_seq RESTART WITH {start_id};"))
            await con.commit()

    def schemes_to_dataframe(self, data, readable=False):
        df = pd.DataFrame([rec.dict() for rec in data],
                          columns=[*(self.scheme_get.__fields__.keys())])
        if readable:
            df.rename(columns=self.scheme_get.get_readable_columns(), inplace=True)
        return df

    def sort_by_columns(self, sqlalchemy_statement, config_sort: List):
        order_by_clauses = []
        for column_name, is_asceding in config_sort:
            column = getattr(self.model, column_name)
            if is_asceding:
                order_by_clauses.append(asc(column))
            else:
                order_by_clauses.append(desc(column))
        return sqlalchemy_statement.order_by(*order_by_clauses)
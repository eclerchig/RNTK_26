import os
import pdb
from pathlib import Path

import pandas as pd
import numpy as np
from celery.contrib import rdb
import aiofiles

from exceptions.services import ServiceFileUploadException
from interfaces.exception import APIException
from interfaces.service import BaseDataService

from logic.file_upload_processors.FileUploadProcessor import ExcelConverter
from logic.file_upload_processors.CompensationsCoeffsCellFileUploadProcess import CompensationsCoeffsCellFileUploadProcess
from schemas.celery import UpdateProgressMeta
from tasks.progress_tracker import task_progress_tracker


class CellsService(BaseDataService):
    def __init__(self):
        super().__init__(repository_name='cells')

    async def upload_polygons_files(self, uow, paths: list[Path], solid_id, task_id:str = None):

        total_cells = len(paths)
        async with uow:
            try:
                for path in paths:
                    head, tail = os.path.split(path)
                    cell = tail.split('_')[0]
                    await uow.cells.add_one({'solid_id': solid_id, 'name': cell})
            except APIException as e:
                raise ServiceFileUploadException(e)
            await uow.commit()

        async with uow:
            for num, path in enumerate(paths):
                polygons_df = pd.DataFrame(columns=['cell_id', 'order', 'x', 'y'])
                try:
                    async with aiofiles.open(path, 'rb') as file:
                        bytes = await file.read()
                        bytes_splitted = bytes.strip().split(b'\r')
                        coords_string = list(map(lambda byte_row: byte_row.strip().decode("utf-8").split(' '), bytes_splitted))[1:]
                        coords = np.array(list(map(lambda coords: [float(num) for num in coords], coords_string)))

                        polygons_df['x'], polygons_df['y'] = coords[:, 0], coords[:, 1]
                        ead, tail = os.path.split(path)
                        cell = tail.split('_')[0]
                        polygons_df['order'] = range(1, len(coords) + 1)

                        cell_row = await uow.cells.find_one(name=cell)
                        polygons_df['cell_id'] = cell_row.id

                    if task_id:
                        task_progress_tracker.update_meta(
                            task_id=task_id,
                            data=UpdateProgressMeta(
                                alert_msg=f"Загружены скважины {num+1}/{total_cells}",
                                current=((num+1)/total_cells)*100,
                                total=100,
                            )
                        )
                except APIException as e:
                    raise ServiceFileUploadException(e)

                polygons_recs = polygons_df.to_dict(orient='records')
                await uow.cell_polygons.delete_all(cell_id=cell_row.id)
                [await uow.cell_polygons.add_one(rec, check_dublicate=False) for rec in polygons_recs]
            await uow.commit()

    async def upload_comp_coeffs_file(self, uow, file_path, solid_id, task_id:str = None):
        async with aiofiles.open(file_path, 'rb') as file:
            content = await file.read()
            async with uow:
                try:
                    purpose_comp_coeff_df = CompensationsCoeffsCellFileUploadProcess(ExcelConverter()).process(
                        content,
                        solid_id=solid_id,
                        task_id=task_id,
                    )
                except Exception as e:
                    raise ServiceFileUploadException(e)

                if task_id:
                    task_progress_tracker.update_meta(
                        task_id=task_id,
                        data=UpdateProgressMeta(
                            alert_msg="Загрузка данных в БД",
                            current=75,
                            total=100,
                        )
                    )
                cells_recs = purpose_comp_coeff_df.to_dict(orient='records')
                [await uow.cells.add_one(rec, check_dublicate=True) for rec in cells_recs]
                await uow.commit()

    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      repository_name=repository_name,
                                      **filter_by)
        return data

    async def get_cells_names(self, uow):
        cells_df = await self.get_data(uow, result_type='dataframe', repository_name='cells')
        return cells_df['name'].unique().tolist()
import pdb

from dateutil.relativedelta import relativedelta

from interfaces.service import BaseDataService
from logic.decorators import append_cells_coeffs_to_dataframe
from stratagies.LoadTable import build_q_inj_potential
from services.techmode import TechModeService
from services.solids import SolidsService

from interfaces.DIContainer import service_container as services


class PotentialInjectionService(BaseDataService):
    def __init__(self):
        super().__init__(repository_name='potential_injections')

    async def calculate_potential_injection(self, uow, user_id, begin_date, end_date, solid_name):

        solids = await SolidsService().get_data(uow, result_type='dataframe', name=solid_name)

        pbd_df = await services['pressure_bg'].get_data(uow, result_type='dataframe')

        techmode_df = await TechModeService().get_actual_tech_modes(uow,
                                                                    pbd_df,
                                                                    begin_date,
                                                                    end_date,
                                                                    solids['id'].values[0])

        async with uow:
            potential_inj_df = build_q_inj_potential(techmode_df, solid_name, begin_date, end_date)
            potential_inj_df = potential_inj_df.replace({float('nan'): None})
            potential_inj_df['date'] = potential_inj_df['date'].apply(lambda dt: dt - relativedelta(days=20))
            potential_inj_df['user_id'] = user_id

            potential_inj_recs = potential_inj_df.to_dict(orient='records')

            ids = [await uow.potential_injections.add_one(rec, check_dublicate=True) for rec in potential_inj_recs]
            ids = [id for id in ids if id is not None]
            await uow.commit()
        return ids

    @append_cells_coeffs_to_dataframe
    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        return await super().get_data(uow, result_type=result_type, readable=readable,
                                      repository_name=repository_name,
                                      config_sort=[('date', False)], **filter_by)

import pdb
from pathlib import Path
from fastapi import UploadFile, File


from api.web_socket_connection import wsOptionsManager
from exceptions.services import ServiceFileUploadException
from logic.file_upload_processors.FileUploadProcessor import ExcelConverter
from logic.file_upload_processors.WellsFileUploadProcessor import WellsFileUploadProcess
from logic.file_upload_processors.ExpetionsWellNameFileUploadProcessor import ExceptionsWellNameFileUploadProcess
from interfaces.service import BaseDataService
from schemas.celery import UpdateProgressMeta
from tasks.progress_tracker import task_progress_tracker


class WellsService(BaseDataService):
    def __init__(self):
        super().__init__(repository_name='wells')

    async def upload_wells_file(self, uow, file_path: Path, task_id: str = None):
        try:
            wells_df = WellsFileUploadProcess(ExcelConverter()).process(file_path, task_id=task_id)
        except Exception as e:
            raise ServiceFileUploadException(e)
        wells_recs = wells_df.to_dict(orient='records')

        if task_id:
            task_progress_tracker.update_meta(
                task_id=task_id,
                data=UpdateProgressMeta(
                    alert_msg="Загрузка данных в БД",
                    current=75,
                    total=100,
                )
            )

        async with uow:
            [await uow.wells.add_one(well) for well in wells_recs]
            await wsOptionsManager.broadcast("wells")
            await uow.commit()


    async def upload_exceptions_well_name_file(self, uow, file: UploadFile = File(...)):
        content = await file.read()
        try:
            excs_df = ExceptionsWellNameFileUploadProcess(ExcelConverter).process(content)
        except Exception as e:
            raise ServiceFileUploadException(e)
        excs_recs = excs_df.to_dict(orient='records')

        async with uow:
            [await uow.well_name_exceptions.add_one(exc) for exc in excs_recs]
            await uow.commit()

    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        repository_name = repository_name if repository_name else self.repository_name
        config_sort = [
            ('name', True),
            ('date_changes', False),
        ] if repository_name == 'wells' else [
            ('date_entry_encoding', False),
            ('kin_name', True)
        ]

        data = await super().get_data(
            uow=uow,
            result_type=result_type,
            readable=readable,
            repository_name=repository_name if repository_name else self.repository_name,
            config_sort=config_sort,
            **filter_by,
        )
        return data

    async def get_unique_trunks(self, uow):
        wells_df = await self.get_data(uow, result_type='dataframe', repository_name='wells')
        return wells_df.sort_values(by="name").name.unique().tolist()
import pdb
from pathlib import Path

from exceptions.business import EmptyPerforationUpload
from exceptions.services import ServiceFileUploadException

from interfaces.service import BaseDataService

from logic.file_upload_processors.FileUploadProcessor import ExcelConverter
from logic.file_upload_processors.PerforationFileUploadProcessor import PerforationFileUploadProcessor
from schemas.celery import UpdateProgressMeta

from services.inclinometry import InclinometryService
from services.monitoring import MonitoringService
from services.solids import SolidsService
from services.wells import WellsService
from tasks.progress_tracker import task_progress_tracker


class PerforationsService(BaseDataService):
    repository_name = 'perforations'

    def __init__(self):
        super().__init__(repository_name='perforations')

    async def upload_perforations_file(self, uow, file_path: Path, calc_coords_only_new=True, task_id:str = None):
        async with uow:

            if task_id:
                task_progress_tracker.update_meta(
                    task_id=task_id,
                    data=UpdateProgressMeta(
                        alert_msg="Загрузка старых перфораций и других таблиц для работы",
                        current=5,
                        total=100,
                    )
                )

            old_perfs_df = await PerforationsService().get_data(uow, result_type='dataframe')
            wells_df = await WellsService().get_data(uow, result_type='dataframe')
            incls_df = await InclinometryService().get_data(uow, result_type='dataframe')
            solids_df = await SolidsService().get_data(uow, result_type='dataframe')
            well_monitoring_df = await MonitoringService().get_data(uow, result_type='dataframe')

            try:
                perfs_df = PerforationFileUploadProcessor(ExcelConverter()).process(
                    file_path,
                    old_perfs_df=old_perfs_df,
                    wells_df=wells_df,
                    incls_df=incls_df,
                    solids_df=solids_df,
                    well_monitoring_df=well_monitoring_df,
                    calc_coords_only_new=calc_coords_only_new,
                    task_id=task_id,
                )
            except Exception as e:
                raise ServiceFileUploadException(e)
            if not perfs_df.empty:
                perfs_recs = perfs_df.to_dict(orient='records')

                ids = [await uow.perforations.add_one(perf) for perf in perfs_recs]
                ids = [id for id in ids if id is not None]
                await uow.commit()
                return ids
            else:
                raise EmptyPerforationUpload()

    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        config_sort = [('well_name', True), ('date', True)]
        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      repository_name=repository_name,
                                      config_sort=config_sort,
                                      **filter_by,
                                      )
        return data
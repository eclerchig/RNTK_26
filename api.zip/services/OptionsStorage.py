import functools
import json
import pdb
from datetime import datetime
from typing import List, Callable

from celery.contrib import rdb
from redis import Redis
from asgiref.sync import async_to_sync

from settings import settings
from interfaces.unit_of_work import UnitOfWork
from api.web_socket_connection import wsOptionsManager

class OptionsCacheService:
    """
    Сервис для централизованного получения и обновления options/unique values
    Например, названия объектов, скважин, кустов и т.д.
    """
    def __init__(
        self,
        redis_url="redis://localhost:6379/0",
        cache_namespace="options",
        expire_sec=3600,
    ):
        print('INIT OptionsCacheService')
        if not hasattr(self, 'redis'):
            self.redis = Redis.from_url(redis_url, decode_responses=True)
        if not hasattr(self, 'uow'):
            self.uow = UnitOfWork()
        if not hasattr(self, 'cache_namespace'):
            self.cache_namespace = cache_namespace
        if not hasattr(self, 'expire_sec'):
            self.expire_sec = expire_sec
        if not hasattr(self, '_caches'):
            self._caches = {
                'wells': {},
                'cells': {},
                'solids': {},
                'well_purposes': {},
                'pads': {},
                'kns': {},
            }

    async def refresh_all_caches(self):
        for key in self._caches:
            await self._update_options(key)

    def get_option(self, table: str):
        return self._caches[table]

    def check_value_in_options(self, value: str, table: str):
        try:
            cache = json.loads(self.redis.get(f"{self.cache_namespace}:{table}"))
            id_ = [k for k, v in cache.items() if v['value'] == value][0]
            return int(id_)
        except IndexError:
            return

    def update_cache_on_success(
        self,
        tables: List[str],
    ):
        def decorator(task_func: Callable):
            @functools.wraps(task_func)
            def wrapper(*args, **kwargs):
                result = task_func(*args, **kwargs)
                for table in tables:
                    async_to_sync(self._update_options)(table)
                return result
            return wrapper
        return decorator

    async def _update_options(
        self,
        table: str,
    ):
        data = {}
        async with self.uow:
            if table == "wells":
                data = await self.uow.wells.find_all(mode="dict")
                data = self._get_unique_values(data, required_field='name')
            elif table == "cells":
                data = await self.uow.cells.find_all(mode="dict")
                data = self._get_unique_values(data, required_field='name')
            elif table == "solids":
                data = await self.uow.solids.find_all(mode="dict")
                data = self._get_unique_values(data, required_field='name')
            elif table == "well_purposes":
                data = await self.uow.wells_monitoring.find_all(mode="dict")
                data = self._get_unique_values(data, required_field='purpose')
            elif table == "pads":
                data = await self.uow.pressure_bg.find_all(mode="dict")
                data = self._get_unique_values(data, required_field='pad')
            elif table == "kns":
                data = await self.uow.pressure_bg.find_all(mode="dict")
                data = self._get_unique_values(data, required_field='kns')

        cache_key = f"{self.cache_namespace}:{table}"
        self.redis.set(cache_key, json.dumps(data), ex=3600)
        await wsOptionsManager.broadcast(table)

    @staticmethod
    def _get_unique_values(
            list_of_dicts: List[dict],
            required_field: str) -> dict:
        timestamp = datetime.now().isoformat()
        fields = []
        ids = []
        for item in list_of_dicts:
            fields_content = dict()
            fields_content['value'] = item[required_field]
            fields_content['timestamp'] = timestamp
            ids.append(item['id'])
            if fields_content not in fields:
                fields.append(fields_content)
        return dict(zip(ids, fields))

# Замыкание
def _OptionsService():
    service: OptionsCacheService = OptionsCacheService(redis_url=settings.REDIS_URL)

    def get_service() -> OptionsCacheService:
        return service

    def set_service(obj: OptionsCacheService) -> None:
        nonlocal service
        service = obj

    return get_service, set_service

optionsService, setterOptionsService = _OptionsService()
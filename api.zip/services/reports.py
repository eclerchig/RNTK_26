import pdb
from datetime import date

import pandas as pd
from interfaces.DIContainer import service_container as services

from exceptions.business import NotExistSolidException, \
    EmptyCoeffsCalculationException, EmptyRecInjCalculationException
from interfaces.service import BaseDataService
from logic.utilities import lead_date_to_one_date_format, \
    dataframe_to_bytes_buffer_by_excel, dataframe_to_bytes_buffer_by_csv
from schemas.users import UsersSchemeGet


class ReportsService(BaseDataService):

    def __init__(self):
        super().__init__(None)
        self.repository_name = None

    @staticmethod
    def _convert_df_to_required_form(df, data_form, file_type):
        if data_form == 'json':
            df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
            return df.to_json(orient='records')
        elif data_form == 'file':
            if file_type == 'excel':
                return dataframe_to_bytes_buffer_by_excel(df)
            elif file_type == 'csv':
                return dataframe_to_bytes_buffer_by_csv(df)
            else:
                raise Exception
        else:
            raise Exception

    @staticmethod
    async def _calc_compensations(
            rec_injs: pd.DataFrame,
            target_injs: pd.DataFrame,
            monitoring: pd.DataFrame,
            coeffs: pd.DataFrame,
            date_begin: date = None,
            date_end: date = None,
            from_cell: bool = False,
    ):
        """
        Генерирует датафрейм с компенсацией
        """

        coeffs['date'] = coeffs['date'].apply(lambda x: lead_date_to_one_date_format(x))

        if date_begin and not date_end:
            coeffs = coeffs[(date_begin <= coeffs['date'])]
        if not date_begin and date_end:
            coeffs = coeffs[(coeffs['date'] <= date_end)]
        if date_begin and date_end:
            coeffs = coeffs[(date_begin <= coeffs['date']) & (coeffs['date'] <= date_end)]

        if coeffs.empty:
            raise EmptyCoeffsCalculationException(date_begin, date_end, from_cell)

        if from_cell:
            total = coeffs[coeffs['center_well_purpose'] == 'Нагнетательная'][
                ['center_well', 'cell_name', 'date']]
            coeffs_prod = coeffs[coeffs['center_well_purpose'] == 'Добывающая'][
                ['center_well', 'cell_name', 'date', 'distance_coefficient']]

            total = total.merge(monitoring[['date', 'well_name', 'water_injection', 'days']],
                                left_on=['center_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)
            total = total[total['water_injection'].notna()]
            total['water_injection'] = total.apply(lambda row: round(row['water_injection'] * 1000 / row['days'], 3),
                                                   axis=1)
            total = total.drop('days', axis=1)

            total = total.merge(target_injs[target_injs['target_inj'] > 0.0][['date', 'well_name', 'target_inj']],
                                left_on=['center_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)

            total = total.merge(rec_injs[['date', 'well_name', 'inj_agrp_recommended', 'inj_infr_recommended']],
                                left_on=['center_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)
            total = total[total['inj_agrp_recommended'].notna() & total['inj_infr_recommended'].notna()]

            coeffs_prod = coeffs_prod.merge(monitoring[['date', 'well_name', 'reservoir_sampling']],
                                            left_on=['center_well', 'date'],
                                            right_on=['well_name', 'date'],
                                            how='left').drop('well_name', axis=1)
            coeffs_prod = coeffs_prod[coeffs_prod['reservoir_sampling'].notna()]
            coeffs_prod['reservoir_sampling_partly'] = coeffs_prod.apply(
                lambda row: round(row['reservoir_sampling'] * row['distance_coefficient'], 2),
                axis=1)
            coeffs_prod['reservoir_sampling_in_cell'] = coeffs_prod.groupby(['date', 'cell_name'])[
                'reservoir_sampling_partly'] \
                .transform('sum')

            total = total.merge(coeffs_prod[['date', 'cell_name', 'reservoir_sampling_in_cell']].drop_duplicates(),
                                on=['date', 'cell_name'], how='left')

            total = total.drop_duplicates()
            total['compens_inj_curr'] = total.apply(
                lambda row: round(row['water_injection'] / row['reservoir_sampling_in_cell'] * 100, 2)
                if row['reservoir_sampling_in_cell'] != 0.0 else 0.0, axis=1)
            total['compens_target_inj'] = total.apply(
                lambda row: round(row['target_inj'] / row['reservoir_sampling_in_cell'] * 100, 2)
                if row['reservoir_sampling_in_cell'] != 0.0 else 0.0, axis=1)
            total['compens_rec_AGRP'] = total.apply(
                lambda row: round(row['inj_agrp_recommended'] / row['reservoir_sampling_in_cell'] * 100, 2)
                if row['reservoir_sampling_in_cell'] != 0.0 else 0.0, axis=1)
            total['compens_rec_INFR'] = total.apply(
                lambda row: round(row['inj_infr_recommended'] / row['reservoir_sampling_in_cell'] * 100, 2)
                if row['reservoir_sampling_in_cell'] != 0.0 else 0.0, axis=1)

        else:
            coeffs = coeffs[coeffs['center_well_purpose'] == 'Нагнетательная']
            total = coeffs[['center_well', 'around_well', 'date', 'distance_coefficient']]

            total = total.merge(monitoring[['date', 'well_name', 'reservoir_sampling']],
                                left_on=['around_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)
            total = total[total['reservoir_sampling'].notna()]

            total = total.merge(monitoring[['date', 'well_name', 'water_injection', 'days']],
                                left_on=['center_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)
            total = total[total['water_injection'].notna()]

            total['water_injection'] = total.apply(
                lambda row: round(row['water_injection'] * 1000 / row['days'], 3),
                axis=1)
            total['inj_partly'] = total.apply(
                lambda row: round(row['distance_coefficient'] * row['water_injection'], 3),
                axis=1)
            total = total.drop('days', axis=1)

            total = total.merge(rec_injs[['date', 'well_name', 'inj_agrp_recommended', 'inj_infr_recommended']],
                                left_on=['center_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)

            total = total[total['inj_agrp_recommended'].notna() & total['inj_infr_recommended'].notna()]

            total['agrp_rec_partly'] = total.apply(
                lambda row: round(row['distance_coefficient'] * row['inj_agrp_recommended'], 2),
                axis=1)
            total['infr_rec_partly'] = total.apply(
                lambda row: round(row['distance_coefficient'] * row['inj_infr_recommended'], 2),
                axis=1)

            total['injection_for_prod_well'] = total.groupby(['date', 'around_well'])['inj_partly'].transform('sum')
            total['agrp_rec_injection_for_prod_well'] = total.groupby(['date', 'around_well'])[
                'agrp_rec_partly'].transform(
                'sum')
            total['infr_rec_injection_for_prod_well'] = total.groupby(['date', 'around_well'])[
                'infr_rec_partly'].transform(
                'sum')

            total['compens_reserv'] = total.apply(
                lambda row: round(row['injection_for_prod_well'] / row['reservoir_sampling'] * 100, 2)
                if row['reservoir_sampling'] != 0.0 else 0.0, axis=1)
            total['compens_rec_AGRP'] = total.apply(
                lambda row: round(row['agrp_rec_injection_for_prod_well'] / row['reservoir_sampling'] * 100, 2) if
                row['reservoir_sampling'] != 0.0 else 0.0, axis=1)
            total['compens_rec_INFR'] = total.apply(
                lambda row: round(row['infr_rec_injection_for_prod_well'] / row['reservoir_sampling'] * 100, 2) if
                row['reservoir_sampling'] != 0.0 else 0.0, axis=1)

            total = total.drop(['inj_partly', 'agrp_rec_partly', 'infr_rec_partly'], axis=1)

        return total

    async def get_recommended_inj_report(self,
                                         uow: UsersSchemeGet,
                                         user_id: int,
                                         solid_name=None,
                                         date_begin=None, date_end=None,
                                         from_cell=False,
                                         file_type: str = 'excel',
                                         data_form: str = 'json'):
        solid = await services['solids'].get_data(uow, result_type='dataframe', name=solid_name)
        if solid_name and solid.empty:
            raise NotExistSolidException(solid_name)

        monitoring = await services['monitoring'].get_data(uow,
                                                           result_type='dataframe',
                                                           solid_id=solid['id'].values[0] if solid_name else None,
                                                           user_id=user_id,
                                                           repository_name='prod_monitoring')

        coeffs = await services['participation_coefficient'].get_data(uow,
                                                                      result_type='dataframe',
                                                                      solid_id=solid['id'].values[0] if solid_name else None,
                                                                      from_cell=from_cell,
                                                                      user_id=user_id)

        potential_inj = await services['potential_injection'].get_data(uow,
                                                                       result_type='dataframe',
                                                                       solid_id=solid['id'].values[0] if solid_name else None,
                                                                       user_id=user_id)
        target_inj = await services['target_injection'].get_data(uow,
                                                                 result_type='dataframe',
                                                                 solid_id=solid['id'].values[0] if solid_name else None,
                                                                 from_cell=from_cell,
                                                                 user_id=user_id)
        rec_injs = await services['rec_injection'].get_data(uow,
                                                            result_type='dataframe',
                                                            solid_id=solid['id'].values[0] if solid_name else None,
                                                            from_cell=from_cell,
                                                            user_id=user_id)

        if date_begin and not date_end:
            coeffs = coeffs[(date_begin <= coeffs['date'])]
        if not date_begin and date_end:
            coeffs = coeffs[(coeffs['date'] <= date_end)]
        if date_begin and date_end:
            coeffs = coeffs[(date_begin <= coeffs['date']) & (coeffs['date'] <= date_end)]

        if coeffs.empty:
            raise EmptyCoeffsCalculationException(date_begin, date_end, from_cell)

        if from_cell:
            coeffs = coeffs[coeffs['center_well_purpose'] == 'Нагнетательная']
            total = coeffs[['center_well', 'cell_name', 'date']]
            total = total.merge(monitoring[['date', 'well_name', 'water_injection', 'days']],
                                left_on=['center_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)
            total['water_injection'] = total.apply(lambda row: row['water_injection'] * 1000 / row['days'], axis=1)

            target_inj_prod = target_inj[target_inj['purpose'] == 'Добывающая']
            target_inj_prod['target_inj'] = target_inj_prod['target_inj'].apply(lambda x: round(x, 3))
            target_inj_prod['target_inj_in_cell'] = target_inj_prod.groupby(['date', 'cell_name'])['target_inj'] \
                .transform('sum')
            target_inj_prod = target_inj_prod.drop_duplicates(subset=['date', 'cell_name'])[
                ['date', 'cell_name', 'target_inj_in_cell']]
            total = total.merge(target_inj[['date', 'well_name', 'cell_name', 'target_inj']],
                                left_on=['center_well', 'cell_name', 'date'],
                                right_on=['well_name', 'cell_name', 'date'],
                                how='left').drop('well_name', axis=1)

            total = total.merge(target_inj_prod[['date', 'cell_name', 'target_inj_in_cell']],
                                on=['cell_name', 'date'], how='left')

            total = total.merge(potential_inj[['date', 'well_name', 'inj_agrp_potential', 'inj_infr_potential']],
                                left_on=['center_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)

            total = total.merge(
                rec_injs[['date', 'well_name', 'cell_name', 'inj_agrp_recommended', 'inj_infr_recommended']],
                left_on=['center_well', 'cell_name', 'date'],
                right_on=['well_name', 'cell_name', 'date'],
                how='left').drop('well_name', axis=1)
        else:
            coeffs = coeffs[coeffs['center_well_purpose'] == 'Добывающая']

            total = coeffs[['center_well', 'around_well', 'date', 'distance_coefficient']]

            total = total.merge(monitoring[['date', 'well_name', 'reservoir_sampling']],
                                left_on=['center_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)

            total['inj_partly'] = total.apply(lambda row: row['distance_coefficient'] * row['reservoir_sampling'],
                                              axis=1)

            total = total.merge(monitoring[['date', 'well_name', 'water_injection', 'days']],
                                left_on=['around_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)

            total['water_injection'] = total.apply(lambda row: row['water_injection'] * 1000 / row['days'], axis=1)

            total = total.merge(target_inj[['date', 'well_name', 'target_inj']],
                                left_on=['around_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)

            total = total.merge(potential_inj[['date', 'well_name', 'inj_agrp_potential', 'inj_infr_potential']],
                                left_on=['around_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)

            total = total.merge(rec_injs[['date', 'well_name', 'inj_agrp_recommended', 'inj_infr_recommended']],
                                left_on=['around_well', 'date'],
                                right_on=['well_name', 'date'],
                                how='left').drop('well_name', axis=1)

        total['date'] = total['date'].apply(lambda x: lead_date_to_one_date_format(x))

        total = total.rename(columns={
            'center_well': 'Центр. скважина',
            'around_well': 'Влияющ. скважина',
            'cell_name': 'Ячейка',
            'date': 'Дата',
            'distance_coefficient': 'КУ',
            'reservoir_sampling': 'Отборы в пластовых условиях, м3/сут',
            'water_injection': 'Закачка воды (мониторинг), м3/сут',
            'days': 'Кол-во дней',
            'inj_partly': 'Закачка по отборам с учетом КУ, м3/сут',
            'target_inj': 'Целевая закачка, м3/сут',
            'target_inj_in_cell': 'Целевая закачка на ячейке, м3/сут',
            'inj_agrp_potential': 'Закачка АГРП потенциальная, м3/сут',
            'inj_infr_potential': 'Закачка ИНФР потенциальная, м3/сут',
            'inj_agrp_recommended': 'Закачка АГРП рекомендуемая, м3/сут',
            'inj_infr_recommended': 'Закачка ИНФР рекомендуемая, м3/сут'
        })

        return self._convert_df_to_required_form(total, data_form, file_type)

    async def get_compensation_report(self,
                                      uow: UsersSchemeGet,
                                      user_id: int,
                                      solid_name=None,
                                      date_begin=None, date_end=None,
                                      from_cell=False,
                                      file_type: str = 'excel',
                                      data_form: str = 'json'):
        solid = await services['solids'].get_data(uow, result_type='dataframe', name=solid_name)
        if solid_name and solid.empty:
            raise NotExistSolidException(solid_name)

        monitoring = await services['monitoring'].get_data(uow,
                                                           result_type='dataframe',
                                                           solid_id=solid['id'].values[0] if solid_name else None,
                                                           user_id=user_id,
                                                           repository_name='prod_monitoring')

        coeffs = await services['participation_coefficient'].get_data(uow,
                                                                      result_type='dataframe',
                                                                      solid_id=solid['id'].values[
                                                                          0] if solid_name else None,
                                                                      from_cell=from_cell,
                                                                      user_id=user_id)
        if coeffs.empty:
            raise EmptyCoeffsCalculationException(date_begin, date_end, from_cell)

        target_inj = await services['target_injection'].get_data(uow,
                                                                 result_type='dataframe',
                                                                 solid_id=solid['id'].values[0] if solid_name else None,
                                                                 from_cell=from_cell,
                                                                 user_id=user_id)
        rec_injs = await services['rec_injection'].get_data(uow,
                                                            result_type='dataframe',
                                                            solid_id=solid['id'].values[0] if solid_name else None,
                                                            from_cell=from_cell,
                                                            user_id=user_id)

        compensations_table = await self._calc_compensations(rec_injs, target_inj, monitoring, coeffs,
                                                             date_begin, date_end, from_cell)
        compensations_table = compensations_table.rename(
            columns={
                'center_well': 'Наг. скважина',
                'around_well': 'Доб. скважина',
                'cell_name': 'Ячейка',
                'date': 'Дата',
                'distance_coefficient': 'КУ',
                'reservoir_sampling': 'Отборы в пластовых условиях, м3/сут',
                'reservoir_sampling_in_cell': 'Пластовые отборы в ячейке, м3/сут',
                'water_injection': 'Закачка воды (мониторинг), м3/сут',
                'inj_partly': 'Закачка (мониторинг) от нагн. скважины, м3/сут',
                'target_inj': 'Целевая закачка, м3/сут',
                'inj_agrp_recommended': 'Закачка рек. АГРП, м3/сут',
                'inj_infr_recommended': 'Закачка рек. ИНФР, м3/сут',
                'agrp_rec_partly': 'Закачка рек. АГРП от нагн. скважины, м3/сут',
                'infr_rec_partly': 'Закачка рек. ИНФР от нагн. скважины, м3/сут',
                'agrp_rec_injection_for_prod_well': 'Закачка рек. АГРП на доб. скважине, м3/сут',
                'infr_rec_injection_for_prod_well': 'Закачка рек. ИНФР на доб. скважине, м3/сут',
                'injection_for_prod_well': 'Закачка на доб. скважине, м3/сут',
                'compens_inj_curr': 'Компенсация (мониторинг), %',
                'compens_reserv': 'Компенсация (мониторинг), %',
                'compens_target_inj': 'Компенсация (целевая закачка), %',
                'compens_rec_AGRP': 'Компенсация (закачка рек. АГРП), %',
                'compens_rec_INFR': 'Компенсация (закачка рек. ИНФР), %'
            })

        return self._convert_df_to_required_form(compensations_table, data_form, file_type)

    async def get_prod_report(self,
                              uow: UsersSchemeGet,
                              user_id: int,
                              solid_name=None,
                              date_begin=None, date_end=None,
                              file_type: str = 'excel',
                              data_form: str = 'json'):
        solid = await services['solids'].get_data(uow, result_type='dataframe', name=solid_name)
        if solid_name and solid.empty:
            raise NotExistSolidException(solid_name)

        monitoring = await services['monitoring'].get_data(uow,
                                                           result_type='dataframe',
                                                           solid_id=solid['id'].values[0] if solid_name else None,
                                                           user_id=user_id,
                                                           repository_name='prod_monitoring')

        coeffs = await services['participation_coefficient'].get_data(uow,
                                                                      result_type='dataframe',
                                                                      solid_id=solid['id'].values[
                                                                          0] if solid_name else None,
                                                                      from_cell=False,
                                                                      user_id=user_id)
        if coeffs.empty:
            raise EmptyCoeffsCalculationException(date_begin, date_end, False)

        target_inj = await services['target_injection'].get_data(uow,
                                                                 result_type='dataframe',
                                                                 solid_id=solid['id'].values[0] if solid_name else None,
                                                                 from_cell=False,
                                                                 user_id=user_id)
        rec_injs = await services['rec_injection'].get_data(uow,
                                                            result_type='dataframe',
                                                            solid_id=solid['id'].values[0] if solid_name else None,
                                                            from_cell=False,
                                                            user_id=user_id)

        table = await self._calc_compensations(rec_injs, target_inj, monitoring, coeffs, date_begin, date_end)
        table = table.drop_duplicates(
            subset=['around_well', 'date', 'reservoir_sampling', 'compens_rec_AGRP', 'compens_rec_INFR'],
        )[['around_well', 'date', 'reservoir_sampling', 'compens_rec_AGRP', 'compens_rec_INFR']]

        table = table[['around_well', 'date', 'reservoir_sampling', 'compens_rec_AGRP', 'compens_rec_INFR']]
        table = table.rename(
            columns={
                'around_well': 'Доб. скважина',
                'date': 'Дата',
                'reservoir_sampling': 'Отборы в пластовых условиях, м3/сут',
                'compens_rec_AGRP': 'Компенсация (закачка рек. АГРП), %',
                'compens_rec_INFR': 'Компенсация (закачка рек. ИНФР), %'
            })
        return self._convert_df_to_required_form(table, data_form, file_type)

    async def get_inj_report(self,
                             uow: UsersSchemeGet,
                             user_id: int,
                             solid_name=None,
                             date_begin=None, date_end=None,
                             from_cell: bool = False,
                             file_type: str = 'excel',
                             data_form: str = 'json'):
        solid = await services['solids'].get_data(uow, result_type='dataframe', name=solid_name)
        if solid_name and solid.empty:
            raise NotExistSolidException(solid_name)

        rec_injs = await services['rec_injection'].get_data(uow,
                                                            result_type='dataframe',
                                                            solid_id=solid['id'].values[0] if solid_name else None,
                                                            from_cell=from_cell,
                                                            user_id=user_id)

        if date_begin and not date_end:
            rec_injs = rec_injs[(date_begin <= rec_injs['date'])]
        if not date_begin and date_end:
            rec_injs = rec_injs[(rec_injs['date'] <= date_end)]
        if date_begin and date_end:
            rec_injs = rec_injs[(date_begin <= rec_injs['date']) & (rec_injs['date'] <= date_end)]

        if rec_injs.empty:
            raise EmptyRecInjCalculationException(date_begin, date_end, from_cell)

        monitoring = await services['monitoring'].get_data(uow,
                                                           result_type='dataframe',
                                                           solid_id=solid['id'].values[0] if solid_name else None,
                                                           user_id=user_id,
                                                           repository_name='prod_monitoring')

        coeffs = await services['participation_coefficient'].get_data(uow,
                                                                      result_type='dataframe',
                                                                      solid_id=solid['id'].values[
                                                                          0] if solid_name else None,
                                                                      from_cell=from_cell,
                                                                      user_id=user_id)
        if coeffs.empty:
            raise EmptyCoeffsCalculationException(date_begin, date_end, False)

        target_inj = await services['target_injection'].get_data(uow,
                                                                 result_type='dataframe',
                                                                 solid_id=solid['id'].values[0] if solid_name else None,
                                                                 from_cell=from_cell,
                                                                 user_id=user_id)

        injs = rec_injs.merge(monitoring[['date', 'well_name', 'water_injection', 'days']],
                              on=['date', 'well_name'],
                              how='left')

        injs['water_injection'] = injs.apply(lambda row: row['water_injection'] * 1000 / row['days'], axis=1)

        injs = injs.merge(target_inj[['date', 'well_name', 'target_inj']],
                          on=['date', 'well_name'],
                          how='left')

        injs['date'] = injs['date'].apply(lambda x: lead_date_to_one_date_format(x))

        injs['delta_agrp_rec_injection_monit'] = injs.apply(
            lambda row: row['inj_agrp_recommended'] - row['water_injection'],
            axis=1)
        injs['delta_infr_rec_injection_monit'] = injs.apply(
            lambda row: row['inj_infr_recommended'] - row['water_injection'],
            axis=1)
        injs['delta_agrp_rec_injection_target'] = injs.apply(
            lambda row: row['inj_agrp_recommended'] - row['target_inj'],
            axis=1)
        injs['delta_infr_rec_injection_target'] = injs.apply(
            lambda row: row['inj_infr_recommended'] - row['target_inj'],
            axis=1)
        injs = injs[['well_name',
                     'date',
                     'water_injection',
                     'target_inj',
                     'inj_agrp_recommended',
                     'inj_infr_recommended',
                     'delta_agrp_rec_injection_monit',
                     'delta_infr_rec_injection_monit',
                     'delta_agrp_rec_injection_target',
                     'delta_infr_rec_injection_target',
                     ]]
        injs = injs.rename(
            columns={
                'well_name': 'Cкважина',
                'date': 'Дата',
                'water_injection': 'Закачка воды (мониторинг), м3/сут',
                'target_inj': 'Целевая закачка, м3/сут',
                'inj_agrp_recommended': 'Закачка рек. АГРП, м3/сут',
                'inj_infr_recommended': 'Закачка рек. ИНФР, м3/сут',
                'delta_agrp_rec_injection_monit': 'Дельта (рек. АГРП и мониторинг), м3/сут',
                'delta_infr_rec_injection_monit': 'Дельта (рек. ИНФР и мониторинг), м3/сут',
                'delta_agrp_rec_injection_target': 'Дельта (рек. АГРП и целевая), м3/сут',
                'delta_infr_rec_injection_target': 'Дельта (рек. АГРП и целевая), м3/сут',
            })
        return self._convert_df_to_required_form(injs, data_form, file_type)

    async def get_cells_report(self,
                               uow: UsersSchemeGet,
                               user_id: int,
                               solid_name=None,
                               date_begin=None, date_end=None,
                               file_type: str = 'excel',
                               data_form: str = 'json'):
        solid = await services['solids'].get_data(uow, result_type='dataframe', name=solid_name)
        if solid_name and solid.empty:
            raise NotExistSolidException(solid_name)

        rec_injs = await services['rec_injection'].get_data(uow,
                                                            result_type='dataframe',
                                                            solid_id=solid['id'].values[0] if solid_name else None,
                                                            from_cell=True,
                                                            user_id=user_id)

        if date_begin and not date_end:
            rec_injs = rec_injs[(date_begin <= rec_injs['date'])]
        if not date_begin and date_end:
            rec_injs = rec_injs[(rec_injs['date'] <= date_end)]
        if date_begin and date_end:
            rec_injs = rec_injs[(date_begin <= rec_injs['date']) & (rec_injs['date'] <= date_end)]

        if rec_injs.empty:
            raise EmptyRecInjCalculationException(date_begin, date_end, True)

        monitoring = await services['monitoring'].get_data(uow,
                                                           result_type='dataframe',
                                                           solid_id=solid['id'].values[0] if solid_name else None,
                                                           user_id=user_id,
                                                           repository_name='prod_monitoring')

        coeffs = await services['participation_coefficient'].get_data(uow,
                                                                      result_type='dataframe',
                                                                      solid_id=solid['id'].values[
                                                                          0] if solid_name else None,
                                                                      from_cell=True,
                                                                      user_id=user_id)
        if coeffs.empty:
            raise EmptyCoeffsCalculationException(date_begin, date_end, False)

        target_inj = await services['target_injection'].get_data(uow,
                                                                 result_type='dataframe',
                                                                 solid_id=solid['id'].values[0] if solid_name else None,
                                                                 from_cell=True,
                                                                 user_id=user_id)

        compensations = await self._calc_compensations(rec_injs,
                                                       target_inj,
                                                       monitoring,
                                                       coeffs,
                                                       date_begin,
                                                       date_end,
                                                       from_cell=True)
        compensations = compensations.drop(columns=['target_inj'])

        target_inj_prod = target_inj[target_inj['purpose'] == 'Добывающая']
        target_inj_prod['target_inj'] = target_inj_prod['target_inj'].apply(lambda x: round(x, 3))
        target_inj_prod['target_inj_in_cell'] = target_inj_prod.groupby(['date', 'cell_name'])['target_inj'] \
            .transform('sum')
        target_inj_prod = target_inj_prod.drop_duplicates(subset=['date', 'cell_name'])[
            ['date', 'cell_name', 'target_inj_in_cell']]

        compensations['water_injection_in_cell'] = compensations.groupby(['date', 'cell_name'])[
            'water_injection'].transform('sum')
        compensations['inj_agrp_recommended_in_cell'] = compensations.groupby(['date', 'cell_name'])[
            'inj_agrp_recommended'].transform('sum')
        compensations['inj_infr_recommended_in_cell'] = compensations.groupby(['date', 'cell_name'])[
            'inj_infr_recommended'].transform('sum')
        compensations['compens_inj_curr_in_cell'] = compensations.groupby(['date', 'cell_name'])[
            'compens_inj_curr'].transform('sum')
        compensations['compens_target_in_cell'] = compensations.groupby(['date', 'cell_name'])[
            'compens_target_inj'].transform('sum')
        compensations['compens_inj_agrp_rec_in_cell'] = compensations.groupby(['date', 'cell_name'])[
            'compens_rec_AGRP'].transform('sum')
        compensations['compens_inj_infr_rec_in_cell'] = compensations.groupby(['date', 'cell_name'])[
            'compens_rec_INFR'].transform('sum')
        compensations = compensations.merge(target_inj_prod, on=['date', 'cell_name'], how='left')

        compensations = compensations[
            ['cell_name', 'date'] +
            list(filter(lambda col: 'in_cell' in col, compensations.columns.tolist()))
        ]

        compensations = compensations.rename(
            columns={
                'cell_name': 'Ячейка',
                'date': 'Дата',
                'reservoir_sampling_in_cell': 'Отборы в пластовых условиях, м3/сут',
                'water_injection_in_cell': 'Закачка воды (мониторинг), м3/сут',
                'target_inj_in_cell': 'Целевая закачка, м3/сут',
                'inj_agrp_recommended_in_cell': 'Закачка рек. АГРП, м3/сут',
                'inj_infr_recommended_in_cell': 'Закачка рек. ИНФР, м3/сут',
                'compens_inj_curr_in_cell': 'Компенсация (закачка), %',
                'compens_target_in_cell': 'Компенсация (цел. закачка), %',
                'compens_inj_agrp_rec_in_cell': 'Компенсация (закачка рек. АГРП), %',
                'compens_inj_infr_rec_in_cell': 'Компенсация (закачка рек. ИНФР), %',
            })
        return self._convert_df_to_required_form(compensations, data_form, file_type)

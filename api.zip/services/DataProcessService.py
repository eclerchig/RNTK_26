import asyncio
import pdb
import datetime
from io import BytesIO
from os.path import dirname, abspath

import pandas as pd
from fastapi import UploadFile

ROOT_DIR = dirname(dirname(abspath(__file__)))


class DataProcessService:

    CONTINIOUS_VARS = ['debitOil', 'debitLiq', 'watercut', 'timeWorkProd', 'solidPress', 'downholePress', 'dynLevel']

    async def process_mer(self, file: UploadFile):
        contents = await file.read()
        excel_file = BytesIO(contents)
        df = pd.read_excel(excel_file, sheet_name='МЭР')
        df = df.drop(df.columns[[14, 15]], axis=1)
        df.columns = ['date', 'well', 'mainWell', 'debitOil', 'debitLiq', 'watercut',
                      'cumOil','cumLiq', 'timeWorkProd', 'solidPress',
                      'downholePress', 'debitOilFirst', 'debitLiqFirst', 'dynLevel', 'pushTR']
        df['date'] = pd.to_datetime(df['date'], format='%d.%m.%Y')
        df['well'] = df['well'].astype(str)
        df['mainWell'] = df['mainWell'].astype(str)
        return df

    async def process_geology(self, file: UploadFile):
        contents = await file.read()
        excel_file = BytesIO(contents)
        df = pd.read_excel(excel_file, sheet_name='Геология')
        df = df.drop(df.columns[1], axis=1)
        df.columns = ['well', 'geology.porosity', 'geology.permeability', 'geology.kh',
                      'geology.onntDensity', 'geology.onnt', 'geology.initOilSaturation', 'geology.nnt']
        df['well'] = df['well'].astype(str)
        return df

    async def process_file(self, date_prediction: datetime.date, file_mer: UploadFile, file_geology: UploadFile):

        # Чтение файлов
        tasks = [
            asyncio.create_task(self.process_mer(file_mer), name="proc_mer"),
            asyncio.create_task(self.process_geology(file_geology), name="proc_geo"),
        ]

        await asyncio.wait(tasks, return_when=asyncio.ALL_COMPLETED)

        results = []
        for task in tasks:
            results.append(task.result())

        df_mer, df_geo = results

        df_mer_geo = pd.merge(df_mer, df_geo, on='well', how='left')
        df_mer_geo = df_mer_geo.drop(['well'], axis=1)
        # df_mer_geo = df_mer_geo.rename(columns={'Материнский ствол': 'Скважина'})
        df_mer_geo['rateDebitOilFallForYear'] = df_mer_geo.apply(
            lambda row:
                df_mer_geo[(df_mer_geo['date'] == (row['date'] - pd.DateOffset(months=12))) &
                            (df_mer_geo['well'] == row['well'])]['debitOil'].iloc[0] - row['debitOil']
                if df_mer_geo[(df_mer_geo['date'] == (row['date'] - pd.DateOffset(months=12))) &
                            (df_mer_geo['well'] == row['well'])].shape[0] != 0
                else None,
            axis=1)
        df_mer_geo['dateYearBefore'] = df_mer_geo.apply(lambda row: row['date'] - pd.DateOffset(months=12), axis=1)
        df_mer_geo['rateDebitOilFallForMonth'] = df_mer_geo.apply(
            lambda row:
                df_mer_geo[(df_mer_geo['date'] == (row['date'] - pd.DateOffset(months=1))) &
                           (df_mer_geo['well'] == row['well'])]
                ['debitOil'].iloc[0] - row['debitOil']
                if df_mer_geo[(df_mer_geo['date'] == (row['date'] - pd.DateOffset(months=1))) &
                           (df_mer_geo['debitOil'] == row['debitOil'])].shape[0] != 0
                else None,
            axis=1)
        # df_mer_geo = df_mer_geo.drop(df_mer_geo[(df_mer_geo['date'] < df_mer_geo['dateYearBefore'])
        #                              | (df_mer_geo['date'] > date_prediction)].index)
        df_mer_geo = df_mer_geo.dropna()
        df_mer_geo = df_mer_geo[df_mer_geo.groupby(['well'])['well'].transform('count') >= 12].copy()

        # Добавление статистических колонок
        for col in self.CONTINIOUS_VARS:
            df_mer_geo[f'{col} median'] = df_mer_geo.groupby(['well'])[col].transform('median')
        zero_days_counts = df_mer_geo.groupby(['well'])['timeWorkProd'].apply(
            lambda x: (x == 0).sum()).reset_index(name='numMonthsWithoutWork')
        df_mer_geo = df_mer_geo.merge(zero_days_counts, on=['wells'], how='left')
        df_mer_geo = df_mer_geo.drop(df_mer_geo[(df_mer_geo['date'].dt.year != date_prediction.year) |
                              (df_mer_geo['date'].dt.month != date_prediction.month)].index)
        return df_mer_geo


    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        config_sort = [
            ('date', False),
        ]
        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      config_sort=config_sort,
                                      **filter_by,
                                      )
        return data
import asyncio
import pdb
import datetime
from io import BytesIO
from os.path import dirname, abspath

import numpy as np
import pandas as pd
from fastapi import UploadFile

from interfaces.unit_of_work import UnitOfWork

from interfaces.service import BaseDataService

ROOT_DIR = dirname(dirname(abspath(__file__)))

def to_date(dt):
    if pd.isna(dt):
        return None
    if isinstance(dt, (pd.Timestamp, datetime.datetime)):
        return dt.date()
    return dt

class DataProcessService(BaseDataService):
    def __init__(self):
        self.repository_name = 'month_report'

    CONTINIOUS_VARS = ['debitOil', 'debitLiq', 'watercut', 'timeWorkProd', 'solidPress', 'downholePress', 'dynLevel']

    async def process_mer(self, file: UploadFile, predict_date):
        contents = await file.read()
        excel_file = BytesIO(contents)
        df = pd.read_excel(excel_file, sheet_name='МЭР')
        df = df.drop(df.columns[[14, 15]], axis=1)
        df.columns = ['date', 'well', 'wellMain', 'debitOil', 'debitLiq', 'watercut',
                      'cumOil','cumLiq', 'timeWorkProd', 'solidPress',
                      'downholePress', 'debitOilFirst', 'debitLiqFirst', 'dynLevel', 'pushTR']
        df = df[(df['date'] > predict_date - pd.DateOffset(months=24))]

        df['date'] = pd.to_datetime(df['date'], format='%d.%m.%Y')
        df['well'] = df['well'].astype(str)
        df['wellMain'] = df['wellMain'].astype(str)
        return df

    async def process_geology(self, file: UploadFile):
        contents = await file.read()
        excel_file = BytesIO(contents)
        df = pd.read_excel(excel_file, sheet_name='Геология')
        df.columns = ['well', 'porosity', 'permeability', 'kh',
                      'onntDensity', 'onnt', 'initOilSaturation', 'nnt']
        df['well'] = df['well'].astype(str)
        return df

    async def create_stat_df(self, df_mer, prediction_date):
        df_stat = df_mer.copy().dropna()
        df_stat['rateDebitOilFallForYear'] = df_stat.apply(
            lambda row:
            df_stat[(df_stat['date'] == (row['date'] - pd.DateOffset(months=12))) &
                   (df_stat['well'] == row['well'])]['debitOil'].iloc[0] - row['debitOil']
            if df_stat[(df_stat['date'] == (row['date'] - pd.DateOffset(months=12))) &
                      (df_stat['well'] == row['well'])].shape[0] != 0
            else None,
            axis=1)
        df_stat['dateYearBefore'] = df_stat.apply(lambda row: row['date'] - pd.DateOffset(months=12), axis=1)
        df_stat['rateDebitOilFallForMonth'] = df_stat.apply(
            lambda row:
            df_stat[(df_stat['date'] == (row['date'] - pd.DateOffset(months=1))) &
                   (df_stat['well'] == row['well'])]['debitOil'].iloc[0] - row['debitOil']
            if df_stat[(df_stat['date'] == (row['date'] - pd.DateOffset(months=1))) &
                      (df_stat['well'] == row['well'])].shape[0] != 0
            else None,
            axis=1)
        df_stat = df_stat[df_stat.groupby(['well'])['well'].transform('count') >= 12].copy()
        for col in self.CONTINIOUS_VARS:
            df_stat[f'{col}Median'] = df_stat.groupby(['well'])[col].transform('median')
        zero_days_counts = df_stat.groupby(['well'])['timeWorkProd'].apply(
            lambda x: (x == 0).sum()).reset_index(name='numMonthsWithoutWork')
        df_stat = df_stat.merge(zero_days_counts, on=['well'], how='left')
        df_stat = df_stat.dropna()
        df_stat = df_stat.drop(df_stat[df_stat['date'] < prediction_date - pd.DateOffset(months=12)].index)
        df_stat = df_stat[['well', 'date', 'rateDebitOilFallForYear', 'rateDebitOilFallForMonth',
                           'numMonthsWithoutWork', 'debitOilMedian', 'debitLiqMedian',
                           'watercutMedian', 'timeWorkProdMedian', 'solidPressMedian',
                           'downholePressMedian', 'dynLevelMedian']]
        return df_stat

    async def process_file(self, uow: UnitOfWork, predict_date: datetime.date, file_mer: UploadFile, file_geology: UploadFile):
        '''
        Обновляет таблицы МЭР, Геологии и Статистики.
        :param uow: UnitOfWork - работает с сессиями в БД
        :param predict_date: дата прогноза - от нее отсчитывается 12 мес назад для прогноза
        :param file_mer: Файл с листом МЭР и соответствующими колонками
        :param file_geology: Файл с листом Геология и соответствующими колонками
        :return: id записи Calculation для дальнейщего вывода
        '''
        predict_date = datetime.datetime.strptime("01/05/2025", "%d/%m/%Y").date()

        # Чтение файлов
        tasks = [
            asyncio.create_task(self.process_mer(file_mer, predict_date), name="proc_mer"),
            asyncio.create_task(self.process_geology(file_geology), name="proc_geo"),
        ]

        await asyncio.wait(tasks, return_when=asyncio.ALL_COMPLETED)

        results = []
        for task in tasks:
            results.append(task.result())

        df_mer, df_geo = results

        df_statistics = await self.create_stat_df(df_mer, predict_date)
        calculation_rec = {
            'predictDate': predict_date,
        }

        # Сначала загрузка всех данных для внешних ключей перед загрузкой МЭР
        # async with uow:
        #     # Сохранение геологии
        #     [await uow.geology.add_one(rec, check_dublicate=True) for rec in df_geo.to_dict(orient='records')]
        #     await uow.commit()

        # async with uow:
            # # Сохранение записей о будущем расчете и статистических данных
            # id_calc = await uow.calculations.add_one(calculation_rec, check_dublicate=True)
            #
            # df_statistics['calculate_id'] = 1
            # [await uow.statistics.add_one(rec, check_dublicate=True) for rec in df_statistics.to_dict(orient='records')]
            # await uow.commit()

        # Сохранение МЭР со всеми внешними ключами
        async with uow:
            df_mer['date'] = df_mer['date'].apply(to_date)

            geology = await uow.geology.find_all(mode='scheme', config_sort=[('well', True),], )
            geology_df = uow.geology.schemes_to_dataframe(geology)
            df_mer = df_mer.merge(geology_df[['id', 'well']], how='left', on='well')
            df_mer = df_mer.rename(columns={'id': 'geology_id'})

            pdb.set_trace()
            stats = await uow.statistics.find_all(mode='scheme', config_sort=[('well', True), ], )
            stats_df = uow.statistics.schemes_to_dataframe(stats)
            df_mer = df_mer.merge(stats_df[['id', 'well', 'date']], how='left', on=['well', 'date'])
            df_mer = df_mer.rename(columns={'id': 'statistics_id'})

            df_mer = df_mer.replace([np.nan, None], None)

            df_mer['calculate_id'] = 1

            [await uow.month_report.add_one(rec, check_dublicate=True) for rec in df_mer.to_dict(orient='records')]
            await uow.commit()

        return 1

    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        config_sort = [
            ('well', True),
            ('date', True),
        ]

        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      config_sort=config_sort,
                                      repository_name=self.repository_name,
                                      **filter_by,
                                      )
        return data
import pdb
from pathlib import Path

from celery.contrib import rdb
from fastapi import UploadFile, File

from exceptions.services import ServiceFileUploadException
from interfaces.service import BaseDataService

from logic.file_upload_processors.FileUploadProcessor import ExcelConverter
from logic.file_upload_processors.InclinometryFileUploadProcessor import InclinometryFileUploadProcess
from logic.utilities import chunk_list
from schemas.celery import UpdateProgressMeta
from tasks.progress_tracker import task_progress_tracker


class InclinometryService(BaseDataService):
    MAX_CHUNK_SIZE = 10000

    def __init__(self):
        super().__init__(repository_name='inclinometries')

    async def upload_inclinometry_file(self, uow, file_path: Path, task_id: str = None):
        async with uow:
            try:
                incl_df = InclinometryFileUploadProcess(ExcelConverter()).process(file_path)
            except Exception as e:
                raise ServiceFileUploadException(e)

            if task_id:
                task_progress_tracker.update_meta(
                    task_id=task_id,
                    data=UpdateProgressMeta(
                        alert_msg="Удаление старой инклинометрии",
                        current=75,
                        total=100,
                    )
                )

            [await uow.inclinometries.delete_all(well_name=well) for well in incl_df['well_name'].unique()]

            incl_recs = incl_df.to_dict(orient='records')
            num_chunk = 1
            if len(incl_recs) > self.MAX_CHUNK_SIZE:
                num_chunk = (len(incl_recs) // self.MAX_CHUNK_SIZE) + 1

            ids = [await self.insert_chunk_incl(uow, num, chunk) for num, chunk in enumerate(chunk_list(incl_recs, num_chunk))]
            ids = [id for sublist in ids for id in sublist]
            await uow.commit()
        return ids

    async def insert_chunk_incl(self, uow, num, chunk_incl, task_id: str = None):
        ids = [await uow.inclinometries.add_one(incl, check_dublicate=False) for incl in chunk_incl]
        if task_id:
            task_progress_tracker.update_meta(
                task_id=task_id,
                data=UpdateProgressMeta(
                    alert_msg="Загрузка инклинометрии",
                    current=80+(num+1)/self.MAX_CHUNK_SIZE*15,
                    total=100,
                )
            )
        return ids

    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        config_sort = [
            ('well_name', True),
            ('md', True),
        ]
        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      repository_name=repository_name,
                                      config_sort=config_sort,
                                      **filter_by,
                                      )
        return data




import pdb
from pathlib import Path

from fastapi import UploadFile, File

from exceptions.services import ServiceFileUploadException
from interfaces.service import BaseDataService
from logic.decorators import append_cells_coeffs_to_dataframe
from logic.file_upload_processors.FileUploadProcessor import ExcelConverter
from logic.file_upload_processors.TechmodeFileUploadProcessor import TechmodeFileUploadProcessor
from schemas.celery import UpdateProgressMeta
from services.monitoring import MonitoringService
from services.solids import SolidsService
from stratagies.LoadTable import fill_predict_pbg_column, stretch_techmodes_by_end_date
from tasks.progress_tracker import task_progress_tracker


class TechModeService(BaseDataService):
    def __init__(self):
        super().__init__(repository_name='techmodes')

    async def upload_by_file(self, uow, purpose_techmode, file_path: Path, task_id: str = None):
        async with uow:
            try:
                techmode_df = TechmodeFileUploadProcessor(
                    ExcelConverter(header=[*range(2)])
                ).process(file_path, purpose_techmode=purpose_techmode)
            except Exception as e:
                raise ServiceFileUploadException(e)

            if task_id:
                task_progress_tracker.update_meta(
                    task_id=task_id,
                    data=UpdateProgressMeta(
                        alert_msg="Добавление внешних ключей",
                        current=75,
                        total=100,
                    )
                )

            solids_df = await SolidsService().get_data(uow, result_type='dataframe')
            monitoring = await MonitoringService().get_data(uow, result_type='dataframe')

            techmode_df = techmode_df.merge(solids_df[['id', 'name']],
                                            left_on=['solid_name'],
                                            right_on=['name'], how='left')
            techmode_df = techmode_df.rename(columns={'id': 'solid_id'})
            techmode_df = techmode_df.drop(['solid_name', 'name'], axis=1)
            techmode_df = techmode_df[techmode_df["solid_id"].notna()]

            techmode_df = techmode_df.merge(monitoring[['id', 'well_name']], on='well_name')
            techmode_df = techmode_df.rename(columns={'id': 'well_id'})

            techmode_recs = techmode_df.to_dict(orient='records')

            ids = [await uow.techmodes.add_one(tm) for tm in techmode_recs]
            ids = [id for id in ids if id is not None]
            #await uow.commit()
            return ids

    @append_cells_coeffs_to_dataframe
    async def get_data(self, uow, result_type='scheme', readable=False, **filter_by):
        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      repository_name=self.repository_name,
                                      config_sort=[
                                        ('date', False),
                                        ('well_name', True),
                                      ],
                                      **filter_by,
                                      )
        return data

    async def update_predict_pbg_column(self, uow, pbg_df):
        techmode_df = await self.get_data(uow, result_type='dataframe')
        techmode_df = fill_predict_pbg_column(techmode_df, pbg_df)
        techmode_recs = techmode_df.to_dict(orient='records')

        async with uow:
            [await uow.techmodes.add_one(tm) for tm in techmode_recs]
            await uow.commit()

    async def get_actual_tech_modes(self, uow, pbg_df, begin_date, end_date, solid_id):
        tech_modes_df = await self.get_data(uow, result_type='dataframe', solid_id=solid_id,
                                            purpose='Нагнетательная')
        if end_date:
            tech_modes_df = stretch_techmodes_by_end_date(tech_modes_df, end_date)
        tech_modes_df = fill_predict_pbg_column(tech_modes_df.drop('bg_forecast_pressure', axis=1), pbg_df)
        if begin_date:
            tech_modes_df = tech_modes_df[(tech_modes_df['date'] >= begin_date)]
        return tech_modes_df


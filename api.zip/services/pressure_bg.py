import pdb

from fastapi import UploadFile, File

from api.web_socket_connection import wsOptionsManager
from interfaces.service import BaseDataService
from logic.file_upload_processors.FileUploadProcessor import ExcelConverter
from logic.file_upload_processors.PressureBGFileUploadProcessor import PressureBGFileUploadProcessor
from services.techmode import TechModeService


class PressureBGService(BaseDataService):
    def __init__(self):
        super().__init__(repository_name='pressure_bg')

    async def upload_pressure_bg_file(self, uow, file: UploadFile = File(...)):
        content = await file.read()
        dynamic_pbg_df = PressureBGFileUploadProcessor(ExcelConverter()).process(content)
        dynamic_pbg_recs = dynamic_pbg_df.to_dict(orient='records')

        async with uow:
            ids = [await uow.pressure_bg.add_one(rec, check_dublicate=True) for rec in dynamic_pbg_recs]
            ids = [id for id in ids if id is not None]
            await wsOptionsManager.broadcast("pads, kns")
            await uow.commit()

        dynamic_pbg_df = await self.get_data(uow, result_type='dataframe')
        await TechModeService().update_predict_pbg_column(uow, dynamic_pbg_df)
        return ids

    async def get_pads_names(self, uow):
        dynamic_pbg = await self.get_data(uow, result_type='dataframe')
        return dynamic_pbg['pad'].unique()

    async def get_kns_names(self, uow):
        dynamic_pbg = await self.get_data(uow, result_type='dataframe')
        return dynamic_pbg['kns'].unique()

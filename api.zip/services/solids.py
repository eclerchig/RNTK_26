import pdb

from interfaces.service import BaseDataService


class SolidsService(BaseDataService):

    def __init__(self):
        super().__init__(repository_name='solids')

    async def get_names(self, uow):
        async with uow:
            solids = await uow.solids.find_all(mode='scheme')
            df = uow.solids.schemes_to_dataframe(solids)
            sorted_df = df.sort_values(by="name")
            return sorted_df.name.unique()
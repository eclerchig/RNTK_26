import pdb

from fastapi import UploadFile, File
import pandas as pd

from exceptions.services import ServiceFileUploadException
from factories.UnitConverterFactory import UnitConverterFactory
from interfaces.service import BaseDataService, ServiceWorkException, AggregateFunctionEnum
from logic.decorators import append_cells_coeffs_to_dataframe
from logic.file_upload_processors.FileUploadProcessor import ExcelConverter
from logic.file_upload_processors.MonitoringFileUploadProcessor import \
    MonitoringWellsFileUploadProcessor, \
    MonitoringValuesFileUploadProcessor

from interfaces.DIContainer import service_container as services


class MonitoringService(BaseDataService):
    MAX_CHUNK_SIZE = 50000

    def __init__(self):
        super().__init__(repository_name='wells_monitoring')

    async def upload_monitoring_file(self, uow, user_id, file: UploadFile = File(...), delete_old_rows=False):
        content = await file.read()
        df = ExcelConverter(sheet_name="Мониторинг", header=0, skiprows=37).convert(content)
        async with uow:
            if delete_old_rows:
                await uow.wells_monitoring.reset_ai("id", 1)
                await uow.wells_monitoring.delete_all()
                await uow.prod_monitoring.reset_ai("id", 1)
                await uow.prod_monitoring.delete_all()

            wells_df = await services['wells'].get_data(uow, result_type='dataframe', times_changed=1)
            solids_df = await services['solids'].get_data(uow, result_type='dataframe')
            try:
                wells_monitoring_df = MonitoringWellsFileUploadProcessor().process(
                    df,
                    wells_df=wells_df,
                    solids_df=solids_df,
                    user_id=user_id
                )
            except Exception as e:
                raise ServiceFileUploadException(e)
            wells_m_recs = wells_monitoring_df.to_dict(orient='records')
            [await uow.wells_monitoring.add_one(well) for well in wells_m_recs]
            await uow.commit()

        async with uow:
            wells_monitoring_df = await self.get_data(uow, result_type='dataframe')

            try:
                prod_monitoring_df = MonitoringValuesFileUploadProcessor().process(
                    df,
                    wells_monitoring_df=wells_monitoring_df,
                    solids_df=solids_df,
                    user_id=user_id
                )
            except Exception as e:
                raise ServiceWorkException(e)
            prod_m_recs = prod_monitoring_df.to_dict(orient='records')
            [await uow.prod_monitoring.add_one(row) for row in prod_m_recs]
            await uow.commit()

    async def insert_chunk_prod(self, uow, num, chunk_prod):
        ids = [await uow.prod_monitoring.add_one(row) for row in chunk_prod]
        print(f"END LOAD {num} CHUNK")
        await uow.commit()

        return ids

    @append_cells_coeffs_to_dataframe
    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        repository_name = repository_name if repository_name else self.repository_name
        config_sort = [
            ('well_name', True),
            ('entry_date', False),
        ] if repository_name == 'wells_monitoring' else [
            ('date', False),
        ]
        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      repository_name=repository_name,
                                      config_sort=config_sort,
                                      **filter_by,
                                      )
        return data

    async def get_current_fund(self, uow, date_begin=None, date_end=None, **filter_by):
        monitoring_df = await self.get_data(uow, repository_name="prod_monitoring",
                                            result_type='dataframe', **filter_by)
        fund_df = pd.DataFrame([], columns=['date', 'prod_fund', 'inj_fund'])
        for dt in monitoring_df.sort_values(by='date')['date'].unique():
            m_by_dt = monitoring_df[monitoring_df['date'] == dt]
            if filter_by.get('cell_id'):
                prod_count = m_by_dt[(m_by_dt['oil_production'] > 0) & (m_by_dt['distance_coefficient'] > 0)].shape[0]
                inj_count = m_by_dt[(m_by_dt['water_injection'] > 0) & (m_by_dt['distance_coefficient'] > 0)].shape[0]
            else:
                prod_count = m_by_dt[m_by_dt['oil_production'] > 0].shape[0]
                inj_count = m_by_dt[m_by_dt['water_injection'] > 0].shape[0]
            fund_df.loc[len(fund_df.index)] = [dt, prod_count, inj_count]

        if date_begin and not date_end:
            fund_df = fund_df[(date_begin <= fund_df['date'])]
        if not date_begin and date_end:
            fund_df = fund_df[(fund_df['date'] <= date_end)]
        if date_begin and date_end:
            fund_df = fund_df[(date_begin <= fund_df['date']) & (fund_df['date'] <= date_end)]

        min_non_zero_date = min([row['date'] for idx, row in fund_df.iterrows() if
                                 row['prod_fund'] > 0.0 or row['inj_fund'] > 0.0])
        max_non_zero_date = max([row['date'] for idx, row in fund_df.iterrows() if
                                 row['prod_fund'] > 0.0 or row['inj_fund'] > 0.0])

        fund_df = fund_df[(fund_df['date'] >= min_non_zero_date) & (fund_df['date'] <= max_non_zero_date)]

        return fund_df

    @staticmethod
    async def get_data_for_graph(uow, column, unit, aggr_func, filters,
                                 getter_func, source_unit, converter_params):
        data_df = await getter_func(uow, filters)
        if unit != source_unit:
            unit_converter = UnitConverterFactory().get_converter(source_unit, unit,
                                                                  **converter_params)
            data_df[column] = data_df.apply(
                lambda row: unit_converter.convert(value=row[column], days=row['days']),
                axis=1
            )
        if filters.get('cell_id') and column not in ['inj_fund', 'prod_fund'] and not data_df.empty:
            data_df[column] = data_df.apply(lambda row: row[column] * row['distance_coefficient'], axis=1)
        data_df = data_df[['date', column]]

        # Использование агрегирующей функции
        if not data_df.empty:
            if aggr_func == AggregateFunctionEnum.sum:
                data_df = data_df.groupby(['date']).sum().reset_index()
            elif aggr_func == AggregateFunctionEnum.mean:
                data_df = data_df.groupby(['date']).mean().reset_index()
            elif aggr_func == AggregateFunctionEnum.median:
                data_df = data_df.groupby(['date']).median().reset_index()
            elif aggr_func == AggregateFunctionEnum.max:
                data_df = data_df.groupby(['date']).max().reset_index()
            elif aggr_func == AggregateFunctionEnum.min:
                data_df = data_df.groupby(['date']).min().reset_index()

        data_df['date'] = pd.to_datetime(data_df['date']).dt.strftime('%Y-%m-%d')
        data_df = data_df.rename(columns={column: 'value'})
        return data_df



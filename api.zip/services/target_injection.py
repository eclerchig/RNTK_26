import pdb

from interfaces.service import BaseDataService
from logic.decorators import append_cells_coeffs_to_dataframe
from stratagies.LoadTable import build_target_inj
from interfaces.DIContainer import service_container as services


class TargetInjectionService(BaseDataService):
    def __init__(self):
        super().__init__(repository_name='target_injections')

    async def calculate_target_injection(self, uow, user_id,
                                         begin_date, end_date, solid_name,
                                         prod_monitoring_df=None, react_fund=None,
                                         coeffs_df=None, cells_df=None,
                                         calc_by_cell=False):

        solid = await services['solids'].get_data(uow, result_type='dataframe', name=solid_name)
        solid_id = solid['id'].values[0]

        prod_monitoring_df = await services['monitoring'].get_data(
            uow, result_type='dataframe',
            solid_id=solid_id,
            repository_name='prod_monitoring',
        ) if prod_monitoring_df is None else prod_monitoring_df

        react_fund_df = await services['react_fund'].get_data(
            uow, result_type='dataframe',
            solid_id=solid_id,
        ) if react_fund is None else react_fund

        async with uow:
            coeffs_df = await services['participation_coefficient'].get_data(
                uow,
                result_type='dataframe',
                solid_id=solid_id,
                from_cell=calc_by_cell
            ) if coeffs_df is None else coeffs_df

            if calc_by_cell:
                cells_df = await services['cells'].get_data(
                    uow, result_type='dataframe',
                    repository_name='cells',
                    solid_id=solid_id
                )

            target_inj_df = await build_target_inj(
                prod_monitoring_df, coeffs_df, react_fund_df,
                begin_date, end_date, cells_df,
            )

            target_inj_df['user_id'] = user_id
            target_inj_recs = target_inj_df.to_dict(orient='records')

            [await uow.target_injections.add_one(row, check_dublicate=True) for row in target_inj_recs]
            await uow.commit()

    @append_cells_coeffs_to_dataframe
    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        return await super().get_data(uow, result_type=result_type, readable=readable,
                                      repository_name=repository_name,
                                      config_sort=[('date', False)], **filter_by)

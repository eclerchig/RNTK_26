import pdb

from celery import Celery
from celery.result import AsyncResult
from celery.signals import worker_ready
from celery.worker.consumer import Consumer
from starlette.responses import JSONResponse

from fastapi import APIRouter
from settings import settings
from services.OptionsStorage import optionsService

celery_app = Celery(
    'celery',
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=[
        'tasks.wells',
        'tasks.solids',
        'tasks.cells',
        'tasks.coeffs',
        'tasks.general',
        'tasks.inclinometry',
        'tasks.techmode',
        'tasks.perforations',
    ],
)
celery_app.conf.update(
    task_track_started=True,
    task_send_sent_event=True,
    worker_send_task_events=True,
    result_extended=True,
)

from celery.schedules import crontab

celery_app.conf.beat_schedule = {
    'add-every-monday-morning': {
        'task': 'tasks.general.cleanup_temp',
        'schedule': crontab(hour=7, minute=0),
    },
}

@worker_ready.connect
def refresh_options(sender: Consumer, **kwargs):
    import asyncio
    asyncio.run(optionsService().refresh_all_caches())
    optionsService()

router = APIRouter(prefix="/tasks", tags=["Celery tasks"])

@router.get("/{task_id}")
def get_status(task_id):
    task_result = AsyncResult(task_id, app=celery_app)
    result = {
        "task_id": task_id,
        "task_status": task_result.status,
    }
    return JSONResponse(result)
import pdb
from datetime import datetime
from fastapi import APIRouter, Depends
from schemas.celery import TaskResponse

from schemas.general import SchemeGetFile, SchemeGetData
from schemas.participation_coefficients import DataForCalculateInputScheme
from schemas.users import UsersSchemeGet

from api.dependencies import UOWDep
from api.users import get_current_user

from interfaces.DIContainer import service_container as services
from interfaces.unit_of_work import IUnitOfWork

from tasks.coeffs import \
calculate_participation_coefficients as calculate, \
get_participation_coefficients_file as get_file, \
get_participation_coefficients as get_data

router = APIRouter(
    prefix="/partcoeffs",
    tags=["ParticipationCoeff"]
)
solid_service = services['solids']
partcoeffs_service = services['participation_coefficient']

@router.get("")
async def get_participation_coeffs_by_ws(
        user_data: UsersSchemeGet = Depends(get_current_user),
        params: SchemeGetData = Depends(),
        uow: IUnitOfWork = UOWDep,
):
    result = get_data.delay(uow, user_data.id, params)
    return TaskResponse(
        task_id=result.id,
        created_at=datetime.now().isoformat(),
        status_task_url=f"/tasks/{result.id}",
    )

@router.post("/calc")
async def calc_coeffs(
        user_data: UsersSchemeGet = Depends(get_current_user),
        calc_params: DataForCalculateInputScheme = Depends(),
        uow: IUnitOfWork = UOWDep,
):
    result = calculate.delay(uow, user_data.id, calc_params)
    return TaskResponse(
        task_id=result.id,
        created_at=datetime.now().isoformat(),
        status_task_url=f"/tasks/{result.id}",
        result_task_url=f"/ws/tasks-result/{result.id}",
    )

@router.get("/file")
async def get_participation_coeffs_file_by_ws(
        user_data: UsersSchemeGet = Depends(get_current_user),
        params: SchemeGetFile = Depends(),
        uow: IUnitOfWork = UOWDep,
):
    result = get_file.delay(uow, user_data.id, params)
    return TaskResponse(
        task_id=result.id,
        created_at=datetime.now().isoformat(),
        status_task_url=f"/tasks/{result.id}",
        result_task_url=f"/ws/tasks-result/{result.id}",
    )

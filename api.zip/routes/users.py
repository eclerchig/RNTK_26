from __future__ import annotations

import pdb

from fastapi import APIRouter, Depends, HTTPException, status, Response, Request, Security, Cookie
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.responses import JSONResponse
from generated.version import APP_VERSION

from datetime import datetime, timezone

from interfaces.logging_ import user_id_ctx, user_logger, general_logger
from api.dependencies import UOWDep
from interfaces.unit_of_work import IUnitOfWork
from schemas.users import UserRegisterScheme, UsersSchemeGet

from logic.hash import get_password_hash, verify_password
from logic.jwt_generator import create_access_token, create_refresh_token, decode_jwt

from dotenv import load_dotenv

load_dotenv()

router = APIRouter(
    prefix="/users",
    tags=["Users"]
)

security = HTTPBearer()


class AuthentificationException(Exception):
    def __init__(self, description: str):
        self.description = f"Ошибка аутентификации: {description.lower()}"

    def __str__(self):
        return self.description


def validate_jwt_token(token, type):
    payload = decode_jwt(token, type=type)

    if not payload:
        raise AuthentificationException('Токен не валидный')

    expire = payload.get('exp')
    app_version = payload.get('app_version')
    expire_time = datetime.fromtimestamp(int(expire), tz=timezone.utc)
    if app_version != APP_VERSION:
        raise AuthentificationException("Токен от устаревшей версии программы")
    if (not expire) or (expire_time < datetime.now(timezone.utc)):
        raise AuthentificationException("У токена истек срок действия")
    return payload.get('sub')


async def get_current_user(
        uow: IUnitOfWork = UOWDep,
        credentials: HTTPAuthorizationCredentials = Security(security),
):
    token = credentials.credentials
    try:
        user = await check_user(token, uow)
        return user
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=e.__str__())


async def check_user(
        token: str,
        uow: IUnitOfWork,
):
    user = None
    try:
        user_id = validate_jwt_token(token, type="access")
        if not user_id:
            raise AuthentificationException('Не найден id пользователя')

        async with uow:
            user = await uow.users.find_one(mode='scheme', id=int(user_id))
            if not user:
                raise AuthentificationException('Пользователь не найден')
        user_id_ctx.set(user.id)
        user_logger.info("Access токен пользователя %s прошел проверку", user.login)
        return user
    except AuthentificationException as e:
        if user:
            user_logger.warning("Access токен пользователя не прошел проверку: %s", e.__str__())
        else:
            general_logger.warning("Access токен %s не прошел проверку: %s", token, e.__str__())
        raise


async def get_current_user_refresh(
        user_refresh_token=Cookie(default=None),
        uow: IUnitOfWork = UOWDep,
):
    user_id = None
    try:
        user_id = validate_jwt_token(user_refresh_token, type="refresh")
        if not user_id:
            raise Exception('Не найден id пользователя')
        async with uow:
            user = await uow.users.find_one(mode='scheme', id=int(user_id))
            if not user:
                raise Exception('Пользователь не найден')
            user_id_ctx.set(user.id)
            user_logger.info("Refresh токен пользователя %s прошел проверку", user.login)
            return user
    except Exception as e:
        if user_id:
            user_logger.warning("Refresh токен пользователя не прошел проверку: %s", e.__str__)
        else:
            general_logger.warning("Refresh токен %s не прошел проверку: %s", user_refresh_token, e.__str__)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=e.__str__)


async def get_current_admin_user(current_user: UsersSchemeGet = Depends(get_current_user)):
    if current_user.is_admin:
        return current_user
    user_logger.warning(
        "Попытка войти под учетной записью администратора пользователя %s: %s",
        current_user.id,
        current_user.login,
    )
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Нет прав администратора')


async def authenticate_user(uow: IUnitOfWork, login: str, password: str):
    async with uow:
        user = await uow.users.find_one(mode='scheme', login=login)

        if not user or not verify_password(plain_password=password, hashed_password=user.password):
            return None
        return user


@router.post("/register")
async def register_user(
        is_user: bool = True,
        is_admin: bool = False,
        data: UserRegisterScheme = Depends(),
        uow: IUnitOfWork = UOWDep,
):
    async with uow:
        user = await uow.users.find_one(login=data.login)
        if user:
            general_logger.warning(
                "Попытка регистрации пользователя с существующим логином %s",
                data.login,
            )
            # raise HTTPException(
            #     status_code=status.HTTP_409_CONFLICT,
            #     detail="Пользователь уже существует",
            # )
            return {'message': 'Пользователь с таким логином уже существует'}
        user_dict = data.dict()
        user_dict['password'] = get_password_hash(data.password)
        user_dict['is_user'] = is_user
        user_dict['is_admin'] = is_admin
        await uow.users.add_one(user_dict)
        await uow.commit()

    general_logger.info("Регистарция пользователя %s", data.login)
    return {'message': 'Регистрация прошла успешно'}


@router.post("/login")
async def auth_user(
        response: JSONResponse,
        request: Request,
        uow: IUnitOfWork = UOWDep,
):
    data = await request.json()
    user = await authenticate_user(uow, data['login'], data['password'])
    if user is None:
        general_logger.warning(
            "Неудачная попытка пользователя %s войти в систему через пароль",
            data.login,
        )
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail='Неверный логин или пароль')
    user_id_ctx.set(str(user.id))
    access_token = create_access_token({"sub": str(user.id)})
    refresh_token = create_refresh_token({"sub": str(user.id)})

    response.set_cookie(
        key="user_refresh_token",
        value=refresh_token,
        secure=False,
        httponly=True)

    user_logger.info("Авторизация пользователя %s", user.login)

    return {'access_token': access_token, 'user': {'login': user.login, 'is_admin': user.is_admin}}


@router.post("/logout")
async def logout_user(
        response: Response,
):
    response.delete_cookie(key='user_refresh_token')
    return {'message': 'Пользователь успешно вышел из системы'}


@router.get("/me")
async def get_me(user_data: UsersSchemeGet = Depends(get_current_user)):
    return {'user': user_data}


@router.get("/me_admin")
async def get_me(user_data: UsersSchemeGet = Depends(get_current_admin_user)):
    return {'user': user_data}


@router.post("/refresh")
async def refresh_access_token(
        response: Response,
        user_refresh_token=Cookie(default=None),
        user_data: UsersSchemeGet = Depends(get_current_user_refresh),
):
    access_token = create_access_token({"sub": str(user_data.id)})

    response.set_cookie(
        key="user_refresh_token",
        value=user_refresh_token,
        secure=False,
        httponly=True)

    user_logger.info("Пересоздан токен доступа для пользователя %s", user_data.login)
    return {'access_token': access_token, 'user': {'login': user_data.login, 'is_admin': user_data.is_admin}}

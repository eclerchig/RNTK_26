# from fastapi import Depends
#
# from api.interfaces.unit_of_work import UnitOfWork
#
# UOWDep = Depends(UnitOfWork)
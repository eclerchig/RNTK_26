import asyncio
import pdb
from logging import Logger

from celery.result import AsyncResult
from fastapi import APIRouter
from starlette import status
from starlette.websockets import WebSocket, WebSocketState
from websockets.exceptions import ConnectionClosedOK

from api.celery import celery_app
from api.dependencies import UOWDep
from api.users import AuthentificationException, check_user
from api.web_socket_connection import WSConnectionManager
from exceptions.routes import DoesntExistCeleryTask
from interfaces.exception import APIException
from interfaces.logging_ import general_logger, user_logger, user_id_ctx
from interfaces.unit_of_work import IUnitOfWork
from logic.chunk_manager import chunk_storage
from tasks.progress_tracker import task_progress_tracker

router = APIRouter(
    tags=["WebSocket Routes"]
)
WS_manager = WSConnectionManager()

files_extentions = {
    'excel': '.xlsx',
    'csv': '.csv',
}

@router.websocket("/ws/tasks-result-chunks/{task_id}")
async def get_data_chunks_by_ws(
        websocket: WebSocket,
        task_id: str,
        uow: IUnitOfWork = UOWDep,
):
    """
    Отдельный WebSocket route для получения данных чанками, которые обрабатываются Celery
    """
    close_code = status.WS_1000_NORMAL_CLOSURE
    logger = general_logger
    try:
        await websocket.accept()
        token = await websocket.receive_text()
        await check_user(token, uow)
        logger = user_logger if user_id_ctx.get() is not None else general_logger
        logger.info(
            "[НАЧАЛО] Запрос WEBSOCKET %s, path параметры: %s, query параметры: %s",
            str(websocket.url),
            str(websocket.path_params),
            str(dict(websocket.query_params)),
        )
        task_result = AsyncResult(task_id, app=celery_app)

        if not task_result.id:
            raise DoesntExistCeleryTask(task_id=task_id)

        last_alert_msg = ""
        task_completed = False
        while not task_completed:
            task_result = AsyncResult(task_id, app=celery_app)
            task_meta = task_progress_tracker.get_meta(task_id)
            current_status = task_result.status

            if task_meta:
                alert_msg = task_meta.get("alert_msg", "") + str(task_meta.get("current", ""))
                # Если это информация о прогрессе
                if task_meta.get("type", None) == "progress" and alert_msg != last_alert_msg:
                    await websocket.send_json({
                        "type": "progress",
                        "task_id": task_id,
                        "alert_msg": task_meta.get("alert_msg", ""),
                        "current": task_meta.get("current", 0),
                        "total": task_meta.get("total", 0),
                        "status": current_status
                    })
                    last_alert_msg = alert_msg

            if current_status == "SUCCESS":
                task_completed = True
                all_chunks = chunk_storage().get_all_cache_chunks(task_id)
                await websocket.send_json({
                    "type": "metadata",
                    "task_id": task_id,
                    "file_name": task_meta.get("file_name", "") + files_extentions.get(task_meta.get("file_type", ""), ""),
                    "total_chunks": task_meta.get("total_chunks", ""),
                })
                begin_current = float(task_meta.get("begin_current", 0))
                for chunk_id, chunk in enumerate(all_chunks.values()):
                    current = begin_current+(int(chunk_id)+1)/len(all_chunks)*(100-begin_current)
                    await websocket.send_json({
                        "type": "chunk",
                        "task_id": task_id,
                        "chunk_index": int(chunk_id),
                        "data": chunk,
                        "alert_msg": f"Отправка данных завершена на {current:.2f}%" if chunk != '[]' else None,
                        "current": round(current, 2) if chunk != '[]' else None
                    })
                    await asyncio.sleep(0.001)
                await websocket.send_json({
                    "type": "complete",
                })
                chunk_storage().cleanup_cache(task_id)

            elif current_status == "FAILURE":
                task_completed = True
                chunk_storage().cleanup_local(task_id)
                chunk_storage().cleanup_cache(task_id)
                meta = task_result._get_task_meta()

                if 'result' in meta and isinstance(meta['result'], Exception):
                    exc = meta['result']
                    await websocket.send_json({
                        "type": "error",
                        "user_friendly": exc.is_user_friendly if isinstance(exc, APIException) else False,
                        "message": exc.__str__(),
                    })
                else:
                    await websocket.send_json({
                        "type": "error",
                        "user_friendly": False,
                        "message": None,
                    })
            else:
                await asyncio.sleep(0.5)
    except AuthentificationException:
        close_code = status.WS_1008_POLICY_VIOLATION
    except Exception as e:
        if not isinstance(e, ConnectionClosedOK):
            await send_error(e, websocket, logger)
        close_code = status.WS_1011_INTERNAL_ERROR
    finally:
        logger.info(
            "[КОНЕЦ] Запрос WEBSOCKET %s, path параметры: %s, query параметры: %s",
            str(websocket.url),
            str(websocket.path_params),
            str(dict(websocket.query_params)),
        )
        await websocket.close(code=close_code)


@router.websocket("/ws/tasks-result/{task_id}")
async def get_data_chunks_by_ws(
        websocket: WebSocket,
        task_id: str,
        uow: IUnitOfWork = UOWDep,
):
    """
    Отдельный WebSocket route для получения данных прогресса
    """
    close_code = status.WS_1000_NORMAL_CLOSURE
    logger = general_logger
    try:
        await websocket.accept()
        token = await websocket.receive_text()
        await check_user(token, uow)
        logger = user_logger if user_id_ctx.get() is not None else general_logger
        logger.info(
            "[НАЧАЛО] Запрос WEBSOCKET %s, path параметры: %s, query параметры: %s",
            str(websocket.url),
            str(websocket.path_params),
            str(dict(websocket.query_params)),
        )
        task_result = AsyncResult(task_id, app=celery_app)

        if not task_result.id:
            raise DoesntExistCeleryTask(task_id=task_id)

        last_alert_msg = ""
        task_completed = False
        while not task_completed:
            task_result = AsyncResult(task_id, app=celery_app)
            task_meta = task_progress_tracker.get_meta(task_id)
            current_status = task_result.status

            if task_meta:
                alert_msg = task_meta.get("alert_msg", "") + str(task_meta.get("current", ""))
                # Если это информация о прогрессе
                if task_meta.get("type", None) == "progress" and alert_msg != last_alert_msg:
                    await websocket.send_json({
                        "type": "progress",
                        "task_id": task_id,
                        "alert_msg": task_meta.get("alert_msg", ""),
                        "current": task_meta.get("current", 0),
                        "total": task_meta.get("total", 0),
                        "status": current_status
                    })
                    last_alert_msg = alert_msg

            if current_status == "SUCCESS":
                task_completed = True
                await websocket.send_json({
                    "type": "complete",
                })
            elif current_status == "FAILURE":
                task_completed = True
                meta = task_result._get_task_meta()
                if 'result' in meta and isinstance(meta['result'], Exception):
                    exc = meta['result']
                    await websocket.send_json({
                        "type": "error",
                        "user_friendly": exc.is_user_friendly if isinstance(exc, APIException) else False,
                        "message": exc.__str__(),
                    })
                else:
                    await websocket.send_json({
                        "type": "error",
                        "user_friendly": False,
                        "message": None,
                    })
            else:
                await asyncio.sleep(0.1)
    except AuthentificationException:
        close_code = status.WS_1008_POLICY_VIOLATION
    except Exception as e:
        if not isinstance(e, ConnectionClosedOK):
            await send_error(e, websocket, logger)
        close_code = status.WS_1011_INTERNAL_ERROR
    finally:
        logger.info(
            "[КОНЕЦ] Запрос WEBSOCKET %s, path параметры: %s, query параметры: %s",
            str(websocket.url),
            str(websocket.path_params),
            str(dict(websocket.query_params)),
        )
        await websocket.close(code=close_code)

async def send_error(exc: Exception, websocket: WebSocket, logger: Logger):
    if websocket.client_state != WebSocketState.DISCONNECTED:
        await websocket.send_json({
            "type": "error",
            "user_friendly": isinstance(exc, APIException) and exc.is_user_friendly,
            "message": str(exc),
        })
    if logger and isinstance(exc, APIException):
        if exc.is_user_friendly:
            logger.warning(exc.log())
        else:
            logger.exception(exc.log())
    elif logger:
        logger.exception(exc)
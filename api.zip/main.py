import datetime
import os
import pdb
from typing import Dict, Optional

from fastapi import FastAPI, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi import UploadFile
from starlette.responses import JSONResponse

from api.services.DataProcessService import DataProcessService

# from interfaces.unit_of_work import IUnitOfWork
# from routes.dependencies import UOWDep

app = FastAPI()
#DATABASE_URL = os.getenv("DATABASE_URL_POSTGRES")
# origins = os.getenv("ORIGINS").split(";")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Response-For-User"]
)


# @app.on_event("startup")
# async def on_startup():
#     await database.connect()


# @app.on_event("shutdown")
# async def shutdown():
#     await database.disconnect()


@app.get("/test")
async def test():
    return {"status": "Working"}


@app.get("/routes")
async def get_routes():
    routes = {}
    for route in app.routes:
        routes[route.path] = {
            'methods': getattr(route, 'methods', 'N/A'),
            'name': getattr(route, 'name', 'N/A'),
            'endpoint': getattr(route, 'endpoint', 'N/A'),
        }
    return routes

@app.post("/files")
async def upload_data(
    predict_date: datetime.date,
    file_mer: UploadFile = File(...),
    file_geology: UploadFile = File(...),
):
    df = await DataProcessService().process_file(predict_date, file_mer, file_geology)
    return JSONResponse(status_code=200, content=df.to_json(orient='records'))

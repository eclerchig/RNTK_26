import datetime
import math
import os
import pdb

from fastapi import FastAPI, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi import UploadFile
from starlette.responses import JSONResponse

from database.session import init_models, async_engine
from services.DataProcessService import DataProcessService
from interfaces.unit_of_work import IUnitOfWork
from routes.dependencies import UOWDep


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Response-For-User"]
)

@app.on_event("startup")
async def on_startup():
    await init_models()

@app.on_event("shutdown")
async def shutdown():
    await async_engine.dispose()


@app.get("/test")
async def test():
    return {"status": "Working"}


@app.get("/routes")
async def get_routes():
    routes = {}
    for route in app.routes:
        routes[route.path] = {
            'methods': getattr(route, 'methods', 'N/A'),
            'name': getattr(route, 'name', 'N/A'),
            'endpoint': getattr(route, 'endpoint', 'N/A'),
        }
    return routes

def clean_float(value):
    """Заменяет NaN и Infinity на None (в JSON станет null)"""
    if value is None:
        return None
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
    return value

# Применяем ко всем полям объекта
def clean_data(obj):
    if isinstance(obj, dict):
        return {k: clean_data(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [clean_data(item) for item in obj]
    elif isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    else:
        return obj

@app.post("/files")
async def upload_data(
    predict_date: datetime.date = Form(...),
    file_mer: UploadFile = File(...),
    file_geology: UploadFile = File(...),
    uow: IUnitOfWork = UOWDep,
):
    #calculate_id = await DataProcessService().process_file(uow, predict_date, file_mer, file_geology)
    data = await DataProcessService().get_data(uow, result_type='dict', calculate_id=1, is_calculated=False)
    data = clean_data(data)
    return data

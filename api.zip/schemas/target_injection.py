from pydantic import BaseModel, validator
from pydantic.schema import Optional
from datetime import date

from logic.dictionary_enums import SolidEnum, WellPurposeEnum


class DataForCalculateInputScheme(BaseModel):
    class Config:
        use_enum_values = True
    calc_coeffs: bool
    begin_monitoring: date
    end_monitoring: date
    solid: str


class TargetInjectionScheme(BaseModel):
    class Config:
        use_enum_values = True
    well_id: Optional[int]
    well_name: str
    solid_id: int
    cell_id: Optional[int]
    date: date
    target_inj: float
    from_cell: bool
    purpose: WellPurposeEnum
    user_id: int

    @validator("well_name", pre=True)
    def validate_null_name(cls, well: str, values: dict):
        if well is None:
            raise ValueError(f"Пропущенное значение имени скважины")
        return well

    @validator("solid_id", pre=True)
    def validate_null_solid_id(cls, solid_id: int, values: dict):
        if solid_id is None:
            raise ValueError(f"Пропущенное значение в id пласта для скважины {values.get('well_name')}")
        return solid_id

    @validator("date", pre=True)
    def validate_null_date(cls, dt: date, values: dict):
        if dt is None:
            raise ValueError(f"Пропущенное значение в дате для скважины {values.get('well_name')}")
        return dt

    @validator("user_id", pre=True)
    def validate_null_user(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id пользователя")
        return id


class TargetInjectionSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    well_id: int
    well_name: str
    purpose: WellPurposeEnum
    solid_id: int
    solid_name: SolidEnum
    cell_id: Optional[int]
    cell_name: Optional[str]
    date: date
    target_inj: float
    from_cell: bool

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'well_id': 'ID скважины',
            'well_name': 'Скважина',
            'solid_id': 'ID пласта',
            'solid_name': 'Пласт',
            'date': 'Дата',
            'target_inj': 'Целевая закачка, м3/сут',
            'from_cell': 'Расчет по ячейкам',
            'purpose': 'Назначение скважины',
            'cell_id': 'ID ячейки',
            'cell_name': 'Ячейка',
        }
import pdb

from pydantic import BaseModel, validator
from datetime import date
from pydantic.schema import Optional
import pandas as pd

from logic.dictionary_enums import SolidEnum


class PotentialInjectionScheme(BaseModel):
    well_id: Optional[int]
    well_name: str
    solid_id: int
    techmode_id: int
    date: date
    pickup_rate_coefficient: Optional[float]
    agrp_pressure: Optional[float]
    downhole_press_agrp: Optional[float]
    inj_agrp_potential: Optional[float]
    pressure_margin_infr: Optional[float]
    downhole_press_infr_potential: Optional[float]
    inj_infr_potential: Optional[float]
    user_id: int

    @validator("well_name", pre=True)
    def validate_null_name(cls, well: str, values: dict):
        if well is None:
            raise ValueError(f"Пропущенное значение имени скважины")
        return well

    @validator("solid_id", pre=True)
    def validate_null_solid_id(cls, solid_id: int, values: dict):
        if solid_id is None:
            raise ValueError(f"Пропущенное значение в id пласта для скважины {values.get('well_name')}")
        return solid_id

    @validator("techmode_id", pre=True)
    def validate_null_techmode_id(cls, techmode_id: int, values: dict):
        if techmode_id is None:
            raise ValueError(f"Пропущенное значение в id записи техрежима для скважины {values.get('well_name')}")
        return techmode_id

    @validator("date", pre=True)
    def validate_null_date_drilled(cls, dt: date, values: dict):
        if dt is None:
            raise ValueError(f"Пропущенное значение в дате для скважины {values.get('well_name')}")
        return dt

    @validator("user_id", pre=True)
    def validate_null_user(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id пользователя")
        return id


class PotentialInjectionSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    well_id: Optional[int]
    well_name: str
    solid_id: int
    solid_name: SolidEnum
    techmode_id: int
    date: date
    pickup_rate_coefficient: Optional[float]
    agrp_pressure: Optional[float]
    downhole_press_agrp: Optional[float]
    inj_agrp_potential: Optional[float]
    pressure_margin_infr: Optional[float]
    downhole_press_infr_potential: Optional[float]
    inj_infr_potential: Optional[float]

    @validator("well_id", "pickup_rate_coefficient", "agrp_pressure", "downhole_press_agrp", "inj_agrp_potential",
               "pressure_margin_infr", "downhole_press_infr_potential", "inj_infr_potential", pre=False)
    def check_NaN(cls, val: float):
        if pd.isnull(val):
            val = None
        return val

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'well_id': 'ID скважины',
            'well_name': 'Скважина',
            'solid_id': 'ID пласта',
            'solid_name': 'Пласт',
            'techmode_id': 'ID строки тех. режима',
            'date': 'Дата',
            'pickup_rate_coefficient': 'Кпр',
            'agrp_pressure': 'Давление АГРП, атм',
            'downhole_press_agrp': 'Рзаб потенциал АГРП, атм',
            'inj_agrp_potential': 'Qзак потенциал АГРП, м3/сут',
            'pressure_margin_infr': 'dРинфр, атм',
            'downhole_press_infr_potential': 'Рзаб потенциал инфр, атм',
            'inj_infr_potential': 'Qзак потенциал инфр, м3/сут',
        }
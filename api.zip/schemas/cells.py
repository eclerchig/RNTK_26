from typing import Optional

from pydantic import BaseModel, validator
from datetime import date

from logic.dictionary_enums import SolidEnum


class CellsScheme(BaseModel):
    name: str
    solid_id: int
    purpose_comp_coeff: Optional[float]

    # TO DO: найти способ привести к DRY-принципу
    @validator("name", pre=True)
    def validate_null_name(cls, cell: str, values: dict):
        if cell is None:
            raise ValueError(f"Пропущенное значение в названии ячейки")
        return cell

    @validator("solid_id", pre=True)
    def validate_null_solid_id(cls, solid_id: date, values: dict):
        if solid_id is None:
            raise ValueError(f"Пропущенное значение в id объекта")
        return solid_id


class CellsSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    name: str
    solid_id: int
    solid_name: SolidEnum
    purpose_comp_coeff: Optional[float]

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'name': 'Ячейка',
            'solid_id': 'ID объекта',
            'solid_name': 'Объект',
            'purpose_comp_coeff': 'Целевой коэффициент компенсации'
        }


class CellPolygonsScheme(BaseModel):
    cell_id: int
    order: int
    x: float
    y: float

    # TO DO: найти способ привести к DRY-принципу
    @validator("cell_id", pre=True)
    def validate_cell_id(cls, cell_id: int, values: dict):
        if cell_id is None:
            raise ValueError(f"Пропущенное значение в id ячейки")
        return cell_id

    @validator("x", pre=True)
    def validate_null_x(cls, x: float, values: dict):
        if x is None:
            raise ValueError(f"Пропущенное значение в координате Х для ячейки c id {values['cell_id']}")
        return x

    @validator("y", pre=True)
    def validate_null_y(cls, y: float, values: dict):
        if y is None:
            raise ValueError(f"Пропущенное значение в координате Y для ячейки c id {values['cell_id']}")
        return y

    @validator("order", pre=True)
    def validate_null_solid_id(cls, order: int, values: dict):
        if order is None:
            raise ValueError(f"Пропущенное значение в порядковом номере точки полигона")
        return order


class CellPolygonsSchemeGet(BaseModel):
    id: int
    cell_id: int
    cell_name: str
    order: int
    x: float
    y: float

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'cell_id': 'ID Ячейки',
            'cell_name': 'Ячейка',
            'order': 'Номер точки',
            'x': 'Координата Х, м',
            'y': 'Координата Y, м',
        }
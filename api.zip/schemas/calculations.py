from datetime import date, datetime

from typing import Optional, Dict, Any

from pydantic import BaseModel, ConfigDict


class CalculationsScheme(BaseModel):
    name: Optional[str] = None
    createAt: datetime = datetime.now()
    predictDate: date
    gtm: Optional[Dict[str, Any]] = None

class CalculationsSchemeGet(BaseModel):
    id: int
    name: Optional[str] = None
    createAt: datetime
    predictDate: date
    gtm: Optional[Dict[str, Any]] = None

    model_config = ConfigDict(from_attributes=True)
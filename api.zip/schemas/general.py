from typing import Optional, Type, Any

from celery.contrib import rdb
from pydantic import BaseModel, validator
from datetime import date

from logic.dictionary_enums import FileExtentionsEnum
from services.OptionsStorage import optionsService


class SchemeGetFile(BaseModel):
    class Config:
        use_enum_values = True
    well: Optional[str]
    solid: Optional[str]
    cell: Optional[str]
    start_date: Optional[date]
    end_date: Optional[date]
    well_purpose: Optional[str]
    file_type: FileExtentionsEnum

    @validator("well")
    @classmethod
    def validate_well(cls, well: str):
        if well:
            well_id = optionsService().check_value_in_options(well, 'wells')
            if not well_id:
                raise ValueError(f"Нет данных по скважине {well}. Обновите данные в Справочнике скважин")
        return well

    @validator("solid")
    @classmethod
    def validate_solid(cls, solid: str):
        if solid:
            solid_id = optionsService().check_value_in_options(solid, 'solids')
            if not solid_id:
                raise ValueError(f"Нет данных по объекту {solid}")
        return solid

    @validator("cell")
    @classmethod
    def validate_cell(cls, cell: str):
        if cell:
            cell_id = optionsService().check_value_in_options(cell, 'cells')
            if not cell_id:
                raise ValueError(f"Нет данных по ячейке {cell}")
        return cell

    @validator("well_purpose")
    @classmethod
    def validate_purpose(cls, well_purpose: str):
        if well_purpose:
            id = optionsService().check_value_in_options(well_purpose, 'well_purposes')
            if not id:
                raise ValueError(f"Не существует назначения {well_purpose} в мониторинге")
        return well_purpose

class SchemeGetData(BaseModel):
    well: Optional[str]
    solid: Optional[str]
    cell: Optional[str]
    start_date: Optional[date]
    end_date: Optional[date]
    well_purpose: Optional[str]

    @validator("well")
    @classmethod
    def validate_well(cls, well: str):
        if well:
            well_id = optionsService().check_value_in_options(well, 'wells')
            if not well_id:
                raise ValueError(f"Нет данных по скважине {well}. Обновите данные в Справочнике скважин")
        return well

    @validator("solid")
    @classmethod
    def validate_solid(cls, solid: str):
        if solid:
            solid_id = optionsService().check_value_in_options(solid, 'solids')
            if not solid_id:
                raise ValueError(f"Нет данных по объекту {solid}")
        return solid

    @validator("cell")
    @classmethod
    def validate_cell(cls, cell: str):
        if cell:
            cell_id = optionsService().check_value_in_options(cell, 'cells')
            if not cell_id:
                raise ValueError(f"Нет данных по ячейке {cell}")
        return cell

    @validator("well_purpose")
    @classmethod
    def validate_purpose(cls, well_purpose: str):
        if well_purpose:
            id = optionsService().check_value_in_options(well_purpose, 'well_purposes')
            if well_purpose and not id:
                raise ValueError(f"Не существует назначения {well_purpose} в мониторинге")
        return well_purpose

from pydantic import BaseModel, validator
from datetime import date


class PressureBgScheme(BaseModel):
    kns: str
    pad: str
    date: date
    pressure_bg: float

    # TO DO: найти способ привести к DRY-принципу
    @validator("kns", pre=True)
    def validate_null_kns(cls, kns: str, values: dict):
        if kns is None:
            raise ValueError(f"Пропущенное значение в названии КНС")
        return kns

    @validator("pad", pre=True)
    def validate_null_pad(cls, pad: str, values: dict):
        if pad is None:
            raise ValueError(f"Пропущенное значение в названии куста")
        return pad

    @validator("date", pre=True)
    def validate_null_date(cls, date: date, values: dict):
        if date is None:
            raise ValueError(f"Пропущенное значение в значении даты")
        return date

    @validator("pressure_bg", pre=True)
    def validate_null_pressure_bg(cls, pressure_bg: float, values: dict):
        if pressure_bg is None:
            raise ValueError(f"Пропущенное значение в значении РнаБГ")
        return pressure_bg


class PressureBgSchemeGet(BaseModel):
    id: int
    kns: str
    pad: str
    date: date
    pressure_bg: float

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'kns': 'КНС',
            'pad': 'Куст',
            'date': 'Дата',
            'pressure_bg': 'Рбг, атм',
        }
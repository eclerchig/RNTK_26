from typing import Optional

from pydantic import BaseModel

class TaskResponse(BaseModel):
    task_id: str
    created_at: str
    status_task_url: str
    result_task_url: Optional[str]

class UpdateInfoMeta(BaseModel):
    type = "metadata"
    file_name: Optional[str]
    file_type: Optional[str]
    total_chunks: Optional[str]
    begin_current: Optional[float]

class UpdateProgressMeta(BaseModel):
    type = "progress"
    alert_msg: Optional[str]
    current: Optional[float]
    total: Optional[float]


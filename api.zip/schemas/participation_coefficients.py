from pydantic import BaseModel, validator
from datetime import date

from logic.dictionary_enums import SolidEnum


class DataForCalculateInputScheme(BaseModel):
    class Config:
        use_enum_values = True
    begin_monitoring: date
    end_monitoring: date
    solid_name: SolidEnum
    react_radius: float
    last_fact_date: date = None
    auto_react_fund: bool
    calc_by_cells: bool
    delete_zero_coeff: bool
    purpose_center: str


class ParticipationCoefficientsScheme(BaseModel):
    react_fund_id: int = None
    center_well_id: int
    around_well_id: int = None
    solid_id: int
    cell_id: int = None
    date: date
    distance: float = 0.0
    distance_coefficient: float = 0.0
    correlation_coefficient: float = 0.0
    from_cell: bool = False
    user_id: int

    # TO DO: найти способ привести к DRY-принципу

    @validator("center_well_id", pre=True)
    def validate_null_center_well_id(cls, center_well_id: int, values: dict):
        if center_well_id is None:
            raise ValueError(f"Пропущенное значение в id для центральной скважины")
        return center_well_id

    @validator("solid_id", pre=True)
    def validate_null_solid_id(cls, solid_id: int, values: dict):
        if solid_id is None:
            raise ValueError(f"Пропущенное значение в id объекта")
        return solid_id

    @validator("date", pre=True)
    def validate_null_date(cls, date: date, values: dict):
        if date is None:
            raise ValueError(f"Пропущенное значение в дате")
        return date

    @validator("distance_coefficient", pre=True)
    def validate_null_distance_coefficient(cls, distance_coefficient: float, values: dict):
        if distance_coefficient is None:
            raise ValueError(f"Пропущенное значение коэффициента участия расстояния")
        return round(distance_coefficient, 3)


class ParticipationCoefficientsSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    react_fund_id: int = None
    solid_id: int
    solid_name: SolidEnum
    cell_id: int = None
    cell_name: str = None
    date: date
    distance: float = 0.0
    distance_coefficient: float
    correlation_coefficient: float = 0.0
    center_well_id: int
    center_well: str
    around_well_id: int = None
    around_well: str = None
    center_well_purpose: str
    from_cell: bool

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'react_fund_id': 'ID строки реагирующего фонда',
            'solid_id': 'ID объекта',
            'solid_name': 'Объект',
            'cell_id': 'ID ячейки',
            'cell_name': 'Ячейка',
            'date': 'Дата',
            'distance': 'Дистанция, м',
            'distance_coefficient': 'Коэффициент расстония',
            'correlation_coefficient': 'Коэффициент корреляции',
            'center_well_id': 'ID центральной скважины',
            'center_well': 'Центральная скважина',
            'around_well_id': 'ID влияющей скважины',
            'around_well': 'Влияющая скважина',
            'center_well_purpose': 'Назначение центральной скважины',
            'from_cell': 'Фонд из ячеек',
        }
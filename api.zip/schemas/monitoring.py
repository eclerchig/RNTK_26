import pdb

from pydantic import BaseModel, validator
from pydantic.schema import Optional
from datetime import date
import pandas as pd
import numpy as np

from logic.dictionary_enums import SolidEnum, WellPurposeEnum


class WellsMonitoringScheme(BaseModel):
    class Config:
        use_enum_values = True
    well_id: Optional[int]
    well_name: str
    purpose: WellPurposeEnum
    solid_id: int
    entry_date: date
    ppd_conversion_date: Optional[date]
    user_id: int

    # TO DO: найти способ привести к DRY-принципу
    @validator("well_name", pre=True)
    def validate_null_name(cls, well: str, values: dict):
        if well is None:
            raise ValueError(f"Пропущенное значение имени скважины")
        return well

    @validator("solid_id", pre=True)
    def validate_null_solid_id(cls, solid_id: int, values: dict):
        if solid_id is None:
            raise ValueError(f"Пропущенное значение в id пласта для скважины {values.get('well_name')}")
        return solid_id

    @validator('well_id', pre=True)
    def handle_pandas_na_well_id(cls, val):
        return None if pd.isna(val) else val

    @validator("purpose", pre=True)
    def validate_null_char_work(cls, purpose: str, values: dict):
        if purpose is None:
            raise ValueError(f"Пропущенное значение в назначении для скважины {values.get('well_name')}")
        return purpose

    @validator("entry_date", pre=True)
    def validate_null_entry_date(cls, entry_date: date, values: dict):
        if entry_date is None:
            raise ValueError(f"Пропущенное значение в дате бурения для скважины {values.get('well_name')}")
        return entry_date

    @validator("user_id", pre=True)
    def validate_null_user(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id пользователя")
        return id


class WellsMonitoringSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    well_id: Optional[int]
    well_name: str
    solid_id: int
    solid_name: SolidEnum
    purpose: WellPurposeEnum
    entry_date: date
    ppd_conversion_date: Optional[date]

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'well_id': 'ID скважины',
            'well_name': 'Скважина',
            'solid_id': 'ID пласта',
            'solid_name': 'Пласт',
            'purpose': 'Назначение',
            'entry_date': 'Дата ввода',
            'ppd_conversion_date': 'Перевод в ППД',
        }


class ProductionMonitoringScheme(BaseModel):
    well_id: int
    solid_id: int
    date: date
    oil_production: Optional[float]
    liquid_production: Optional[float]
    gas_production: Optional[float]
    water_injection: Optional[float]
    reservoir_sampling: Optional[float]
    days: float
    user_id: int

    # TO DO: найти способ привести к DRY-принципу
    @validator("well_id", pre=True)
    def validate_null_name(cls, id: int, values: dict):
        if id is None:
            raise ValueError("Пропущенный id для скважины из мониторинга")
        return id

    @validator("solid_id", pre=True)
    def validate_null_solid(cls, solid_id: int, values: dict):
        if solid_id is None:
            raise ValueError(f"Пропущенное значение в id пласта для скважины {values.get('well_name')}")
        return solid_id

    @validator("date", pre=True)
    def validate_null_date(cls, date: str, values: dict):
        if date is None:
            raise ValueError(f"Пропущенное значение даты для скважины {values.get('name')}")
        return date

    @validator("days", pre=True)
    def validate_null_days(cls, days: str, values: dict):
        if days is None:
            raise ValueError(f"Пропущенное значение количества дней в работе для скважины {values.get('name')}")
        return days

    @validator("user_id", pre=True)
    def validate_null_user(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id пользователя")
        return id


class ProductionMonitoringSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    well_id: int
    well_name: str
    solid_id: int
    solid_name: SolidEnum
    date: date
    oil_production: Optional[float]
    liquid_production: Optional[float]
    gas_production: Optional[float]
    water_injection: Optional[float]
    reservoir_sampling: Optional[float]
    days: float

    @validator('*', pre=True)
    def convert_nan_to_zero(cls, v):
        if isinstance(v, float):
            if v is None or np.isnan(v) or pd.isna(v):
                v = 0
        return v

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'well_id': 'ID скважины',
            'well_name': 'Скважина',
            'solid_id': 'ID пласта',
            'solid_name': 'Пласт',
            'date': 'Дата',
            'oil_production': 'Добыча нефти, тыс. тн',
            'liquid_production': 'Добыча жидкости, тыс. тн',
            'gas_production': 'Добыча газа, млн. м3',
            'water_injection': 'Закачка воды, тыс. м3',
            'reservoir_sampling': 'Отбор в пластовых условиях, м3/сут',
            'days': 'Количество дней',
        }
from pydantic import BaseModel, validator
from pydantic.schema import Optional
from datetime import date
import pandas as pd

from logic.dictionary_enums import SolidEnum


class PerforationsScheme(BaseModel):
    well_id: Optional[int]
    well_name: str
    solid_id: Optional[int]
    date: date
    perforation_kind: str
    perforation_code: Optional[str]
    top_interval_depth: float
    bottom_interval_depth: float
    number_holes: Optional[int]
    main_trunk_name: str
    x1: float
    y1: float
    z1: float
    x2: float
    y2: float
    z2: float
    md1: float
    md2: float

    # TO DO: найти способ привести к DRY-принципу
    @validator("well_name", pre=True)
    def validate_null_well_name(cls, well_name: str, values: dict):
        if well_name is None:
            raise ValueError(f"Пропущенное значение в названии скважины")
        return well_name

    @validator("date", pre=True)
    def validate_null_date(cls, dt: date, values: dict):
        if dt is None:
            raise ValueError(f"Пропущенное значение в дате перфорации для скважины {values['well_name']}")
        return dt

    @validator("perforation_kind", pre=True)
    def validate_null_perforation_kind(cls, perforation_kind: str, values: dict):
        if perforation_kind is None:
            raise ValueError(f"Пропущенное значение в признаке перфорации для скважины {values['well_name']}")
        return perforation_kind

    @validator("top_interval_depth", pre=True)
    def validate_null_top_interval_depth(cls, top_interval_depth: float, values: dict):
        if top_interval_depth is None:
            raise ValueError(f"Пропущенное значение в глубине кровли перфорации для скважины {values['well_name']}")
        return top_interval_depth

    @validator("bottom_interval_depth", pre=True)
    def validate_null_bottom_interval_depth(cls, bottom_interval_depth: float, values: dict):
        if bottom_interval_depth is None:
            raise ValueError(f"Пропущенное значениев в глубине подошвы перфорации для скважины {values['well_name']}")
        return bottom_interval_depth

    @validator("main_trunk_name", pre=True)
    def validate_null_main_trunk_name(cls, main_trunk_name: str, values: dict):
        if main_trunk_name is None:
            raise ValueError(f"Пропущенное значение в названии главного ствола для скважины {values['well_name']}")
        return main_trunk_name

    @validator("x1", "y1", "z1", "x2", "y2", "z2", "md1", "md2", pre=True)
    def validate_null_coords(cls, coord: float, values: dict):
        if coord is None:
            raise ValueError("Пропущенное значение в координатах перфорации")
        return coord


class PerforationsSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    well_id: Optional[int]
    solid_id: Optional[int]
    solid_name: SolidEnum
    date: date
    well_name: str
    main_trunk_name: str
    perforation_kind: str
    perforation_code: Optional[str]
    top_interval_depth: float
    bottom_interval_depth: float
    date_open: Optional[date]
    date_close: Optional[date]
    number_holes: Optional[int]
    x1: float
    y1: float
    z1: float
    x2: float
    y2: float
    z2: float
    md1: float
    md2: float

    @validator("well_id", "solid_id", "date_open", "date_close", "number_holes", pre=False)
    def check_NaN(cls, val: float):
        if pd.isnull(val):
            val = None
        return val

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'well_id': 'ID скважины',
            'well_name': 'Скважина',
            'solid_id': 'ID пласта',
            'solid_name': 'Пласт',
            'date': 'Дата',
            'main_trunk_name': 'Главный ствол',
            'perforation_kind': 'Признак перфорации',
            'perforation_code': 'Код перфорации',
            'date_open': 'Дата открытия',
            'date_close': 'Дата закрытия',
            'top_interval_depth': 'Глубина кровли интервала, м',
            'bottom_interval_depth': 'Глубина подошвы интервала, м',
            'x1': 'Координата X кровли, м',
            'y1': 'Координата Y кровли, м',
            'z1': 'Координата Z кровли, м',
            'md1': 'MD кровли',
            'x2': 'Координата X подошвы, м',
            'y2': 'Координата Y подошвы, м',
            'z2': 'Координата Z подошвы, м',
            'md2': 'MD подошвы',
        }

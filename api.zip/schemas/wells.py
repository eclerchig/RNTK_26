import pdb

from pydantic import BaseModel, validator
from pydantic.schema import Optional
from datetime import date
import traceback

from logic.dictionary_enums import NumberTrunkEnum, CharacterWorkEnum, SolidEnum


class InvalidNumberTrunkException(Exception):
    def __init__(self, message):
        self.message = message
        self.traceback = traceback.format_exc()
        self.source = 'Scheme'

    def __str__(self):
        return f'({self.source}) Ошибка при обработке данных: {self.message}'


class WellsDictionaryScheme(BaseModel):
    class Config:
        use_enum_values = True
    name: str
    pad: Optional[str]
    solid: str
    xx: Optional[float]
    yy: Optional[float]
    zz: Optional[float]
    date_drilled: date
    main_trunk: str
    char_work: Optional[CharacterWorkEnum]
    times_changed: Optional[int]
    date_changes: Optional[date]
    drilling_status: Optional[bool]
    number_trunk: NumberTrunkEnum

    # TO DO: найти способ привести к DRY-принципу
    @validator("name", pre=True)
    def validate_null_name(cls, name: str, values: dict):
        if name is None:
            raise ValueError("Пропущенное значение в имени скважины")
        return name

    @validator("solid", pre=True)
    def validate_null_solid(cls, solid: str, values: dict):
        if solid is None:
            raise ValueError(f"Пропущенное значение в названии пласта для скважины {values.get('name')}")
        return solid

    @validator("date_drilled", pre=True)
    def validate_null_date_drilled(cls, date_drilled: str, values: dict):
        if date_drilled is None:
            raise ValueError(f"Пропущенное значение в дате бурения для скважины {values.get('name')}")
        return date_drilled

    @validator("main_trunk", pre=True)
    def validate_null_main_trunk(cls, main_trunk: str, values: dict):
        if main_trunk is None:
            raise ValueError(f"Пропущенное значение в названии основного ствола для скважины {values.get('name')}")
        return main_trunk

    @validator("times_changed", pre=True)
    def validate_null_times_changed(cls, times_changed: str, values: dict):
        if times_changed is None:
            raise ValueError(f"Пропущенное значение в названии основного ствола для скважины {values.get('name')}")
        return times_changed

    @validator("number_trunk", pre=True)
    def validate_number_trunk(cls, number_trunk: str, values: dict):
        if number_trunk is None:
            raise ValueError(f"Пропущенное значение в номере ствола {values.get('name')}")
        return number_trunk


class WellsDictionarySchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    name: str
    pad: Optional[str]
    solid: str
    number_trunk: Optional[str]
    xx: Optional[float]
    yy: Optional[float]
    zz: Optional[float]
    date_drilled: date
    main_trunk: str
    char_work: Optional[CharacterWorkEnum]
    times_changed: Optional[int]
    date_changes: Optional[date]
    drilling_status: Optional[bool]

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'name': 'Скважина',
            'pad': 'Куст',
            'solid': 'Пласт',
            'xx': 'X устья, м',
            'yy': 'Y устья, м',
            'zz': 'Z устья, м',
            'date_drilled': 'Дата бурения',
            'char_work': 'Характер работы',
            'times_changed': 'Номер изменения',
            'date_changes': 'Дата изменения',
            'drilling_status': 'В бурении',
            'number_trunk': 'Номер ствола',
        }


class WellNameExceptionsScheme(BaseModel):
    dev_name: str
    kin_name: str
    date_entry_encoding: date
    date_end_encoding: Optional[date]

    # TO DO: найти способ привести к DRY-принципу
    @validator("dev_name", pre=True)
    def validate_null_dev_name(cls, name: str, values: dict):
        if name is None:
            raise ValueError("Пропущенное значение в исходном имени скважины")
        return name

    @validator("kin_name", pre=True)
    def validate_null_kin_name(cls, name: str, values: dict):
        if name is None:
            raise ValueError(f"Пропущенное значение в имени скважины для РН-КИН для скважины {values.get('dev_name')}")
        return name

    @validator("date_entry_encoding", pre=True)
    def validate_null_date_entry_encoding(cls, date: str, values: dict):
        if date is None:
            raise ValueError(f"Пропущенное значение в дате ввода исключения переименования для скважины {values.get('dev_name')}")
        return date


class WellNameExceptionsSchemeGet(BaseModel):
    id: int
    dev_name: str
    kin_name: str
    date_entry_encoding: date
    date_end_encoding: Optional[date]

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'dev_name': 'Файловое название скважины',
            'kin_name': 'Название скважины в РН-КИН',
            'date_entry_encoding': 'Дата начала работы исключения',
            'date_end_encoding': 'Дата окончания работы исключения',
        }

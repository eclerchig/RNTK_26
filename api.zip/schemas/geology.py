from pydantic import BaseModel, ConfigDict


class GeologyScheme(BaseModel):
    well: str
    porosity: float = 0
    permeability: float = 0
    kh: float = 0
    onntDensity: float = 0
    onnt: float = 0
    initOilSaturation: float = 0
    nnt: float = 0

class GeologySchemeGet(BaseModel):
    id: int
    well: str
    porosity: float
    permeability: float
    kh: float
    onntDensity: float
    onnt: float
    initOilSaturation: float
    nnt: float

    model_config = ConfigDict(from_attributes=True)
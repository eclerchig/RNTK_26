from datetime import date

from pydantic import BaseModel, ConfigDict


class StatisticsScheme(BaseModel):
    well: str
    date: date
    rateDebitOilFallForYear: float = 0
    rateDebitOilFallForMonth: float = 0
    numMonthsWithoutWork: float = 0

    debitOilMedian: float = 0
    debitLiqMedian: float = 0
    watercutMedian: float = 0
    timeWorkProdMedian: float = 0
    solidPressMedian: float = 0
    downholePressMedian: float = 0
    dynLevelMedian: float = 0

    calculate_id: int

class StatisticsSchemeGet(BaseModel):
    id: int
    well: str
    date: date
    rateDebitOilFallForYear: float
    rateDebitOilFallForMonth: float
    numMonthsWithoutWork: float

    debitOilMedian: float
    debitLiqMedian: float
    watercutMedian: float
    timeWorkProdMedian: float
    solidPressMedian: float
    downholePressMedian: float
    dynLevelMedian: float

    calculate_id: int

    model_config = ConfigDict(from_attributes=True)

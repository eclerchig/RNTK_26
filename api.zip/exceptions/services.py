import pdb

from interfaces.service import ServiceWorkException


class ServiceValidationError(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return f'Ошибка валидации данных: {self.message}'


class ServiceFileUploadException(ServiceWorkException):
    def __init__(self, child_exc=None):
        super().__init__(
            description=f"Ошибка на этапе обработки файла: \n{child_exc.__str__()}",
            child_exc=child_exc,
        )
    def __str__(self):
        return super().__str__()


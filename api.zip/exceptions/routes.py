from interfaces.exception import APIException


class DoesntExistCeleryTask(APIException):
    def __init__(self, task_id):
        super().__init__(
            description=f"Задачи с ID {task_id} не существует",
            data={
                "task_id": task_id,
            }
        )

    def __str__(self):
        return super().__str__()


import pdb
from abc import ABC

from interfaces.exception import APIException


class RepositoryException(APIException):
    def __init__(self, description: str, data: dict = None, service=None):
        super().__init__(description, source="Репозиторий", data=data, service=service)

    def __str__(self):
        return super().__str__()


class ErrorInTimeParallelCalculationCoeffsException(APIException):
    def __init__(self, parent_exc):
        exc_msg = parent_exc.__str__()
        super().__init__(
            f"Ошибка во время вычисления коэффициентов: {exc_msg[0].lower() + exc_msg[1:]}",
        )

    def __str__(self):
        return super().__str__()


class ErrorInTimeParallelCalculationTargetInjException(APIException):
    def __init__(self, parent_exc):
        exc_msg = parent_exc.__str__()
        super().__init__(
            f"Ошибка во время вычисления целевой закачки: {exc_msg[0].lower() + exc_msg[1:]}",
        )

    def __str__(self):
        return super().__str__()


class NotExistCoordinatesForPerforationError(APIException, ABC):
    def __init__(self, well, top_md, bottom_md, source=None):
        super().__init__(
            f"Для скважины {well} не найдены координаты траектории для интервала перфорации от {top_md} до {bottom_md}",
            source=source if source else "Бизнес-слой",
            data={
                well: well,
                top_md: top_md,
                bottom_md: bottom_md
            }
        )


class NotExistCoordinatesForCenterPerforationError(APIException, ABC):
    def __init__(self, well, center_md, source=None):
        center_md = round(center_md, 2)
        super().__init__(
            f"Для скважины {well} не найдены координаты траектории для центра интервала перфорации {center_md}",
            source=source if source else "Бизнес-слой",
            data={
                well: well,
                center_md: center_md,
            }
        )


class CantConvertValueToDateTypeException(APIException, ABC):
    def __init__(self, value, source=None):
        super().__init__(
            f"Не получилось преобразовать значение {value} типа {type(value)} к datetime.date",
            source=source if source else "Бизнес-слой",
            data={
                value: value,
            }
        )
        self.value = value


class NotFoundFormatForConvertStringToDateException(APIException, ABC):
    def __init__(self, str_date, source=None):
        super().__init__(
            f"Нет подходящего формата для преобзования строки {str_date} в datetime.date",
            source=source if source else "Бизнес-слой",
            data={
                str_date: str_date,
            }
        )


class NotExistWellException(APIException):
    def __init__(self, well_name):
        super().__init__(f"Нет данных по скважине {well_name}",
                         data={
                             'well_name': well_name,
                         })

    def __str__(self):
        return super().__str__()


class NotExistSolidException(APIException):
    def __init__(self, solid_name):
        super().__init__(f"Нет данных по объекту {solid_name}",
                         data={
                             'solid_name': solid_name,
                         })

    def __str__(self):
        return super().__str__()


class NotExistCellException(APIException):
    def __init__(self, cell_name, solid_name):
        super().__init__(f"Нет данных по ячейке {cell_name} на объекте {solid_name}",
                         data={
                             'cell_name': cell_name,
                             'solid_name': solid_name,
                         })

    def __str__(self):
        return super().__str__()


class NotExistAggrFuncException(APIException):
    def __init__(self, name):
        super().__init__(f"Нет данных по функции {name}",
                         data={
                             'name': name,
                         })

    def __str__(self):
        return super().__str__()


class NotExistWellInSolidException(APIException):
    def __init__(self, well_name, solid_name):
        super().__init__(f"Скважина {well_name} не принадлежит объекту {solid_name}",
                         data={
                             'well_name': well_name,
                             'solid_name': solid_name,
                         })

    def __str__(self):
        return super().__str__()


class NotExistFundForSolidException(APIException):
    def __init__(self, solid_name):
        super().__init__(f"Нет сформированного реаг. фонда по объекту {solid_name}",
                         data={
                             'solid_name': solid_name,
                         })

    def __str__(self):
        return super().__str__()


class NotExistCellsDataForSolidException(APIException):
    def __init__(self, solid_name):
        super().__init__(f"Не загружена информация о ячейках на объекте {solid_name}",
                         data={
                             'solid_name': solid_name,
                         })

    def __str__(self):
        return super().__str__()


class NotExistCellsPolygonsDataForSolidException(APIException):
    def __init__(self, solid_name):
        super().__init__(f"Не загружена информация о полигонах ячеек на объекте {solid_name}",
                         data={
                             'solid_name': solid_name,
                         })

    def __str__(self):
        return super().__str__()


class NotExistDataInMonitoringException(APIException):
    def __init__(self, well_name, solid_name, date):
        super().__init__(f"Нет данных в мониторинге по следующим фильтрам: скважина - {well_name}, "
                         f"объект - {solid_name}, дата - {date}",
                         data={
                             'well_name': well_name,
                             'solid_name': solid_name,
                             'date': date,
                         })

    def __str__(self):
        return super().__str__()


class EmptyCoeffsCalculationException(APIException):
    def __init__(self, begin_date, end_date, by_cells=False):
        description = "Отсутствуют вычисленные коэффициенты"

        if by_cells:
            description += " по ячейкам"
        if begin_date or end_date:
            description += " на период"
            if begin_date:
                description += f" с {begin_date}"
            if end_date:
                description += f" по {end_date}"
            super().__init__(description,
                             data={'begin_date': begin_date, 'end_date': end_date})

    def __str__(self):
        return super().__str__()


class EmptyRecInjCalculationException(APIException):
    def __init__(self, begin_date, end_date, by_cells=False):
        description = "Отсутствуют вычисленная рекомендуемая закачка"

        if by_cells:
            description += " по ячейкам"
        if begin_date or end_date:
            description += " на период"
            if begin_date:
                description += f" с {begin_date}"
            if end_date:
                description += f" по {end_date}"
            super().__init__(description,
                             data={'begin_date': begin_date, 'end_date': end_date})

    def __str__(self):
        return super().__str__()


class EmptyPerforationUpload(APIException):
    def __init__(self):
        super().__init__("Отсутствуют данные для обновления. Проверьте данные, возможно, перфорации уже загружены")

    def __str__(self):
        return super().__str__()
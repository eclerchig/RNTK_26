# from typing import Union
#
# from pydantic import BaseSettings
#
# class Settings(BaseSettings):
#     DATABASE_URL_POSTGRES: str = ""
#     ORIGINS: str = "http://localhost"
#
#     TEMPDIR: str = "temp"
#
#     ACCESS_TOKEN_EXPIRE_MINUTES: int = 4
#     REFRESH_TOKEN_EXPIRE_DAYS: Union[str, int] = "0.002"
#
#     REDIS_URL: str ="redis://localhost:6379"
#
#     JWT_SECRET_KEY: str = "somejwtsecretkey"
#     JWT_REFRESH_SECRET_KEY: str = "somerefreshsecretkey"
#
#     ALGORITHM: str = "algorithm"
#
#     class Config:
#         env_file = ".env"
#         env_file_encoding = "utf-8"
#
# settings = Settings()
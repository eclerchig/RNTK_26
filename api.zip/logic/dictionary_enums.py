from enum import Enum


class FileExtentionsEnum(str, Enum):
    oil = 'excel'
    inj = 'csv'


class CharacterWorkEnum(str, Enum):
    oil = 'неф'
    inj = 'наг'
    wat = 'вдз'
    gas = 'газ'


class SolidEnum(str, Enum):
    nh_34 = 'Нх 3-4'
    nh_1 = 'Нх 1'
    yak_37 = 'Як 3-7'
    yak_2 = 'Як 2'


class NumberTrunkEnum(str, Enum):
    general = 'основной'
    first = 'первый'
    second = 'второй'
    third = 'третий'
    fourth = 'четвертый'
    fifth = 'пятый'
    sixth = 'шестой'
    seventh = 'седьмой'
    eighth = 'восьмой'
    ninth = 'девятый'
    tenth = 'десятый'
    eleventh = 'одиннацдцатый'
    twelfth = 'двенадцатый'
    thirteenth = 'тринадцатый'
    fourteenth = 'четырнадцатый'
    fifteenth = 'пятнадцатый'


class WellPurposeEnum(str, Enum):
    production = 'Добывающая'
    injection = 'Нагнетательная'
    production_injection = 'Нагнетательная с отработкой'


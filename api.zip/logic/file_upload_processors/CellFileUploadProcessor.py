import itertools
import pdb

import pandas as pd
import numpy as np
import datetime

from dateutil.relativedelta import relativedelta

from logic.file_upload_processors.FileUploadProcessor import FileUploadProcessor
from logic.utilities import lead_date_to_one_date_format, rename_solid
from stratagies.LoadTable import calc_reservoir_sampling


class CellPolygonFileUploadProcessor(FileUploadProcessor):

    COLUMNS = {
        'Скважина': 'well_name',
        'Ячейка': 'cell_name',
        'Пласт': 'solid_name',
        'Дата ввода': 'entry_date',
        'Перевод в ППД': 'ppd_conversion_date',
    }

    COLUMNS_TYPES = {
        'well_name': str,
        'cell_name': str,
    }

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df, wells_df=None, solids_df=None, user_id=None, **kwargs):

        missing_columns = [col for col in self.COLUMNS if col not in df.columns]
        if missing_columns:
            raise KeyError("Отсутствуют необходимые колонки", missing_columns, list(self.COLUMNS.keys()))
        else:
            df = df[self.COLUMNS.keys()]
            df = df.rename(columns=self.COLUMNS)
            return df

    def remove_na(self, df):
        df = df.replace({np.nan: None})
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            else:
                df[col] = df[col].astype(type_)
        return df

    def additional_processing(self, df, **kwargs):
        # Удаляем пласты, в которых не определелился id
        # (Временно, планируется предупреждать пользователя об удаленных строках)
        df["well_id"] = df["well_id"].replace(np.nan, None)
        df = df[df["solid_id"].notna()]
        return df


class MonitoringValuesFileUploadProcessor(FileUploadProcessor):

    COLUMNS_TYPES = {
        'well_name': str,
        'solid_name': str,
        'date': datetime.date,
        'oil_production': float,
        'liquid_production': float,
        'gas_production': float,
        'water_injection': float,
        'days': int,
    }

    BEGIN_BLOCK_OIL_COLUMN = 16
    END_BLOCK_OIL_COLUMN = 100
    BEGIN_BLOCK_LIQ_COLUMN = 188
    END_BLOCK_LIQ_COLUMN = 272
    BEGIN_BLOCK_WATER_INJ_COLUMN = 618
    END_BLOCK_WATER_INJ_COLUMN = 702
    BEGIN_BLOCK_GAS_COLUMN = 876
    END_BLOCK_GAS_COLUMN = 960

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df, wells_monitoring_df=None, solids_df=None, user_id=None, **kwargs):
        df = df.iloc[3:, :]
        df = df.drop(df[pd.isnull(df['Скважина'])].index)

        dates = [lead_date_to_one_date_format(dt)
                for dt in (df.columns[self.BEGIN_BLOCK_OIL_COLUMN - 1:self.END_BLOCK_OIL_COLUMN].to_list())]
        wells = [well for well in df['Скважина'].to_list() for _ in range(len(dates))]
        solids = [solid for solid in df['Пласт'].to_list() for _ in range(len(dates))]
        dates = dates * df.shape[0]

        days = [-(dt - (dt + relativedelta(months=1))).days for dt in dates]
        oils = df.iloc[:, self.BEGIN_BLOCK_OIL_COLUMN - 1:self.END_BLOCK_OIL_COLUMN].values.tolist()
        oils = list(itertools.chain(*oils))
        liqs = df.iloc[:, self.BEGIN_BLOCK_LIQ_COLUMN - 1:self.END_BLOCK_LIQ_COLUMN].values.tolist()
        liqs = list(itertools.chain(*liqs))
        gases = df.iloc[:, self.BEGIN_BLOCK_GAS_COLUMN - 1:self.END_BLOCK_GAS_COLUMN].values.tolist()
        gases = list(itertools.chain(*gases))
        injs = df.iloc[:, self.BEGIN_BLOCK_WATER_INJ_COLUMN - 1:self.END_BLOCK_WATER_INJ_COLUMN].values.tolist()
        injs = list(itertools.chain(*injs))

        df = pd.DataFrame({'well_name': wells,
                           'solid_name': solids,
                           'date': dates,
                           'oil_production': oils,
                           'liquid_production': liqs,
                           'gas_production': gases,
                           'water_injection': injs,
                           'days': days
                           })
        return df

    def remove_na(self, df):
        df['oil_production'].fillna(0.0, inplace=True)
        df['liquid_production'].fillna(0.0, inplace=True)
        df['gas_production'].fillna(0.0, inplace=True)
        df['water_injection'].fillna(0.0, inplace=True)
        df = df.where(pd.notnull(df), None)
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            else:
                df[col] = df[col].astype(type_)
        return df

    def additional_processing(self, df, wells_monitoring_df=None, solids_df=None, user_id=None, **kwargs):

        df['solid_name'] = df['solid_name'].apply(lambda solid: rename_solid(solid))
        df = df.merge(
            wells_monitoring_df[['id', 'well_name', 'solid_name', 'solid_id']],
            left_on=['well_name', 'solid_name'],
            right_on=['well_name', 'solid_name'],
            how='left'
        )
        df = df.drop(['well_name', 'solid_name'], axis=1)
        df = df.rename(columns={'id': 'well_id'})

        df = df.merge(solids_df,
                      left_on=['solid_id'],
                      right_on=['id'],
                      how='left')
        df = df.drop(['id'], axis=1)

        df['user_id'] = user_id

        df['reservoir_sampling'] = df.apply(
            lambda row: calc_reservoir_sampling(
                row['oil_production'],
                row['liquid_production'],
                row['gas_production'],
                row['days'],
                row['oil_density'],
                row['oil_volume_coeff'],
                row['water_density'],
                row['water_volume_coeff'],
                row['gas_volume_coeff'],
            ),
            axis=1)

        df = df[['well_id', 'solid_id', 'date', 'oil_production',
                 'liquid_production', 'gas_production', 'water_injection',
                 'days', 'reservoir_sampling', 'user_id']]

        df = df[df["solid_id"].notna()]
        df["well_id"] = df["well_id"].replace(np.nan, None)

        return df
import datetime

from logic.file_upload_processors.FileUploadProcessor import FileUploadProcessor
from logic.utilities import lead_date_to_one_date_format


class ExceptionsWellNameFileUploadProcess(FileUploadProcessor):

    COLUMNS = {
        'WellDevName': 'well_dev_name',
        'WellName': 'well_kin_name',
        'DateEntryDecoding': 'date_entry_exception',
        'DateExitDecoding': 'date_exit_exception',
    }

    COLUMNS_TYPES = {
        'well_dev_name': str,
        'well_kin_name': str,
        'date_entry_exception': datetime.date,
        'date_exit_exception': datetime.date,
    }

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df):
        missing_columns = [col for col in self.COLUMNS.keys() if col not in df.columns]
        if missing_columns:
            raise KeyError("Отсутствуют необходимые колонки", missing_columns, list(self.COLUMNS.keys()))
        else:
            df = df[self.COLUMNS.keys()]
            df = df.rename(columns=self.COLUMNS)
            return df

    def remove_na(self, df):
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            else:
                df[col] = df[col].astype(type_)

    def additional_processing(self, df):
        return df


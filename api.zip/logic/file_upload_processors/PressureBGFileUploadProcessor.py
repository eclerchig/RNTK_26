import pdb

import pandas as pd
import datetime

from logic.file_upload_processors.FileUploadProcessor import FileUploadProcessor
from logic.utilities import lead_date_to_one_date_format


class PressureBGFileUploadProcessor(FileUploadProcessor):

    COLUMNS = {
        'КНС': 'kns',
        'КП': 'pad',
    }

    COLUMNS_TYPES = {
        'kns': str,
        'pad': str,
        'date': datetime.date,
        'pressure_bg': float,
    }

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df, **kwargs):
        missing_columns = [col for col in self.COLUMNS.keys() if col not in df.columns]
        if missing_columns:
            raise KeyError("Отсутствуют необходимые колонки", missing_columns, list(self.COLUMNS.keys()))
        else:
            df = df.rename(columns=self.COLUMNS)
            dates = df.columns[2:]
            kns_column = [str(kns) for kns in df['kns'].to_list() for _ in range(len(dates))]
            kp_column = [str(pad) for pad in df['pad'].to_list() for _ in range(len(dates))]

            vals = []

            for row in df[dates].itertuples():
                vals = vals + list(row[1:])

            dates = [lead_date_to_one_date_format(dt) for dt in dates.to_list()] * df.shape[0]

            df = pd.DataFrame({
                'kns': kns_column,
                'pad': kp_column,
                'date': dates,
                'pressure_bg': vals})
            return df

    def remove_na(self, df):
        df = df[df["pressure_bg"].notna()]
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            else:
                df[col] = df[col].astype(type_)
        return df

    def additional_processing(self, df, **kwargs):
        return df


import pdb

import pandas as pd
import numpy as np
import datetime

from celery.contrib import rdb

from interfaces.exception import APIException
from logic.file_upload_processors.FileUploadProcessor import FileUploadProcessor
from logic.utilities import rename_solid
from logic.utilities import lead_date_to_one_date_format
from schemas.celery import UpdateProgressMeta
from stratagies.LoadTable import define_main_trunk_by_kin_name, add_coords_to_perforation_table
from tasks.progress_tracker import task_progress_tracker


class MissingTrunksInWellsDictionaryException(APIException):
    def __init__(self, missing_trunks: list = None):
        self.missing_trunks = missing_trunks

    def __str__(self):
        return f"В базу скважин не загружены стволы: {self.missing_trunks}"


class PerforationFileUploadProcessor(FileUploadProcessor):

    COLUMNS = {
        'Скважина': 'well_name',
        'Пласт': 'solid_name',
        'Дата': 'date',
        'Тип': 'perforation_kind',
        'Перфоратор': 'perforation_code',
        'N отв': 'number_holes',
        'Ннач(md)': 'top_interval_depth',
        'Нкон(md)': 'bottom_interval_depth',
    }

    COLUMNS_TYPES = {
        'well_name': str,
        'solid_name': str,
        'date': datetime.date,
        'perforation_kind': str,
        'perforation_code': str,
        'number_holes': int,
        'top_interval_depth': float,
        'bottom_interval_depth': float,
    }

    CLOSE_PERFS_KINDS = ['отсеч.пакером', 'отсеч.мостом', 'отсеч.стаканом', 'изол. взрывпак.']

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df, **kwargs):
        missing_columns = [col for col in self.COLUMNS if col not in df.columns]
        if missing_columns:
            raise KeyError("Отсутствуют необходимые колонки", missing_columns, list(self.COLUMNS.keys()))
        else:
            df = df[self.COLUMNS.keys()]
            df = df.rename(columns=self.COLUMNS)

        return df

    def remove_na(self, df):
        df['number_holes'].fillna(0, inplace=True)
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            else:
                df[col] = df[col].astype(type_)
        return df

    def additional_processing(self, df, old_perfs_df=None,
                              wells_df=None, incls_df=None,
                              solids_df=None, well_monitoring_df=None,
                              calc_coords_only_new=True, task_id:str=None, **kwargs):

        total_rows = df.shape[0]
        df.sort_values('date', inplace=True)
        df[['date_open', 'date_close']] = None
        df['perforation_kind'] = df['perforation_kind'].apply(lambda x: x.lower())

        df['solid_name'] = df['solid_name'].apply(lambda solid: rename_solid(solid))

        df['main_trunk_name'] = df.apply(lambda row: define_main_trunk_by_kin_name(row['well_name'], wells_df), axis=1)
        missing_trunk_names_in_wells_df = df[df['main_trunk_name'].isnull()]['well_name'].unique()

        if len(missing_trunk_names_in_wells_df) > 0:
            raise MissingTrunksInWellsDictionaryException(missing_trunk_names_in_wells_df)

        processed_df = old_perfs_df.copy()
        ready_perfs_df = pd.DataFrame([])

        is_closed_only_rows = pd.DataFrame([], columns=df.columns)
        date_close_equal_date_open_rows = pd.DataFrame([], columns=df.columns)
        empty_date_open_wells = []

        for idx, _ in enumerate(df.itertuples(name=None, index=False)):

            df_piece = df.iloc[idx, :]
            is_closed = df_piece.at['perforation_kind'] in self.CLOSE_PERFS_KINDS

            match_old_rows = processed_df[
                (processed_df['well_name'] == df_piece['well_name']) &
                (processed_df['solid_name'] == df_piece['solid_name']) &
                (processed_df['perforation_code'] == df_piece['perforation_code']) &
                (processed_df['top_interval_depth'] == df_piece['top_interval_depth']) &
                (processed_df['bottom_interval_depth'] == df_piece['bottom_interval_depth'])
            ]

            # если уже есть перфорация(-ии) с подобными координатами
            if not match_old_rows.empty:
                first_perforation = match_old_rows.iloc[0]
                # если новая перфорация закрывает
                if is_closed:
                    if first_perforation.at['date_open']:
                        if df_piece.at['date'] == first_perforation.at['date_open']:
                            date_close_equal_date_open_rows = pd.concat(
                                [date_close_equal_date_open_rows, df_piece.to_frame().T],
                                ignore_index=True)
                        # Добавляем дату закрытия к старым перфорациям
                        df_piece['date_close'] = df_piece.at['date']
                        processed_df.loc[match_old_rows.index, 'date_close'] = df_piece.at['date']
                    else:
                        empty_date_open_wells.append(df_piece['well_name'])
                if match_old_rows[match_old_rows['perforation_kind'] == df_piece['perforation_kind']].empty:
                    # Если это новый вид перфорации обновляем дату открытия перфорации
                    df_piece['date_open'] = first_perforation.at['date']
            else:
                # Если новая перфорация закрывает, но старых перфораций нет
                if is_closed:
                    is_closed_only_rows = pd.concat([is_closed_only_rows, df_piece.to_frame().T], ignore_index=True)
                # Если новая перфорация не закрывает, то обновляем дату открытия на основе даты перфорации
                else:
                    df_piece['date_open'] = df_piece['date']

            if df_piece['date_open']:
                df_piece = pd.DataFrame([df_piece])
                if idx == 0 and processed_df.empty:
                    processed_df = df_piece.copy()  # для копирования типа данных в первый раз
                else:
                    processed_df = pd.concat([processed_df, df_piece])

                if calc_coords_only_new:
                    if idx == 0 and ready_perfs_df.empty:
                        ready_perfs_df = df_piece.copy()
                    else:
                        ready_perfs_df = pd.concat([ready_perfs_df, df_piece])

            if task_id:
                task_progress_tracker.update_meta(
                    task_id=task_id,
                    data=UpdateProgressMeta(
                        alert_msg=f"Обработано строк перфораций {idx+1}/{total_rows}",
                        current=70+(idx/total_rows)*20,
                        total=100,
                    )
                )

        df = ready_perfs_df.reset_index(drop=True).copy() if calc_coords_only_new else processed_df.reset_index(drop=True).copy()

        if not df.empty:

            if task_id:
                task_progress_tracker.update_meta(
                    task_id=task_id,
                    data=UpdateProgressMeta(
                        alert_msg=f"Добавление координат к перфорациям",
                        current=95,
                        total=100,
                    )
                )

            df = add_coords_to_perforation_table(df, incls_df)

            if not calc_coords_only_new:
                df = df.drop(['id', 'solid_id', 'well_id'], axis=1)

            if task_id:
                task_progress_tracker.update_meta(
                    task_id=task_id,
                    data=UpdateProgressMeta(
                        alert_msg=f"Добавление внешних ключей",
                        current=98,
                        total=100,
                    )
                )

            df = df.merge(solids_df[['id', 'name']],
                          left_on='solid_name',
                          right_on='name',
                          how='left')
            df = df.rename(columns={'id': 'solid_id'})
            df = df.drop(['name', 'solid_name'], axis=1)
            df = df[df["solid_id"].notna()]

            df = df.merge(well_monitoring_df[['id', 'well_name']],
                          on='well_name',
                          how='left')
            df = df.rename(columns={'id': 'well_id'})

            df = df.replace(np.nan, None)

        return df


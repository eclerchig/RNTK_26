import pdb

import pandas as pd
import datetime

from logic.file_upload_processors.FileUploadProcessor import FileUploadProcessor
from logic.utilities import lead_date_to_one_date_format, rename_solid


class WellsFileUploadProcess(FileUploadProcessor):

    COLUMNS = {
        'WellName': 'name',
        'Pad': 'pad',
        'Zone': 'solid',
        'XX': 'xx',
        'YY': 'yy',
        'ZZ': 'zz',
        'DateDrilled': 'date_drilled',
        'WellOrig': 'main_trunk',
        'LastCharWork': 'char_work',
        'TimesChanged': 'times_changed',
        'DateChanges': 'date_changes',
        'DrillingStatus': 'drilling_status',
        'NumberTrunk': 'number_trunk',
    }

    COLUMNS_TYPES = {
        'name': str,
        'pad': str,
        'solid': str,
        'xx': float,
        'yy': float,
        'zz': float,
        'date_drilled': datetime.date,
        'main_trunk': str,
        'char_work': str,
        'times_changed': int,
        'date_changes': datetime.date,
        'drilling_status': bool,
        'number_trunk': str,
    }

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df, **kwargs):
        missing_columns = [col for col in self.COLUMNS.keys() if col not in df.columns]
        if missing_columns:
            raise KeyError("Отсутствуют необходимые колонки", missing_columns, list(self.COLUMNS.keys()))
        else:
            df = df[self.COLUMNS.keys()]
            df = df.rename(columns=self.COLUMNS)
            return df

    def remove_na(self, df):
        df['xx'].fillna(0, inplace=True)
        df['yy'].fillna(0, inplace=True)
        df['zz'].fillna(0, inplace=True)

        df = df.where(pd.notnull(df), None)
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            elif type_ == str:
                df[col] = df[col].apply(lambda x: str(x) if x is not None else None)
            else:
                df[col] = df[col].astype(type_)
        return df

    def additional_processing(self, df, **kwargs):
        # Удаление аварийных стволов
        for idx, _ in df.iterrows():
            trunk = df.loc[idx, :]['name']
            if '_' in trunk and trunk not in ['14Г_БГС', '9Р_НХ', '9Р_ЯК']:
                df.drop(idx, inplace=True)

        df['solid'] = df['solid'].apply(lambda solid: rename_solid(solid))
        return df


import pdb

import pandas as pd
import datetime

from logic.file_upload_processors.FileUploadProcessor import FileUploadProcessor
from logic.utilities import lead_date_to_one_date_format


class InclinometryFileUploadProcess(FileUploadProcessor):

    COLUMNS = {
        'Скважина': 'well_name',
        'Координата X': 'x',
        'Координата Y': 'y',
        'Z': 'z',
        'MD': 'md',
    }

    COLUMNS_TYPES = {
        'well_name': str,
        'x': float,
        'y': float,
        'z': float,
        'md': float,
    }

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df):
        missing_columns = [col for col in self.COLUMNS.keys() if col not in df.columns]
        if missing_columns:
            raise KeyError("Отсутствуют необходимые колонки", missing_columns, list(self.COLUMNS.keys()))
        else:
            df = df[self.COLUMNS.keys()]
            df = df.rename(columns=self.COLUMNS)
            return df

    def remove_na(self, df):
        df = df.where(pd.notnull(df), None)
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            else:
                df[col] = df[col].astype(type_)
        return df

    def additional_processing(self, df):
        return df


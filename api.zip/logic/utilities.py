import contextvars
import pdb

import math
import re
from io import BytesIO

import pandas as pd
import numpy as np
import os
import shutil
from datetime import datetime, time

from exceptions.business import CantConvertValueToDateTypeException, NotFoundFormatForConvertStringToDateException
from interfaces.exception import APIException
from interfaces.logging_ import user_id_ctx, trace_id_ctx

SOLID_DECODER = {
    "Дл 1-3": ('дл1-3', 'длi-iii', 'дл-i-iii'),
    "ВЯк 8": ('вяк8', 'вяк-8', 'вякviii', 'вяк-viii'),
    "Нс": ('нс'),
    "Нх 3-4": ('нх3-4', 'нхiii-iv', 'нх-iii-iv', 'нх3-4,основнаязалежь'),
    "Нх 1": ('нх1', 'нх-1', 'нхi', 'нх-i'),
    "Сд 9": {'сд9', 'сд-9', 'сдix', 'сд-ix'},
    "Як 2": {'як2', 'як-2', 'якii', 'як-ii'},
    "Як 3-7": {'як3-7', 'якiii-vii', 'як-iii-vii'},
}


def chunk_list(seq, num):
    avg = len(seq) / float(num)
    out = []
    last = 0.0

    while last < len(seq):
        out.append(seq[int(last):int(last+avg)])
        last += avg

    return out


def remove_spaces(val):
    if isinstance(val, str): return str.strip(val)
    return val


def convert_multi_index_to_single_index(df):
    '''
    Преобразование MultiIndex в обычный
    '''
    new_columns = []
    for index_column in df.columns.to_list():
        new_columns.append(''.join([str(elem) + ' ' for elem in list(index_column)]).strip())
    df.columns = new_columns
    return df


def replace_nan_to_none_for_float_values(df):
    '''
    Преобразование np.nan в None
    '''
    for column in df:
        df[column] = df[column].apply(lambda v: check_float(v))
    return df


def check_float(v):
    if isinstance(v, float) and np.isnan(v):
        v = None
    return v



class UnknownSolidName(APIException):
    def __init__(self, solid_name):
        super().__init__(
            f"Неизвестное название пласта - '{solid_name}'",
            data={
                'solid_name': solid_name,
            }
        )


def rename_solid(source_name: str):
    if pd.isna(source_name):
        return source_name
    if "|" in source_name:
        solid_name = []
        for name in source_name.split("|"):
            findout_flag = False
            for solid in SOLID_DECODER.keys():
                if str(name).lower().replace(" ", "") in SOLID_DECODER[solid]:
                    solid_name.append(solid)
                    findout_flag = True
                    break
            if not findout_flag:
                raise UnknownSolidName(source_name)
        return "|".join(solid_name)
    for solid in SOLID_DECODER.keys():
        if str(source_name).lower().replace(" ", "") in SOLID_DECODER[solid]:
            return solid
    raise UnknownSolidName(source_name)


def remove_files_in_folder(folder_path):
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Не получилось удалить файл по пути %s. Причина: %s' % (file_path, e))


def is_date_between(begin_date, end_date, check_date=None):
    check_date = check_date or datetime.today()
    return begin_date >= check_date >= end_date


def partition_df(df: pd.DataFrame,
                 chunk_size: int) -> pd.DataFrame:
    for i in range(0, df.shape[0], chunk_size):
        yield df.iloc[i:i + chunk_size]


def partition_list(records,
                   chunk_size: int):
    for i in range(0, len(records), chunk_size):
        yield records[i:i + chunk_size]


regex_pattern_convert_to_strptime = {
    r'^\d{2}-\d{2}-\d{2}$': '%d-%m-%y',
    r'^\d{2}.\d{2}.\d{2}$': '%d.%m.%y',
    r'^\d{2}\/\d{2}\/\d{2}$': '%d/%m/%y',
    r'^\d{2}-\d{2}-\d{4}$': '%d-%m-%Y',
    r'^\d{2}.\d{2}.\d{4}$': '%d.%m.%Y',
    r'^\d{2}\/\d{2}\/\d{4}$': '%d/%m/%Y',
}


def lead_date_to_one_date_format(dt):
    try:
        if pd.isnull(dt) or isinstance(dt, time):
            return None
        elif isinstance(dt, int):
            dt = datetime.fromordinal(datetime(1900, 1, 1).toordinal() + int(dt) - 2)
            return dt.date()
        elif isinstance(dt, float):
            dt = math.trunc(dt)
            dt = datetime.fromordinal(datetime(1900, 1, 1).toordinal() + int(dt) - 2)
            return dt.date()
        elif isinstance(dt, str):
            if dt.strip() == '':
                return None
            else:
                return string_to_date(dt.strip())
        elif isinstance(dt, pd.Timestamp) or isinstance(dt, datetime):
            return dt.date()
        else:
            return dt
    except Exception:
        raise CantConvertValueToDateTypeException(dt, source="func utilities.lead_date_to_one_date_format")


def string_to_date(str_date: str):
    for pattern in regex_pattern_convert_to_strptime:
        if re.search(pattern, str_date):
            return datetime.strptime(str_date, regex_pattern_convert_to_strptime[pattern])
    raise NotFoundFormatForConvertStringToDateException(str_date, source="func utilities.string_to_date")


def dataframe_to_bytes_buffer_by_excel(df: pd.DataFrame) -> BytesIO:
    buffer = BytesIO()
    with pd.ExcelWriter(buffer) as writer:
        df.to_excel(writer, index=False)
    return buffer


def dataframe_to_bytes_buffer_by_csv(df: pd.DataFrame) -> BytesIO:
    buffer = BytesIO()
    bytes_ = df.to_csv().encode('utf-8-sig')
    buffer.write(bytes_)
    buffer.seek(0)
    return buffer


class SerializableContextWrapper:
    def __init__(self, sync_func, args, kwargs):
        self.sync_func = sync_func
        self.args = args
        self.kwargs = kwargs
        self.context_data = {}

        for var in contextvars.copy_context():
            self.context_data[var.name] = var.get()

    def __call__(self):
        for var_name, value in self.context_data.items():
            for var in contextvars.copy_context():
                if var.name == var_name:
                    var.set(value)
                    break
        user_id_ctx.set(self.context_data['user_id'])
        trace_id_ctx.set(self.context_data['trace_id'])
        return self.sync_func(*self.args, **self.kwargs)


def preserve_context(sync_func, *args, **kwargs):
    return SerializableContextWrapper(sync_func, args, kwargs)



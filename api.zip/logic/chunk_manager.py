import base64
import pdb
from io import BytesIO
from typing import Dict, Any
from collections import defaultdict

from celery.contrib import rdb
from redis import Redis

from settings import settings


class ChunkManager:
    """
    Менеджер для хранения чанков во время выполнения celery задач
    """
    chunk_size = 128 * 1024  # 128 КБ

    def __init__(
        self,
        redis_url="redis://localhost:6379/0",
        cache_namespace="result-chunks",
        expire_sec=7200,
    ):
        self._redis = Redis.from_url(redis_url, decode_responses=True)
        self._cache_namespace = cache_namespace
        self._expire_sec = expire_sec
        self._task_chunks: Dict[str, Dict[str, Any]] = defaultdict(dict) # Временное хранилище перед записью в redis

    def parse_json_to_chunks(self, task_id: str, json: str):
        for chunk_id, i in enumerate(range(0, len(json), self.chunk_size)):
            chunk = json[i:i + self.chunk_size]
            self.add_chunk(task_id, str(chunk_id), chunk)

    def parse_file_to_chunks(self, task_id: str, bytes_: BytesIO):
        chunk_index = 1
        bytes_.seek(0)
        while True:
            chunk = bytes_.read(self.chunk_size)
            if not chunk:
                break
            chunk_b64 = base64.b64encode(chunk).decode('utf-8-sig')
            self.add_chunk(task_id, str(chunk_index), chunk_b64)
            chunk_index += 1

    def add_chunk(self, task_id: str, chunk_id: str, chunk_data: Any):
        """
        Добавление нового чанка
        :param task_id: ID задачи в Celery
        :param chunk_id: Порядковый номер чанка
        :param chunk_data: Данные в чанке
        """
        self._task_chunks[task_id][chunk_id] = chunk_data

    def save_chunks_in_cache(self, task_id: str):
        chunks = self.get_all_local_chunks(task_id)
        self._redis.hset(f"{self._cache_namespace}:{task_id}", mapping=chunks)
        self._redis.expire(f"{self._cache_namespace}:{task_id}", self._expire_sec)
        self.cleanup_local(task_id)

    def get_chunk(self, task_id: str, chunk_id: str,):
        return self._redis.hget(f"{self._cache_namespace}:{task_id}", key=chunk_id)

    def get_all_local_chunks(self, task_id):
        return self._task_chunks[task_id]

    def get_all_cache_chunks(self, task_id):
        unsorted_chunks = self._redis.hgetall(f"{self._cache_namespace}:{task_id}")
        sorted_keys = sorted([*unsorted_chunks], key=int)
        sorted_chunks = {}
        for key in sorted_keys:
            sorted_chunks[key] = unsorted_chunks[key]
        return sorted_chunks

    def get_len_chunks(self, task_id):
        return len(self._redis.hgetall(f"{self._cache_namespace}:{task_id}"))

    def cleanup_local(self, task_id):
        if task_id in self._task_chunks:
            del self._task_chunks[task_id]

    def cleanup_cache(self, task_id):
        self._redis.delete(f"{self._cache_namespace}:{task_id}")


# Замыкание
def _ChunkStorage():
    service: ChunkManager = ChunkManager(redis_url=settings.REDIS_URL)

    def get_service() -> ChunkManager:
        return service

    def set_service(obj: ChunkManager) -> None:
        nonlocal service
        service = obj

    return get_service, set_service

chunk_storage, _ = _ChunkStorage()
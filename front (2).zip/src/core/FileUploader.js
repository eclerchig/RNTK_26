import {useMutation} from "@tanstack/react-query";

export default function FileUploader() {
    const uploadMutation = useMutation({
        mutationFn: async (file) => {
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch('localhost:/api/upload', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message || 'Upload failed');
            }

            // Получаем JSON ответ от сервера
            const result = await response.json();
            return result; // Это будет доступно в onSuccess
        },

        onSuccess: (data) => {
            console.log('Загружено! Ответ:', data);
            // data.processedFile, data.stats, etc.
        },

        onError: (error) => {
            console.error('Ошибка загрузки:', error);
        }
    });
}
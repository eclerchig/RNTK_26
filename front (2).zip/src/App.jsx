import { useState, useEffect } from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import './App.css'
import Header from './components/Header'
import { Container, Row, Col } from 'react-bootstrap';
import ProgressScreen from './components/ProgressScreen';
import ExampleTable, {columns, data} from './components/Table'
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import 'dayjs/locale/ru';
import ru from 'dayjs/locale/ru';
import { ruRU } from '@mui/x-date-pickers/locales';
import { Button, TextField } from "@mui/material";
import { rosneftBtnTheme } from "./components/themes.jsx";
import Autocomplete from '@mui/material/Autocomplete';
import TableGroupStatistic from './components/TableGroupStatistic.jsx';
import TableWellStatistic from "./components/TableWellStatistic.jsx";
import WellSelector from './components/wellSelector.jsx'
import TableGTM from "./components/TableGTM.jsx";
import AccordionModelInfo from "./components/AccordionModelInfo.jsx";
import ChartDistribution from './components/ChartDistribution.jsx';
import ChartWell from './components/ChartWell.jsx';
import FileUploaderBlock from './components/FileUploadBlock.jsx';
import dayjs from "dayjs";


const StyledButton = (props) => {
  const { text, onCLick } = props
  return <Button
    variant="contained"
    onClick={onCLick}
    sx={{
      color: rosneftBtnTheme.palette.orange.contrastText,
      backgroundColor: rosneftBtnTheme.palette.orange.lightContrastText,
    }}
  >
    {text}
  </Button>
}

const groupOptions = ['ОПЗ', 'ИДН', 'ЛНЭК']

const wells = [
  { id: 1, name: '100', gtm: 'ОПЗ'},
  { id: 2, name: '1001А', gtm: 'ОПЗ'},
  { id: 3, name: '1010А', gtm: 'ИДН'},
  { id: 4, name: 'Скважина 4', gtm: 'ЛНЭК'},
  { id: 5, name: 'Скважина 5', gtm: 'ЛНЭК'},
  { id: 6, name: 'Скважина 6', gtm: 'ЛНЭК'},
];

const queryClient = new QueryClient()


function App() {

  const [progress, setProgress] = useState(false)
  const [tableData, setTableData] = useState([])

  const [currentGTM, setCurrentGTM] = useState(groupOptions[0]);
  const [inputValue, setInputValue] = useState('');
  const [selectedWell, setSelectedWell] = useState(null)
  const [selectedDataWell, setSelectedDataWell] = useState([])
  const [selectedDataGTM, setSelectedDataGTM] = useState([])
  const [selectedWellsByGTM, setSelectedWellsByGTM] = useState([])

  const handleSelectWell = (well) => {
    setSelectedWell(well)
    setSelectedDataWell(data.filter(row => row.well === well.name))
  }
  const handleTableDataUpload = (data) => {
    console.log('handleTableDataUpload', data)
    const tableData = data.map(row => {
      row.date = dayjs(row.date, 'YYYY-MM-DD')
      return row
    })
    console.log('handleTableDataUpload tableData', tableData)
    setTableData(tableData)
  }

  useEffect(() => {
    const wellsGTM = currentGTM ? wells.filter(well => well.gtm === currentGTM).map(well => well.name) : wells
    setSelectedWellsByGTM(currentGTM ? wells.filter(well => well.gtm === currentGTM) : wells)
    setSelectedDataGTM(currentGTM ? data.filter(well => wellsGTM.includes(well.well)) : data)
  }, [currentGTM])

  return (
    <QueryClientProvider client={queryClient}>
      {progress && <ProgressScreen progress={progress} totalProgress={100} title='Загрузка...'/>}
      <LocalizationProvider
        dateAdapter={AdapterDayjs}
        adapterLocale={ru}
        localeText={ruRU.components.MuiLocalizationProvider.defaultProps.localeText}>
        <Header />
        <Container fluid id='main'>
          <FileUploaderBlock onLoadingChange={setProgress} onDataChange={handleTableDataUpload}/>
          <Row id="model-config-block" className="justify-content-center mt-5">
            <Col className="title" md={12}>
              <h2>Настройки модели</h2>
            </Col>
            <Col className="table-zone mt-5" md={12} >
              <AccordionModelInfo/>
            </Col>
          </Row>
          <Row id="showDataFilesBlock" className="justify-content-center mt-5">
            <Col className="title" md={12} >
              <h2>Загруженные данные по скважинам</h2>
            </Col>
            <Col className="table-zone mt-5" md={12} >
              <ExampleTable data={tableData}/>
            </Col>
          </Row>
          <Row id="resultsBlock" className="justify-content-center mt-5" style={{marginBottom: '400px'}}>
            <Col className="title" md={12}>
              <h2>Запуск прогноза и вывод результатов</h2>
              <StyledButton text='Запустить расчет' />
            </Col>
            <Col className="result-zone" md={12}>
              <Row>
                <Col className="groups-info-block mt-5 mb-3" md={6}>
                  <h3>Сформированные группы фонда</h3>
                  <div className='content mt-3'>
                    <div className='filterGTM mb-3'>
                      Вид мероприятия:
                      <Autocomplete
                        value={currentGTM}
                        onChange={(_, newValue) => {
                          setCurrentGTM(newValue);
                        }}
                        inputValue={inputValue}
                        onInputChange={(_, newInputValue) => {
                          setInputValue(newInputValue);
                        }}
                        id="controllable-states-demo"
                        options={groupOptions}
                        sx={
                          {
                            width: 150,
                            marginLeft: 10
                          }
                        }
                        size='small'
                        renderInput={(params) =>
                          <TextField
                            {...params}
                            sx={{
                              '& .MuiOutlinedInput-root': {
                                '&.Mui-focused fieldset': {
                                  borderColor: rosneftBtnTheme.palette.orange.main,
                                }
                              }
                            }}
                          />}
                      />
                    </div>
                    <span>Выберите скважину для более подробной информации</span>
                    <WellSelector wellOptions={selectedWellsByGTM} handleSelectWell={handleSelectWell} selectedWell={selectedWell}/>
                  </div>
                  <div className='mt-3'>
                    <TableGroupStatistic data={selectedDataGTM}/>
                  </div>
                  <div className='table-container mt-3'>
                    <TableGTM/>
                  </div>
                  <div className='content charts mt-3' >
                    <ChartDistribution data={selectedDataGTM} columns={columns} wells={wells}/>
                  </div>
                </Col>
                <Col className="well-info-block mt-5" md={6}>
                  <h3>Информация по скважине</h3>
                  <div className='content mt-3'>
                    <span className='well-name'>Скважина: <b>{selectedWell ? selectedWell.name : null}</b></span>
                    <div className="table-container mt-3">
                      <TableWellStatistic data={selectedDataWell} columns={columns}/>
                    </div>
                  </div>
                  <div className='content mt-3'>
                    <ChartWell data={selectedDataWell} columns={columns}/>
                  </div>
                </Col>
              </Row>
            </Col>
          </Row>
        </Container>
      </LocalizationProvider>
    </QueryClientProvider>
  )
}

export default App

import {useEffect, useState} from 'react'
import { useMutation } from '@tanstack/react-query';
import { DatePicker } from "@mui/x-date-pickers";
import dayjs from "dayjs";
import axios from 'axios';

import { rosneftBtnTheme} from "./themes.jsx";
import { Row, Col } from 'react-bootstrap';
import './FileUploadBlock.css'
import DropZone from './Dropzone.jsx';

export default function FileUploaderBlock({ onLoadingChange, onDataChange }) {
    const [fileMer, setFileMer] = useState()
    const [fileGeo, setFileGeo] = useState()
    const [predictDate, setPredictDate] = useState(dayjs().add(1, 'month'))

    const uploadMutation = useMutation({
        mutationFn: async () => {
            const formData = new FormData();
            formData.append('file_mer', fileMer);
            formData.append('file_geology', fileGeo);
            formData.append('predict_date', predictDate.format('YYYY-MM-DD'));

            const response = await axios.post('http://localhost:8000/files',
                formData, 
                {
                    headers: {
                        'Accept': 'application/json',
                    },
                }
             );

            if (response.status >= 400) {
                const error = JSON.parse(response?.data?.message);
                throw new Error(error.message || 'Upload failed');
            }

            // Получаем JSON ответ от сервера
            return response.data
        },

        onSuccess: (data) => {
            console.log('Загружено! Ответ:', data);
        },

        onError: (error) => {
            console.error('Ошибка загрузки:', error);
        }
    });

    useEffect(() => {
        onLoadingChange?.(uploadMutation.isPending);
    }, [uploadMutation.isPending, onLoadingChange]);

    useEffect(() => {
        if (uploadMutation.data) {
            onDataChange?.(uploadMutation.data)
        }
    }, [uploadMutation.data, onDataChange]);

    return (
        <Row id="importFilesBlock" className="mt-5 justify-content-center">
            <Col className="title" md={3}>
              <h2>Загрузка исходных данных</h2>
            </Col>
            <Col id="filesDropForm" className="form" md={9}>
                <Row style={{ padding: '40px 120px 100px 120px' }}>
                    <Col md={12}>
                        <DatePicker
                            label="Месяц прогноза"
                            format="MM-YYYY"
                            size="small"
                            value={predictDate}
                            slotProps={{textField: {variant: 'standard', required: true}}}
                            sx={{
                                marginBottom: '10px',
                                '& .MuiInputLabel-root.Mui-focused': {
                                    color: rosneftBtnTheme.palette.orange.main,
                                },
                                '& .MuiPickersFilledInput-root.Mui-focused::after': {
                                    borderColor: rosneftBtnTheme.palette.orange.main,
                                },
                            }}
                            onChange={(date) => setPredictDate(date)}
                        />
                    </Col>
                    <Col className="formCell" md={6}>
                        <DropZone name="MER" text="Прикрепите файл МЭР" onAcceptedFile={setFileMer} required/>
                    </Col>
                    <Col className="formCell" md={6}>
                        <DropZone name="GEO" text="Прикрепите файл с геологией" onAcceptedFile={setFileGeo} required />
                    </Col>
                    <Col className="btnCell" md={12}>
                        <button type="submit" onClick={uploadMutation.mutate}>Собрать данные для прогноза</button>
                    </Col>
                </Row>
            </Col>
        </Row>
    )
}

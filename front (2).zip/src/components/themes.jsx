import { createTheme } from '@mui/material/styles';

export const rosneftTextFieldTheme = createTheme({
  components: {
    MuiInputBase: {
      styleOverrides: {
        root: {
          backgroundColor: '#ffffff',
        }
      }
    },
    MuiFormLabel: {
      styleOverrides: {
        root: {
          '&.Mui-focused': {
            color: '#303030ff !important',
          }
        }
      }
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          '&.Mui-focused fieldset': {
            borderColor: '#303030ff !important',
          },
        }
      }
    }
  },
});

export const rosneftBtnTheme = createTheme({
  palette: {
    orange: {
      main: '#F8BF03',
      light: '#fcd34a',
      dark: '#ffAA03',
      contrastText: '#1e1313',
      lightContrastText: '#ffffff',
    },
  },
});

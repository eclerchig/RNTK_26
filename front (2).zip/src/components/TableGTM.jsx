import './TableGTM.css'
import {Box, Paper, Stack, styled} from "@mui/material";
import Typography from "@mui/material/Typography";

const gtmRate = [
  { 
    id: 1, 
    name: '100', 
    gtm: {
        'ОПЗ': 70.0,
        'ИДН': 21.0,
        'ЛНЭК': 9.0,
    }
  },
  { 
    id: 2, 
    name: '1001А', 
    gtm: {
        'ОПЗ': 90.0,
        'ИДН': 5.0,
        'ЛНЭК': 5.0,
    }
  },
  { 
    id: 3, 
    name: '1010А', 
    gtm: {
        'ОПЗ': 15.0,
        'ИДН': 60.0,
        'ЛНЭК': 25.0,
    }
  },
];

const defineLevelQuality = (procent) => {
    if (procent <= 65) {
        return 'bad'
    } else if (procent <= 80) {
        return 'good'
    } else {
        return 'great'
    }
}

const TableGTM = (data) => {

    data = gtmRate
    const sortedData = data.map(item => {
        var sortedGtm = Object.fromEntries(
            Object.entries(item.gtm).sort(([, a], [, b]) => b - a)
        );


        return {
            ...item,
            quality: defineLevelQuality(Object.values(sortedGtm)[0]),
            gtm: sortedGtm
        };
    });

    const ColorDot = styled(Box)(({ theme, color }) => ({
        width: 16,
        height: 16,
        borderRadius: '50%',
        backgroundColor: color,
        marginRight: theme.spacing(1)
      }));

    return <>
        <table className='gtm-table'>
            <thead>
                <tr>
                    <th>Скважина</th>
                    <th>Мероприятие 1</th>
                    <th>Вероятность</th>
                    <th>Мероприятие 2</th>
                    <th>Вероятность</th>
                    <th>Мероприятие 3</th>
                    <th>Вероятность</th>
                </tr>
            </thead>
            <tbody>
                    {sortedData.map((row) => (
                        <tr className={`row-quality-${row.quality}`}>
                            <th>{row.name}</th>
                            {
                                Object.keys(row.gtm).map((key) =>
                                    <>
                                        <th>{key}</th>
                                        <th>{row.gtm[key]} %</th>
                                    </>
                                )
                            }
                        </tr>
                        ))}
            </tbody>
        </table>
        <Paper
            elevation={0}
            variant="outlined"
            sx={{ p: 2, bgcolor: 'grey.50' }}
          >
            <Typography variant="subtitle2" gutterBottom>
              Обозначение качества прогноза:
            </Typography>

            <Stack direction="row" spacing={3} flexWrap="wrap">
              <Stack direction="row" alignItems="center">
                <ColorDot color="#95c379" />
                <Typography variant="body2">Отличное</Typography>
              </Stack>

              <Stack direction="row" alignItems="center">
                <ColorDot color="#fcd34a" />
                <Typography variant="body2">Удовлетворительное</Typography>
              </Stack>

              <Stack direction="row" alignItems="center">
                <ColorDot color="#c76969" />
                <Typography variant="body2">Плохое</Typography>
              </Stack>
            </Stack>
          </Paper>
    </>
}

export default TableGTM
import {useState, useMemo, useEffect, useRef} from "react"
import {FormControl, Grid, InputLabel, MenuItem, Select, Typography, Paper, Popper} from "@mui/material"
import {BarPlot, ScatterChart, useItemTooltip, useAxisTooltip, ChartsXAxis, ChartsYAxis, ChartsTooltip, ChartsLegend, ChartDataProvider, ChartsSurface, ChartsTooltipContainer} from "@mui/x-charts"
import dayjs from "dayjs";
import {rosneftBtnTheme} from "./themes.jsx";

const colors = [
    'rgb(250, 79, 88)',
    'rgb(66, 84, 251)',
    'rgb(255, 180, 34)',
]

const CustomItemTooltip = ({ chartRef }) => {
  const tooltip = useItemTooltip()

    // Состояние для позиции мыши
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  // Отслеживаем движение мыши по графику
  useEffect(() => {
    const svgElement = chartRef?.current;
    if (!svgElement) return;

    const handleMouseMove = (event) => {
      // Получаем координаты мыши относительно окна
      setMousePosition({
        x: event.clientX,
        y: event.clientY,
      });
    };
    svgElement.addEventListener('mousemove', handleMouseMove);
    return () => {
      svgElement.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

    if (!tooltip) {
        return null
    }

    const virtualElement = {
        getBoundingClientRect: () => ({
          width: 0,
          height: 0,
          x: mousePosition.x,
          y: mousePosition.y,
          left: mousePosition.x,
          right: mousePosition.x,
          top: mousePosition.y,
          bottom: mousePosition.y,
        }),
   };

    return (
        <Popper
          open={true}
          anchorEl={virtualElement}
          placement="top-start"
          modifiers={[
            {
              name: 'flip',
              enabled: true,
              options: {
                padding: 8,
              },
            },
            {
              name: 'preventOverflow',
              enabled: true,
              options: {
                padding: 8,
              },
            },
            {
              name: 'offset',
              options: {
                offset: [10, -130], // [горизонталь, вертикаль] - смещаем на 10px вниз
              },
            },
          ]}
          // Важно! Отключаем портал, чтобы тултип был в том же контексте
          disablePortal={true}
          // Добавляем стили для правильного позиционирования
          style={{ zIndex: 9999 }}
        >
            <Paper elevation={0}
                sx={{
                    m: 1,
                    p: 1.5,
                    border: 'solid',
                    borderWidth: 1,
                    borderColor: 'divider',
                    table: { borderSpacing: 0 },
                    thead: {
                        td: {
                            px: 1.5,
                            py: 0.75,
                            border: 'none',
                            borderBottom: 'solid',
                            borderWidth: 1,
                            borderColor: 'divider',
                        }
                    },
                    tbody: {
                        'tr:first-of-type' : { td: { paddingTop: 1.5 } },
                        'tr:last-of-type' : { td: { paddingBottom: 1.5 } },
                        tr: {
                            'td:first-of-type' : { td: { paddingLeft: 1.5 } },
                            'td:last-of-type' : { td: { paddingRight: 1.5 } },
                            td: {
                                paddingLeft: '12px',
                                paddingRight: '7px',
                                paddingBottom: '10px'
                            }
                        }
                    }
                }}>
                <table>
                    <thead>
                        <tr>
                            <td colSpan={1}>
                                <div
                                style={{
                                    width: 10,
                                    height: 10,
                                    borderRadius: '50%',
                                    backgroundColor: tooltip.color
                                }}/>
                            </td>
                            <td>
                                <Typography fontWeight={600}>{tooltip.value.well}</Typography>
                            </td>
                            <td/>
                            <td/>
                            <td/>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colSpan={5}>
                                <Typography>
                                    {tooltip.value.x.format('DD-MM-YYYY')}: {tooltip.formattedValue}{` ${tooltip.value?.unit}`}
                                </Typography>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </Paper>
        </Popper>
    )
}

const CustomAxisTooltip = () => {
    const tooltip = useAxisTooltip()
    const tooltip2 = useItemTooltip()
    const firstAxisData = tooltip?.[0]
    console.log('firstAxisData', firstAxisData, tooltip, tooltip2)

    if (!firstAxisData) {
        return null
    }

    return (
        <Paper elevation={0}
            sx={{
                m: 1,
                border: 'solid',
                borderWidth: 2,
                borderColor: 'divider',
                table: { borderSpacing: 0 },
                thead: {
                    td: {
                        px: 1.5,
                        py: 0.75,
                        border: 'none',
                        borderBottom: 'solid',
                        borderWidth: 2,
                        borderColor: 'divider',
                    }
                },
                tbody: {
                    'tr:first-of-type' : { td: { paddingTop: 1.5 } },
                    'tr:last-of-type' : { td: { paddingBottom: 1.5 } },
                    tr: {
                        'td:first-of-type' : { td: { paddingLeft: 1.5 } },
                        'td:last-of-type' : { td: { paddingRight: 1.5 } },
                        td: {
                            paddingRight: '7px',
                            paddingBottom: '10px'
                        }
                    }
                }
            }}>
            <table>
                <thead>
                    <tr>
                        <td colSpan={3}>
                            <Typography>Интервал {firstAxisData.value}</Typography>
                        </td>
                        <td/>
                        <td/>
                        <td/>
                    </tr>
                </thead>
                <tbody>
                    {firstAxisData.seriesItems.map((seriesItem, index) => (
                        <tr key={seriesItem.seriesId}>
                            <td aria-label={`${seriesItem.formattedLabel}-series-color`}>
                                <div
                                    style={{
                                        width: 10,
                                        height: 10,
                                        borderRadius: '50%',
                                        backgroundColor: seriesItem.color,
                                    }}
                                />
                            </td>
                            <td>
                                <Typography fontWeight="light">
                                    {seriesItem.formattedLabel}
                                </Typography>
                            </td>
                            <td>
                                <Typography>
                                    {seriesItem.formattedValue}
                                </Typography>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </Paper>
    )
}

export default function ChartDistribution({data, columns, wells}) {
    const [selectedValue, setSelectedValue] = useState(null)
    const [maxCountHist, setMaxCountHist] = useState(0)

    const groupsGTM = useMemo(() => wells ? [...new Set(wells.map((well) => well.gtm))] : [], [wells])

    const chartData = useMemo(() => {
        const data_ = {}
        groupsGTM.forEach(gtm => {
            const wellsGTM = gtm ? [...new Set(wells.filter(well => well.gtm === gtm).map(well => well.name))] : [...new Set(wells.map(well => well.name))]
            const filter = data && data.length > 0 && selectedValue?.value
                ? data
                    .filter(row => wellsGTM.includes(row.well))
                    .map(row => {
                        const currentAccessorKey = selectedValue?.value
                        const filteredColumns = columns.filter(col => col.accessorKey === currentAccessorKey)
                        return {
                        x: row.date,
                        y: String(currentAccessorKey).startsWith('geology') 
                           ? row['geology'][String(currentAccessorKey).split('.')[1]]
                           : row[currentAccessorKey],
                        well: row.well,
                        unit: filteredColumns.length > 0 && filteredColumns[0]?.unit ? filteredColumns[0].unit : '' }
                    })
                : []
            if (filter.length !== 0) {
                data_[gtm] = filter 
            }
        })
        return data_
    }, [data, groupsGTM, selectedValue])

    const histData = useMemo(() => {
        const data = Object.fromEntries(
            Object.entries(chartData).map(([gtm, rows]) => [gtm, rows.map(row => row.y)])
        );
        const values = [...new Set(Object.values(data).flat())]

        const n = values.length
        const binCount = Math.max(
            Math.ceil(1 + Math.log2(n)),
            15
        )

        const min = Math.min(...values)
        const max = Math.max(...values)
        const binSize = (max - min) / binCount
        const bins = []  

        for (let i = 0; i < binCount; i++) {
            const start = min + i * binSize
            const end = i === binCount - 1 ? max : min + (i + 1) * binSize
            bins.push({
                label: `${start.toFixed(1)}-${end.toFixed(1)}`,
                start,
                end,
            })
        }

        const countValuesInBins = (values) => {
            const counts = new Array(binCount).fill(0)
            values.forEach(value => {
                for(let i = 0; i < bins.length; i++) {
                    const bin = bins[i]
                    if (value >= bin.start && value <= bin.end){
                        counts[i]++
                        break
                    }
            }})
            return counts
        }

        return Object.fromEntries(
            Object.entries(data).map(([gtm, values]) => {
                return [gtm, {bins: bins.map(bin => bin.label), counts: countValuesInBins(values)}]
            })
        );
    }, [chartData])

    const chartRef = useRef(null);
    
    const handleChangeSelector = (e) => {
        const value = e.target.value
        const label = columns.find(col => col.accessorKey === value,).header
        setSelectedValue({
            value: value,
            label: label,
        })
    }

    const bins = useMemo(() => {
        const counts = Object.values(histData).map(item => item.counts)
        console.log(counts)
        if (counts.length > 0){
            const length = counts[0].length
            const sumCounts = Array.from({length: length}, (_, index) =>
                counts.reduce((sum, arr) => sum + (arr[index] || 0), 0)
            )
            setMaxCountHist(Math.max(...sumCounts)*1.5)
        }
        return histData[Object.keys(histData)[0]]?.bins && histData[Object.keys(histData)[0]].bins
    }, [histData])

    const formatHistTick = (value, index) => {
        if (bins.length > 10) {
            const [start, end] = value.split('-')
            return `${Math.round(Number(start))}`
        }
        return value
    }

    return (
        <Grid container spacing={3} width="100%" mb={3}>
            <Grid item size={12}>
                <Typography variant="h5">Инфографика групп ГТМ</Typography>
            </Grid>
            <Grid item size={6}>
                <FormControl
                    fullWidth
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            '&.Mui-focused fieldset': {
                                borderColor: rosneftBtnTheme.palette.orange.main,
                            }},
                        '& .MuiFormLabel-root': {
                            top: '-7px',
                            '&.Mui-focused': {
                                color: rosneftBtnTheme.palette.orange.main,
                                transform: 'translate(15px, -3px) scale(0.75)',
                            }},
                    }}
                >
                    <InputLabel>Показатель</InputLabel>
                    <Select
                        value={selectedValue?.value}
                        label="Показатель"
                        onChange={(e) => handleChangeSelector(e)}
                        size='small'
                        MenuProps={{
                            PaperProps: {
                                style: {
                                    maxHeight: '200px',
                                }
                            }
                        }}
                    >
                        {
                            columns
                            .filter(col => !['well', 'mainWell', 'date'].includes(col.accessorKey))
                            .map(col => (
                                <MenuItem key={col.accessorKey} value={col.accessorKey}>
                                    {col.header}
                                </MenuItem> 
                            ))
                        }
                    </Select>
                </FormControl>
            </Grid>
            { chartData && Object.keys(chartData).length > 0 
                ?
                <>
                <Grid item size={12} height={'400px'} ref={chartRef}>
                { chartData && Object.keys(chartData).length > 0 
                ? 
                    <ScatterChart
                        series={
                            Object.keys(chartData).map((gtm, i) => ({
                                label: `Группа ${gtm}`,
                                data: chartData[gtm],
                                color: colors[i],
                                valueFormatter: (v) => {
                                    return `${v.y}`
                                }
                            }))
                        }
                        xAxis={[{
                            label: 'Дата',
                            scaleType: 'time',
                            valueFormatter: (value) => {
                                return dayjs(value).format('DD-MM-YYYY')
                            },
                            tickInterval: (date, index) => {
                                return dayjs(date).date() === 1;
                            },
                            height: 90,
                            // tickMaxStep: 26 * 60 * 60 * 1000 * 28 * 1.5 , // месяц в миллисекундах

                            tickLabelStyle: {
                                angle: 45,
                            }
                        }]}
                        yAxis={[{
                            label: selectedValue?.label,
                        }]}
                        slots={{
                            tooltip: (props) => <CustomItemTooltip {...props} chartRef={chartRef}/>,
                        }}
                        slotProps={{
                            tooltip: {
                              trigger: 'item',
                              anchor: 'pointer',
                          },
                        }}
                        grid={{vertical: true, horizontal: true}}
                    />
                : null}
            </Grid>
            <Grid item size={12} height={'400px'}>
                <ChartDataProvider
                    series={
                        Object.keys(histData).map((gtm, i) => ({ 
                            type: 'bar',
                            label: `Группа ${gtm}`,
                            data: histData[gtm].counts,
                            color: colors[i],
                            stack: 'total',
                        }))
                    }
                    xAxis={[{
                        id: 'main-x-axis',
                        label: 'Распределение частот',
                        scaleType: 'band',
                        data: histData[Object.keys(histData)[0]].bins,
                        height: bins.length > 10 ? 80 : 90,
                        tickLabelStyle: {
                            angle: 45,
                        },
                        valueFormatter: formatHistTick, 
                    }]}
                    yAxis={[{
                        label: 'Количество',
                        max: maxCountHist,
                    }]}
                    // margin={{
                    //     top: 60,
                    // }}
                >
                    <ChartsLegend sx={{ justifyContent: 'center' }}/>

                    <ChartsSurface>
                        <BarPlot/>
                        <ChartsXAxis
                            position="bottom"
                            tickInterval={bins.length > 15 ? 'auto' : undefined}
                        />
                        <ChartsYAxis/>
                    </ChartsSurface>
                    
                    {/* <CustomAxisTooltip trigger="axis"/> */}
                    <ChartsTooltip/>
                    {/* <ChartsTooltip trigger="axis" axisContent={CustomAxisTooltip}/> */}

                </ChartDataProvider>
            </Grid>
                </>
            : null}
        </Grid>
    )
}
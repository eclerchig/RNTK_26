import react, { useState, useMemo } from 'react'
import {MaterialReactTable, MRT_EditActionButtons} from 'material-react-table'
import { MRT_Localization_RU } from 'material-react-table/locales/ru';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { rosneftBtnTheme} from "./themes.jsx";
import {useMutation, useQueryClient} from '@tanstack/react-query'
import * as Yup from 'yup'
import {
    Box,
    Button,
    DialogActions,
    DialogContent,
    DialogTitle,
    Tooltip,
    IconButton,
    TextField
} from "@mui/material";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import {DatePicker} from "@mui/x-date-pickers";
import dayjs from "dayjs";
import axios from "axios";

const StyledTextFieldDialog = (props) => {
    const {color, column, row, cell} = props
    return <TextField
        fullWidth
        color={color}
        label={column.columnDef.header}
        variant="standard"
        size="small"
        disabled={row.id !== "mrt-row-create"}
        defaultValue={cell.getValue()}
        required
    />
}

const dataScheme = Yup.object().shape({
    well: Yup.string().required('Required'),
    mainWell: Yup.string().required('Required'),
    debitOil: Yup.number().required('Required').min(0),
    debitLiq: Yup.number().required('Required').min(0),
    watercut: Yup.number().required('Required').min(0).max(100),
    cumOil: Yup.number().required('Required').min(0),
    cumLiq: Yup.number().required('Required').min(0),
    timeWorkProd: Yup.number().required('Required').min(0).max(744),
    solidPress: Yup.number().required('Required').min(0),
    downholePress: Yup.number().required('Required').min(0),
    debitOilFirst: Yup.number().required('Required').min(0),
    debitLiqFirst: Yup.number().required('Required').min(0),
    dynLevel: Yup.number().required('Required').min(0),
    pushTR: Yup.number().required('Required').min(0),
    geology: Yup.object().shape({
        porosity: Yup.number().required('Required').min(0),
        permeability: Yup.number().required('Required').min(0),
        kh: Yup.number().required('Required').min(0),
        onntDensity: Yup.number().required('Required').min(0),
        onnt: Yup.number().required('Required').min(0),
        initOilSaturation: Yup.number().required('Required').min(0),
        nnt: Yup.number().required('Required').min(0),
        }

    )
 });

export const columns = [
    {
        accessorKey: 'well',
        header: 'Ствол',
        size: 150,
    },
    {
        accessorKey: 'mainWell',
        header: 'Скважина',
        size: 150,
    },
    {
        accessorKey: 'date',
        header: 'Дата МЭР',
        size: 150,
    },
    {
        accessorKey: 'debitOil',
        header: 'Дебит нефти, т/сут',
        size: 150,
        unit: 'т/сут',
    },
    {
        accessorKey: 'debitLiq',
        header: 'Дебит жидкости, т/сут',
        size: 150,
        unit: 'т/сут',
    },
    {
        accessorKey: 'watercut',
        header: 'Обводненность, %',
        size: 150,
        unit: '%',
    },
    {
        accessorKey: 'cumOil',
        header: 'Накопленный отбор нефти, т',
        size: 150,
        unit: 'т',
    },
    {
        accessorKey: 'cumLiq',
        header: 'Накопленный отбор жидкости, т',
        size: 150,
        unit: 'т',
    },
    {
        accessorKey: 'timeWorkProd',
        header: 'Время работы в добыче, часы',
        size: 150,
        unit: 'ч',
    },
    {
        accessorKey: 'solidPress',
        header: 'Пластовое давление (ТР), атм',
        size: 150,
        unit: 'атм',
    },
    {
        accessorKey: 'downholePress',
        header: 'Забойное давление (замер), атм',
        size: 150,
        unit: 'атм',
    },
    {
        accessorKey: 'debitOilFirst',
        header: 'Дебит нефти за первый раб.месяц, т/сут',
        size: 150,
        unit: 'т/сут',
    },
    {
        accessorKey: 'debitLiqFirst',
        header: 'Дебит жидкости за первый раб.месяц, т/сут',
        size: 150,
        unit: 'т/сут',
    },
    {
        accessorKey: 'dynLevel',
        header: 'Динамический уровень (ТР), м',
        size: 150,
        unit: 'м',
    },
    {
        accessorKey: 'pushTR',
        header: 'Напор (ТР)',
        size: 150,
    },
    {
        accessorKey: 'geology.porosity',
        header: 'Пористость',
        size: 150,
    },
    {
        accessorKey: 'geology.permeability',
        header: 'Проницаемость',
        size: 150,
    },
    {
        accessorKey: 'geology.kh',
        header: 'KH проводимость',
        size: 150,
    },
    {
        accessorKey: 'geology.onntDensity',
        header: 'Плотность ОННТ',
        size: 150,
    },
    {
        accessorKey: 'geology.onnt',
        header: 'ОННТ',
        size: 150,
    },
    {
        accessorKey: 'geology.initOilSaturation',
        header: 'Нач. нефтенасыщенность',
        size: 150,
    },
    {
        accessorKey: 'geology.nnt',
        header: 'ННТ',
        size: 150,
    }
]

// export const data = [
//         {
//             well: '100',
//             mainWell: '100',
//             date: dayjs('01-10-2010', 'DD-MM-YYYY'),
//             debitOil: 206,
//             debitLiq: 231,
//             watercut: 10,
//             cumOil: 6651,
//             cumLiq: 7422,
//             timeWorkProd: 744,
//             solidPress: 265,
//             downholePress: 128,
//             debitOilFirst: 289,
//             debitLiqFirst: 304,
//             dynLevel: 1446,
//             pushTR: 1567,
//             geology: {
//                 porosity: 0.24,
//                 permeability: 164,
//                 kh: 16713,
//                 onntDensity: 0,
//                 onnt: 5,
//                 initOilSaturation: 0,
//                 nnt: 6,
//             }
//         },
//         {
//             well: '100',
//             mainWell: '100',
//             date: dayjs('01-11-2010', 'DD-MM-YYYY'),
//             debitOil: 101,
//             debitLiq: 130,
//             watercut: 22,
//             cumOil: 9685,
//             cumLiq: 11349,
//             timeWorkProd: 720,
//             solidPress: 265,
//             wellheadPress: 117,
//             debitOilFirst: 289,
//             debitLiqFirst: 304,
//             dynLevel: 1446,
//             pushTR: 1567,
//             geology: {
//                 porosity: 0.24,
//                 permeability: 164,
//                 kh: 16713,
//                 onntDensity: 0,
//                 onnt: 5,
//                 initOilSaturation: 0,
//                 nnt: 6,
//             }
//         },
//         {
//             well: '1001А',
//             mainWell: '1001',
//             date: dayjs('01-05-2018', 'DD-MM-YYYY'),
//             debitOil: 87,
//             debitLiq: 148,
//             watercut: 40,
//             cumOil: 1532,
//             cumLiq: 2594,
//             timeWorkProd: 419,
//             solidPress: 125,
//             wellheadPress: 88,
//             debitOilFirst: 87,
//             debitLiqFirst: 148,
//             dynLevel: 818,
//             pushTR: 1605,
//             geology: {
//                 porosity: 0.27,
//                 permeability: 338,
//                 kh: 28108,
//                 onntDensity: 0.88,
//                 onnt: 11,
//                 initOilSaturation: 0.58,
//                 nnt: 12,
//             }
//         },
//         {
//             well: '1001А',
//             mainWell: '1001',
//             date: dayjs('01-06-2018', 'DD-MM-YYYY'),
//             debitOil: 0,
//             debitLiq: 0,
//             watercut: 0,
//             cumOil: 29882,
//             cumLiq: 48678,
//             timeWorkProd: 419,
//             solidPress: 135,
//             wellheadPress: 131,
//             debitOilFirst: 87,
//             debitLiqFirst: 148,
//             dynLevel: 1207,
//             pushTR: 2046,
//             geology: {
//                 porosity: 0.27,
//                 permeability: 338,
//                 kh: 28108,
//                 onntDensity: 0.88,
//                 onnt: 11,
//                 initOilSaturation: 0.58,
//                 nnt: 12,
//             }
//         },
//         {
//             well: '1010А',
//             mainWell: '1010',
//             date: dayjs('01-10-2021', 'DD-MM-YYYY'),
//             debitOil: 0,
//             debitLiq: 0,
//             watercut: 0,
//             cumOil: 5,
//             cumLiq: 271,
//             timeWorkProd: 0,
//             solidPress: 160,
//             wellheadPress: 72,
//             debitOilFirst: 0,
//             debitLiqFirst: 35,
//             dynLevel: 0,
//             pushTR: null,
//             geology: {
//                 porosity: 0.26,
//                 permeability: 476,
//                 kh: 40251,
//                 onntDensity: 0.21,
//                 onnt: 8,
//                 initOilSaturation: 0.41,
//                 nnt: 10,
//             }
//         },
//         {
//             well: '1010А',
//             mainWell: '1010',
//             date: dayjs('01-11-2021', 'DD-MM-YYYY'),
//             debitOil: 0,
//             debitLiq: 35,
//             watercut: 0,
//             cumOil: 28,
//             cumLiq: 1345,
//             timeWorkProd: 720,
//             solidPress: 160,
//             wellheadPress: 134,
//             debitOilFirst: 0,
//             debitLiqFirst: 35,
//             dynLevel: 0,
//             pushTR: null,
//             geology: {
//                 porosity: 0.26,
//                 permeability: 476,
//                 kh: 40251,
//                 onntDensity: 0.21,
//                 onnt: 8,
//                 initOilSaturation: 0.41,
//                 nnt: 10,
//             }
//         }
//     ]

const ExampleTable = ({ data }) => {

    console.log('ExampleTable', data)

    const [validationErrors, setValidationErrors] = useState({})
    const {mutateAsync: updateRow, isPending: isUpdatingRow} = useUpdateRow()
    const {mutateAsync: deleteRow, isPending: isDeletingRow} = useDeleteRow()

    // // СRUD handlers
    // const handleCreateRow = async (values, table) => {
    //     let dataValidated = undefined
    //     try {
    //         await dataScheme.validate(
    //             values,
    //             {
    //                 abortEarly: false,
    //             })
    //         setValidationErrors({})
    //         table.setCreatingRow(null)
    //     } catch (error) {
    //         if (error.inner && error.inner.length > 0) {
    //             const errors = error.inner.reduce((acc, err) => {
    //                 acc[err.path] = err.message
    //                 return acc
    //             })
    //             setValidationErrors(errors)
    //         }
    //     }
    // }

    const handleUpdateRow = async (values, table) => {
        dataScheme.validate(
            values,
            {
                abortEarly: false,
            }).then(async (valid) => {
                setValidationErrors({})
                await updateRow(values)
                table.setEditingRow(null)
            }).catch(err => {
                if (err.inner && err.inner.length > 0) {
                    const errors = err.inner.reduce((acc, err) => {
                        acc[err.path] = err.message
                        return acc
                    })
                    setValidationErrors(errors)
                }
        })
    }

    const openDeleteConfirmModal = async (row) => {
        if (window.confirm('Вы действительно хотите удалить запись?')) {
          await deleteRow(row.original.id);
        }
    };


    function useUpdateRow() {
        return useMutation({
            mutationFn: async (values) => {
                await axios.put('http://localhost:8000/update', values);
        }})
    }

    function useDeleteRow() {
        return useMutation({
            mutationFn: async (id) => {
                const response = await axios.delete('http://localhost:8000/delete', {id: id})},
        })
    }

    const columns = useMemo(() => [
        {
            accessorKey: 'well',
            header: 'Ствол',
            size: 150,
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'string',
                error: !!validationErrors?.well,
                helperText: validationErrors?.well,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        well: undefined,
                    })
            }

        },
        {
            accessorKey: 'wellMain',
            header: 'Скважина',
            size: 150,
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'string',
                error: !!validationErrors?.mainWell,
                helperText: validationErrors?.mainWell,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        mainWell: undefined,
                    })
            }
        },
        {
            accessorKey: 'date',
            header: 'Дата МЭР',
            size: 150,
            Edit: ({cell, column, row}) => {
                const value = cell.getValue();
                return (
                    <DatePicker
                        label={column.columnDef.header}
                        format="DD-MM-YYYY"
                        disabled={row.id !== "mrt-row-create"}
                        defaultValue={value ? value : undefined}
                        slotProps={{textField: {variant: 'standard', required: true}}}
                        sx={{
                            '& .MuiInputLabel-root.Mui-focused': {
                                color: rosneftBtnTheme.palette.orange.main,
                            },
                            '& .MuiPickersFilledInput-root.Mui-focused::after': {
                                borderColor: rosneftBtnTheme.palette.orange.main,
                            },
                        }}
                    />
                );
            },
            Cell: ({cell}) => {
                const value = cell.getValue();
                return <div>{dayjs.isDayjs(value) ? value.format('DD-MM-YYYY') : undefined}</div>
            },
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'string',
                error: !!validationErrors?.date,
                helperText: validationErrors?.date,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        date: undefined,
                    })
            }
        },
        {
            accessorKey: 'debitOil',
            header: 'Дебит нефти, т/сут',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'debitLiq',
            header: 'Дебит жидкости, т/сут',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'watercut',
            header: 'Обводненность, %',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'cumOil',
            header: 'Накопленный отбор нефти, т',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'cumLiq',
            header: 'Накопленный отбор жидкости, т',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'timeWorkProd',
            header: 'Время работы в добыче, часы',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'solidPress',
            header: 'Пластовое давление (ТР), атм',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'downholePress',
            header: 'Забойное давление (замер), атм',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'debitOilFirst',
            header: 'Дебит нефти за первый раб.месяц, т/сут',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'debitLiqFirst',
            header: 'Дебит жидкости за первый раб.месяц, т/сут',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'dynLevel',
            header: 'Динамический уровень (ТР), м',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'pushTR',
            header: 'Напор (ТР)',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'geology.porosity',
            header: 'Пористость',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'geology.permeability',
            header: 'Проницаемость',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'geology.kh',
            header: 'KH проводимость',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'geology.onntDensity',
            header: 'Плотность ОННТ',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'geology.onnt',
            header: 'ОННТ',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'geology.initOilSaturation',
            header: 'Нач. нефтенасыщенность',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        },
        {
            accessorKey: 'geology.nnt',
            header: 'ННТ',
            size: 150,
            enableEditing: true,
            muiEditTextFieldProps: {
                required: true,
                type: 'number',
                error: !!validationErrors?.debitOil,
                helperText: validationErrors?.debitOil,
                onFocus: () =>
                    setValidationErrors({
                        ...validationErrors,
                        firstName: undefined,
                    })
            },
            Edit: ({cell, column, row}) => {
                return <StyledTextFieldDialog color='orange' column={column} row={row} cell={cell}/>
            },
        }
    ], [validationErrors])


    return <MaterialReactTable
        columns={columns}
        data={data}
        localization={MRT_Localization_RU}
        createDisplayMode='modal'
        editDisplayMode='modal'
        enableEditing
        getRowId={(row, index) => `${index}`}
        muiTableContainerProps={{
            sx: {
                minHeight: '500px',
            },
        }}
        // onCreatingRowCancel={() => setValidationErrors({})}
        // onCreatingRowSave={handleCreateRow}
        onEditingRowCancel={() => setValidationErrors({})}
        onEditingRowSave={handleUpdateRow}
        // renderCreateRowDialogContent={({table, row, internalEditComponents}) => (
        //     <>
        //         <ThemeProvider theme={rosneftBtnTheme}>
        //             <DialogTitle variant="h3">Добавление строки данных</DialogTitle>
        //             <DialogContent
        //                 sx={{display: 'flex', flexDirection: 'column', gap: '1rem'}}
        //             >{internalEditComponents}
        //             </DialogContent>
        //             <DialogActions>
        //                 <MRT_EditActionButtons
        //                     variant="text"
        //                     table={table}
        //                     row={row}
        //                     sx={{
        //                         '& .MuiButton-root:first-of-type': {
        //                           color: rosneftBtnTheme.palette.orange.contrastText,
        //                           border: `1px solid ${rosneftBtnTheme.palette.orange.main}`,
        //                             '&:hover': {
        //                             background: rosneftBtnTheme.palette.orange.light,
        //                           },
        //                         },
        //                         '& .MuiButton-root:last-of-type': {
        //                           background: rosneftBtnTheme.palette.orange.main,
        //                           color: rosneftBtnTheme.palette.primary.contrastText,
        //                           '&:hover': {
        //                             background: rosneftBtnTheme.palette.orange.dark,
        //                           },
        //                         },
        //                     }}/>
        //             </DialogActions>
        //         </ThemeProvider>
        //     </>
        // )}
        renderEditRowDialogContent={({table, row, internalEditComponents}) => (
            <>
                <ThemeProvider theme={rosneftBtnTheme}>
                <DialogTitle variant="h3">Редактировать данные</DialogTitle>
                    <DialogContent
                        sx={{display: 'flex', flexDirection: 'column', gap: '1.5rem'}}
                    >
                        {internalEditComponents}
                    </DialogContent>
                    <DialogActions>
                        <MRT_EditActionButtons
                            variant="text"
                            table={table}
                            row={row}
                            sx={{
                                '& .MuiButton-root:first-of-type': {
                                  color: rosneftBtnTheme.palette.orange.contrastText,
                                  border: `1px solid ${rosneftBtnTheme.palette.orange.main}`,
                                    '&:hover': {
                                    background: rosneftBtnTheme.palette.orange.light,
                                  },
                                },
                                '& .MuiButton-root:last-of-type': {
                                  background: rosneftBtnTheme.palette.orange.main,
                                  color: rosneftBtnTheme.palette.primary.contrastText,
                                  '&:hover': {
                                    background: rosneftBtnTheme.palette.orange.dark,
                                  },
                                },
                            }}/>
                    </DialogActions>
                </ThemeProvider>
            </>
        )}
        renderRowActions={({row, table}) => (
            <Box sx={{display: 'flex', gap: '1rem'}}>
                <Tooltip title="Редактировать">
                    <IconButton onClick={() => table.setEditingRow(row)}>
                        <EditIcon/>
                    </IconButton>
                </Tooltip>
                <Tooltip title="Удалить">
                    <IconButton color="error" onClick={() => openDeleteConfirmModal(row)}>
                        <DeleteIcon/>
                    </IconButton>
                </Tooltip>
            </Box>
        )}
        renderTopToolbarCustomActions={({table}) => (
            <ThemeProvider theme={rosneftBtnTheme}>
                <Box sx={{display: 'flex', gap: '1rem'}}>
                    <Button
                        variant="contained"
                        color="orange"
                        onClick={() => {
                            table.setCreatingRow(true);
                        }}
                    >
                        Добавить строку
                    </Button>
                    <Button
                        variant="contained"
                        color="orange"
                        onClick={() => {
                        }}
                    >
                        Сохранить все изменения
                    </Button>
                </Box>
            </ThemeProvider>
        )}
    />
}

export default ExampleTable
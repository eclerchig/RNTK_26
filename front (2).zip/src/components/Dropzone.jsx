import { useDropzone } from 'react-dropzone';
import {useRef} from 'react'

import './Dropzone.css'

export default function DropZone(props) {
    const {required, name, text, onAcceptedFile} = props

    const hiddeninputRef = useRef(null)
    
    const {getRootProps, getInputProps, open, acceptedFiles} = useDropzone({
        onDrop: (incomingFiles) => {
            if (hiddeninputRef.current) {
                const dataTransfer = new DataTransfer()
                console.log('dataTransfer', dataTransfer)
                incomingFiles.forEach((v) => {
                    dataTransfer.items.add(v)
                })
                hiddeninputRef.current.files = dataTransfer.files
                onAcceptedFile(dataTransfer.files[0])
            }
        }
    })

    const files = acceptedFiles.map(file => (
        <li key={file.path}>
            {file.path} - {file.size} bytes
        </li>
    ))

    const icon = 
        <svg 
            className='icon'
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg">
            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
            <g id="SVGRepo_iconCarrier">
                <path fill="white" opacity="0.7" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="#d77b00" stroke-width="1.752"></path>  
                <path d="M12 17L12 10M12 10L15 13M12 10L9 13" stroke="rgb(245 138 4)" stroke-width="1.752" stroke-linecap="round" stroke-linejoin="round"></path> 
                <path d="M16 7H12H8" stroke="rgb(245 138 4)" stroke-width="1.752" stroke-linecap="round"></path> 
                
            </g>
        </svg>

    return (
        <div className='container'>
            <div
            {...getRootProps({className: "dropzone"})}
            >
                <input type="file" name={name} required={required} style={{opacity: 0}} ref={hiddeninputRef}/>
                <input {...getInputProps()}/>
                <p className='dropZone-title'>{icon}<br/>{text}</p>
            </div>
        </div>
    )
}

// const SimpleDropzone = () => {
//     const onDrop = useCallback(acceptedFiles => {

//     }, [])
//     const {getRootProps, getInputProps, isDragActive} = useDropzone({onDrop})

//     return (
//         <div {...getRootProps()}>
//             <input {...getInputProps()}/>
//             <p className='dropZone-title'>drop here</p>
//         </div>
//     )
// }

// export { SimpleDropzone }
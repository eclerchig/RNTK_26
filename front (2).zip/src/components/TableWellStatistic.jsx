import './TableWellStatistic.css'

const TableWellStatistic = ({ data, columns }) => {
    return <>
        <table className='stat_table'>
            <thead>
                <tr>
                    <th className="table-h-divider" colSpan="100%"> {/* или конкретное число */}
                         Показатели МЭР
                    </th>
                </tr>
                <tr>
                    <th className='date-cell'>Дата</th>
                    {columns.map((col) => {
                        const isNecessary = col.accessorKey && !col.accessorKey.startsWith("geology") && !['well', 'mainWell', 'date'].includes(col.accessorKey)
                        return col.accessorKey && isNecessary ? <th>{col.header}</th> : null
                    })}
                </tr>
            </thead>
            <tbody>
                    {data.map((row) => (
                        <tr>
                            <th className='date-cell'>{row.date.format('DD-MM-YYYY')}</th>
                            {columns.map((col) => {
                                const isNecessary = col.accessorKey && !col.accessorKey.startsWith("geology") && !['well', 'mainWell', 'date'].includes(col.accessorKey)
                                return col.accessorKey && isNecessary ? <th style={{fontWeight: '300'}}>{row[col.accessorKey]}</th> : null
                            })}
                        </tr>
                        ))}
            </tbody>
        </table>
        <table className='stat_table'>
            <thead>
                <tr>
                    <th className="table-h-divider" colSpan="100%"> {/* или конкретное число */}
                        Геология
                    </th>
                </tr>
                <tr>
                    <th className='date-cell'>Дата</th>
                    {columns.map((col) => {
                        const isNecessary = col.accessorKey && col.accessorKey.startsWith("geology") && !['well', 'mainWell', 'date'].includes(col.accessorKey)
                        return col.accessorKey && isNecessary ? <th>{col.header}</th> : null
                    })}
                </tr>
            </thead>
            <tbody>
                    {data.map((row) => (
                        <tr>
                            <th className='date-cell'>{row.date.format('DD-MM-YYYY')}</th>
                            {columns.map((col) => {
                                const subkey = col.accessorKey.split('.')[1]
                                const isNecessary = col.accessorKey && col.accessorKey.startsWith("geology") && !['well', 'mainWell', 'date'].includes(col.accessorKey)
                                return col.accessorKey && isNecessary ? <th style={{fontWeight: '300'}}>{row['geology'][subkey]}</th> : null
                            })}
                        </tr>
                        ))}
            </tbody>
        </table>
    </>
}

export default TableWellStatistic
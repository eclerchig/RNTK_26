import {Box} from "@mui/material";
import Typography from "@mui/material/Typography";
import {ChartsTooltip, LineChart} from "@mui/x-charts";

const goodROCDemo = {
  "fpr": [0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.7, 1],
  "tpr": [0, 0.3, 0.5, 0.65, 0.75, 0.85, 0.9, 0.95, 0.98, 1],
  "thresholds": [1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0],
  "auc": 0.8523
};
const goodChartData = [
  { fpr: 0, tpr: 0, threshold: 1, name: "Точка 1" },
  { fpr: 0.05, tpr: 0.3, threshold: 0.9, name: "Точка 2" },
  { fpr: 0.1, tpr: 0.5, threshold: 0.8, name: "Точка 3" },
  { fpr: 0.15, tpr: 0.65, threshold: 0.7, name: "Точка 4" },
  { fpr: 0.2, tpr: 0.75, threshold: 0.6, name: "Точка 5" },
  { fpr: 0.3, tpr: 0.85, threshold: 0.5, name: "Точка 6" },
  { fpr: 0.4, tpr: 0.9, threshold: 0.4, name: "Точка 7" },
  { fpr: 0.5, tpr: 0.95, threshold: 0.3, name: "Точка 8" },
  { fpr: 0.7, tpr: 0.98, threshold: 0.2, name: "Точка 9" },
  { fpr: 1, tpr: 1, threshold: 0, name: "Точка 10" }
];

export default function ChartROCAUC() {
    return (
      <>
            <Typography variant="h6" gutterBottom>
              (AUC = {goodROCDemo?.auc?.toFixed(2)})
            </Typography>
            <Box sx={{ height: '300px', width: '400px'}}>
              <LineChart
                dataset={goodChartData}
                xAxis={[{
                  dataKey: 'fpr',
                  label: 'False Positive Rate (FPR)',
                  min: 0,
                  max: 1,
                  tickNumber: 10,
                  tickSpacing: 0.1,
                  tickPlacement: 'middle',
                  valueFormatter: (value) => value.toFixed(1)
                }]}
                yAxis={[{
                  datakey: 'tpr',
                  label: 'True Positive Rate (TPR)',
                  min: 0,
                  max: 1,
                  tickNumber: 10,
                  valueFormatter: (value) => value.toFixed(1)
                }]}
                series={[
                  {
                    dataKey: 'tpr',
                    label: 'ROC кривая',
                    color: '#4254fb',
                    showMark: false,
                    curve: "stepBefore",
                    valueFormatter: (value) => value.toFixed(3)
                  }
                ]}
                grid={{ vertical: true, horizontal: true }}
                tooltip={{ trigger: 'item' }}
                legend={{ hidden: true }}
                margin={{ top: 10, bottom: 50, left: 60, right: 20 }}
              >
                <ChartsTooltip />
              </LineChart>
            </Box>
            </>
    )
}
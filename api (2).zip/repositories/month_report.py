from database.models import MonthReport, Statistics
from schemas.MonthReport import MonthReportScheme, MonthReportSchemeGet
from schemas.statistics  import StatisticsScheme, StatisticsSchemeGet

from interfaces.repository import SQLAlchemyRepository


class MonthReportRepository(SQLAlchemyRepository):
    model = MonthReport
    scheme = MonthReportScheme
    scheme_get = MonthReportSchemeGet

class StatisticsRepository(SQLAlchemyRepository):
    model = Statistics
    scheme = StatisticsScheme
    scheme_get = StatisticsSchemeGet
from database.models import Calculations
from schemas.calculations import CalculationsScheme, CalculationsSchemeGet
from interfaces.repository import SQLAlchemyRepository


class CalculationsRepository(SQLAlchemyRepository):
    model = Calculations
    scheme = CalculationsScheme
    scheme_get = CalculationsSchemeGet
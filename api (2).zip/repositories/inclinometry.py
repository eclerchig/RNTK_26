from database.models import Inclinometries
from schemas.inclinometry import InclinometriesScheme, InclinometriesSchemeGet
from interfaces.repository import SQLAlchemyRepository


class InclinometryRepository(SQLAlchemyRepository):
    model = Inclinometries
    scheme = InclinometriesScheme
    scheme_get = InclinometriesSchemeGet
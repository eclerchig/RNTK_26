from database.models import Cells
from schemas.cells import CellsScheme, CellsSchemeGet
from interfaces.repository import SQLAlchemyRepository


class CellsRepository(SQLAlchemyRepository):
    model = Cells
    scheme = CellsScheme
    scheme_get = CellsSchemeGet
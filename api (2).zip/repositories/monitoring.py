from database.models import WellsMonitoring, ProductionMonitoring
from schemas.monitoring import WellsMonitoringScheme, ProductionMonitoringScheme, WellsMonitoringSchemeGet, ProductionMonitoringSchemeGet
from interfaces.repository import SQLAlchemyRepository


class WellsMonitoringRepository(SQLAlchemyRepository):
    model = WellsMonitoring
    scheme = WellsMonitoringScheme
    scheme_get = WellsMonitoringSchemeGet


class ProductionMonitoringRepository(SQLAlchemyRepository):
    model = ProductionMonitoring
    scheme = ProductionMonitoringScheme
    scheme_get = ProductionMonitoringSchemeGet
from datetime import date
from typing import Optional, Dict

from pydantic import BaseModel

class StatisticsScheme(BaseModel):
    well: str
    rateDebitOilFallForYear: float = 0
    rateDebitOilFallForMonth: float = 0
    numMonthsWithoutWork: float = 0

    debitOilMedian: float = 0
    debitLiqMedian: float = 0
    watercutMedian: float = 0
    timeWorkProdMedian: float = 0
    solidPressMedian: float = 0
    downholePressMedian: float = 0
    dynLevelMedian: float = 0

class StatisticsSchemeGet(BaseModel):
    id: int
    well: str
    rateDebitOilFallForYear: float
    rateDebitOilFallForMonth: float
    numMonthsWithoutWork: float

    debitOilMedian: float
    debitLiqMedian: float
    watercutMedian: float
    timeWorkProdMedian: float
    solidPressMedian: float
    downholePressMedian: float
    dynLevelMedian: float

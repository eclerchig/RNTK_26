from pydantic import BaseModel, validator

from logic.dictionary_enums import SolidEnum


class SolidsScheme(BaseModel):
    class Config:
        use_enum_values = True
    name: SolidEnum
    oil_density: float
    condensate_density: float
    water_density: float
    oil_volume_coeff: float
    water_volume_coeff: float
    gas_volume_coeff: float
    gas_content: float  # газосодержание

    # TO DO: найти способ привести к DRY-принципу
    @validator("name", pre=True)
    def validate_null_name(cls, name: str, values: dict):
        if name is None:
            raise ValueError(f"Пропущенное значение в названии пласта")
        return name

    @validator("oil_density", pre=True)
    def validate_null_oil_density(cls, oil_density: float, values: dict):
        if oil_density is None:
            raise ValueError(f"Пропущенное значение в плотности нефти для пласта {values['name']}")
        return oil_density

    @validator("condensate_density", pre=True)
    def validate_null_condensate_density(cls, condensate_density: float, values: dict):
        if condensate_density is None:
            raise ValueError(f"Пропущенное значение в плотности конденсата для пласта {values['name']}")
        return condensate_density

    @validator("water_density", pre=True)
    def validate_null_water_density(cls, water_density: float, values: dict):
        if water_density is None:
            raise ValueError(f"Пропущенное значение в плотности воды для пласта {values['name']}")
        return water_density

    @validator("oil_volume_coeff", pre=True)
    def validate_null_oil_volume_coeff(cls, oil_volume_coeff: float, values: dict):
        if oil_volume_coeff is None:
            raise ValueError(f"Пропущенное значение в объемном коэффициенте нефти для пласта {values['name']}")
        return oil_volume_coeff

    @validator("water_volume_coeff", pre=True)
    def validate_null_water_volume_coeff(cls, water_volume_coeff: float, values: dict):
        if water_volume_coeff is None:
            raise ValueError(f"Пропущенное значение в объемном коэффициенте воды для пласта {values['name']}")
        return water_volume_coeff

    @validator("gas_volume_coeff", pre=True)
    def validate_null_gas_volume_coeff(cls, gas_volume_coeff: float, values: dict):
        if gas_volume_coeff is None:
            raise ValueError(f"Пропущенное значение в объемном коэффициенте газа для пласта {values['name']}")
        return gas_volume_coeff

    @validator("gas_content", pre=True)
    def validate_null_gas_content(cls, gas_content: float, values: dict):
        if gas_content is None:
            raise ValueError(f"Пропущенное значение в величине газосодержания для пласта {values['name']}")
        return gas_content


class SolidsSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    name: SolidEnum
    oil_density: float
    condensate_density: float
    water_density: float
    oil_volume_coeff: float
    water_volume_coeff: float
    gas_volume_coeff: float
    gas_content: float  # газосодержание

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'name': 'Пласт',
            'oil_density': 'Плотность нефти, т/м3',
            'condensate_density': 'Плотность конденсата, т/м3',
            'water_density': 'Плотность воды, т/м3',
            'oil_volume_coeff': 'Объёмный коэффициент нефти',
            'water_volume_coeff': 'Объёмный коэффициент воды',
            'gas_volume_coeff': 'Объёмный коэффициент газа',
            'gas_content': 'Газосодержание, м3/т',
        }
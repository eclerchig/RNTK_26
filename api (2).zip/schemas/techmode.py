import pdb

from pydantic import BaseModel, validator
from pydantic.schema import Optional
from datetime import date

import numpy as np

from logic.dictionary_enums import WellPurposeEnum, SolidEnum


class TechModeScheme(BaseModel):
    class Config:
        use_enum_values = True
    well_id: Optional[int]
    well_name: str
    pad_name: str
    date: date
    solid_id: int
    purpose: WellPurposeEnum
    q_injection: Optional[float]
    bottomhole_pressure: Optional[float]
    solid_pressure: Optional[float]
    bg_fact_pressure: Optional[float]
    wellhead_pressure: Optional[float]
    bg_forecast_pressure: Optional[float]

    # TO DO: найти способ привести к DRY-принципу
    @validator("well_name", pre=True)
    def validate_null_well_name(cls, well_name: str, values: dict):
        if well_name is None:
            raise ValueError(f"Пропущенное значение в названии скважины")
        return well_name

    @validator("pad_name", pre=True)
    def validate_null_pad_name(cls, pad_name: str, values: dict):
        if pad_name is None:
            raise ValueError(f"Пропущенное значение в названии куста для скважины {values['well_name']}")
        return pad_name

    @validator("date", pre=True)
    def validate_null_date(cls, dt: date, values: dict):
        if dt is None:
            raise ValueError(f"Пропущенное значение в дате тех. режима для скважины {values['well_name']}")
        return dt

    @validator("purpose", pre=True)
    def validate_null_purpose(cls, purpose: str, values: dict):
        if purpose is None:
            raise ValueError(f"Пропущенное значение в назначении скважины {values['well_name']} в тех.режиме")
        return purpose


class TechModeSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    well_id: Optional[int]
    well_name: str
    pad_name: str
    solid_id: int
    solid_name: SolidEnum
    date: date
    purpose: WellPurposeEnum
    q_injection: Optional[float]
    bottomhole_pressure: Optional[float]
    solid_pressure: Optional[float]
    bg_fact_pressure: Optional[float]
    wellhead_pressure: Optional[float]
    bg_forecast_pressure: Optional[float]

    @validator('*', pre=True)
    def convert_nan_to_zero(cls, v):
        if isinstance(v, float):
            if v is None or np.isnan(v):
                v = 0
        return v

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'well_id': 'ID скважины',
            'well_name': 'Скважина',
            'pad_name': 'Куст',
            'solid_id': 'ID пласта',
            'solid_name': 'Пласт',
            'date': 'Дата',
            'purpose': 'Назначение скважин',
            'q_injection': 'Qзак, м3/сут',
            'bottomhole_pressure': 'Рзаб, атм',
            'solid_pressure': 'Рпл, атм',
            'bg_fact_pressure': 'Рбг факт, атм',
            'wellhead_pressure': 'Рустье, атм',
            'bg_forecast_pressure': 'Рбг прогноз, атм'
        }

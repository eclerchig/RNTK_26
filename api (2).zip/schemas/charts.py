from typing import Optional

from pydantic import BaseModel, validator
from pydantic.types import Json
from datetime import datetime


class ChartsScheme(BaseModel):
    name: str
    data: Json
    user_id: int

    # TO DO: найти способ привести к DRY-принципу
    @validator("name", pre=True)
    def validate_null_name(cls, name: str, values: dict):
        if name is None:
            raise ValueError(f"Пропущенное значение в названии графика")
        return name

    @validator("data", pre=True)
    def validate_null_data(cls, data: Json, values: dict):
        if data is None:
            raise ValueError(f"Пропущены данные для графика")
        return data

    @validator("user_id", pre=True)
    def validate_null_user_id(cls, user_id: int, values: dict):
        if user_id is None:
            raise ValueError(f"Пропущенное значение в id пользователя")
        return user_id


class ChartsSchemeGet(BaseModel):
    id: int
    name: str
    datetime: datetime
    data: Json
    user_id: int

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'name': 'Название шаблона',
            'datetime': 'Дата и время создания',
            'data': 'Данные (json)',
            'user_id': 'ID пользователя',
        }


class AggrFuncScheme(BaseModel):
    name: str
    latin_name: str

    @validator("name", pre=True)
    def validate_null_name(cls, name: str):
        if name is None:
            raise ValueError(f"Пропущенное значение в названии агрегирующей функции")
        return name

    @validator("latin_name", pre=True)
    def validate_null_data(cls, data: str):
        if data is None:
            raise ValueError(f"Пропущены данные в латинском названии агрегирующей функции")
        return data


class AggrFuncSchemeGet(BaseModel):
    id: int
    name: str
    latin_name: str

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'name': 'Название функции',
            'latin_name': 'Латинское название функции',
        }



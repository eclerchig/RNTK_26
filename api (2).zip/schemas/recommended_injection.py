from pydantic import BaseModel, validator
from pydantic.schema import Optional
from datetime import date

from logic.dictionary_enums import SolidEnum


class RecommendedInjectionScheme(BaseModel):
    well_id: int
    solid_id: int
    cell_id: Optional[int]
    date: date
    record_target_injection_id: Optional[int]
    record_potential_injection_id: Optional[int]
    techmode_id: Optional[int]
    inj_agrp_recommended: float
    inj_infr_recommended: float
    from_cell: bool
    user_id: int

    @validator("well_id", pre=True)
    def validate_null_name(cls, well_id: str, values: dict):
        if well_id is None:
            raise ValueError(f"Пропущенное значение в id скважины")
        return well_id

    @validator("solid_id", pre=True)
    def validate_null_solid_id(cls, solid_id: int, values: dict):
        if solid_id is None:
            raise ValueError(f"Пропущенное значение в id пласта для скважины c id {values.get('well_id')}")
        return solid_id

    @validator("date", pre=True)
    def validate_null_date(cls, dt: date, values: dict):
        if dt is None:
            raise ValueError(f"Пропущенное значение в дате для скважины c id {values.get('well_id')}")
        return dt

    @validator("user_id", pre=True)
    def validate_null_user(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id пользователя")
        return id


class RecommendedInjectionSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    well_id: int
    well_name: str
    solid_id: int
    solid_name: SolidEnum
    cell_id: Optional[int]
    cell_name: Optional[str]
    date: date
    record_target_injection_id: Optional[int]
    record_potential_injection_id: Optional[int]
    techmode_id: Optional[int]
    inj_agrp_recommended: float
    inj_infr_recommended: float
    from_cell: bool

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'well_id': 'ID скважины',
            'well_name': 'Скважина',
            'solid_id': 'ID пласта',
            'solid_name': 'Пласт',
            'cell_id': 'ID ячейки',
            'cell_name': 'Ячейка',
            'date': 'Дата',
            'record_target_injection_id': 'ID строки целевой закачки',
            'record_potential_injection_id': 'ID строки потенциальной закачки',
            'techmode_id': 'ID строки тех. режима',
            'inj_agrp_recommended': 'Qзак АГРП рекомендуемая, м3/сут',
            'inj_infr_recommended': 'Qзак ИНФР рекомендуемая, м3/сут',
            'from_cell': 'Расчет по ячейкам',
        }
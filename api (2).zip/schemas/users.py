from pydantic import BaseModel, validator


class UserRegisterScheme(BaseModel):
    login: str
    password: str

    # TO DO: найти способ привести к DRY-принципу
    @validator("login", pre=True)
    def validate_login(cls, login: str):
        if login is None:
            raise ValueError("Пропущен логин пользователя")
        return login

    @validator("password", pre=True)
    def validate_password(cls, password: str):
        if password is None:
            raise ValueError("Пропущен логин пользователя")
        return password


class UserAuthScheme(BaseModel):
    login: str
    password: str

    # TO DO: найти способ привести к DRY-принципу
    @validator("login", pre=True)
    def validate_login(cls, login: str):
        if login is None:
            raise ValueError("Пропущен логин пользователя")
        return login

    @validator("password", pre=True)
    def validate_password(cls, password: str):
        if password is None:
            raise ValueError("Пропущен пароль пользователя")
        return password


class UsersScheme(BaseModel):
    login: str
    password: str
    is_user: bool
    is_admin: bool

    # TO DO: найти способ привести к DRY-принципу
    @validator("login", pre=True)
    def validate_login(cls, login: str):
        if login is None:
            raise ValueError("Пропущен логин пользователя")
        return login

    @validator("password", pre=True)
    def validate_password(cls, password: str):
        if password is None:
            raise ValueError("Пропущен пароль пользователя")
        return password


class UsersSchemeGet(BaseModel):
    id: int
    login: str
    password: str
    is_user: bool
    is_admin: bool

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'login': 'Логин',
            'password': 'Пароль',
            'is_user': 'Статус пользователя',
            'is_admin': 'Статус администратора',
        }

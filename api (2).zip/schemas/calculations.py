from datetime import date, datetime

from typing import Optional, Dict, Any

from pydantic import BaseModel

class CalculationsScheme(BaseModel):
    name: Optional[str]
    createAt: datetime = datetime.now(),
    predictDate: date
    gtm: Optional[Dict[str, Any]]

class CalculationsSchemeGet(BaseModel):
    id: int
    name: Optional[str]
    createAt: datetime
    predictDate: date
    gtm: Optional[Dict[str, Any]]
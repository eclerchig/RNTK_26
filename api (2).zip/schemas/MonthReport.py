from datetime import date
from typing import Dict, Optional

from pydantic import BaseModel

class MonthReportScheme(BaseModel):
    well: str
    wellMain: str
    date: date
    debitOil: float = 0
    debitLiq: float = 0
    watercut: float = 0
    cumOil: float = 0
    cumLiq: float = 0
    timeWorkProd: int = 0
    solidPress: float = 0
    wellheadPress: float = 0
    debitOilFirst: float = 0
    debitLiqFirst: float = 0
    dynLevel: float = 0
    pushTR: float = 0

    is_calculated: bool = False

    statistics_id: int
    geology_id: int
    calc_id: int

class MonthReportSchemeGet(BaseModel):
    id: int
    well: str
    wellMain: str
    date: date
    debitOil: float
    debitLiq: float
    watercut: float
    cumOil: float
    cumLiq: float
    timeWorkProd: int
    solidPress: float
    wellheadPress: float
    debitOilFirst: float
    debitLiqFirst: float
    dynLevel: float
    pushTR: float

    is_calculated: bool

    statistics: Dict
    geology: Dict
    calculation: Dict

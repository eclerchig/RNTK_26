from datetime import date
from typing import Optional, Dict, Any

from pydantic import BaseModel

class MLModelsScheme(BaseModel):
    name: str
    version: str
    type: str
    date: date
    quality: float = 0
    userGrade: float = 0
    dataVolume: int = 0
    gtm: Dict[str, Any]
    confisionMatrix: Dict[str, Any]
    roc: Dict[str, Any]

class MLModelsSchemeGet(BaseModel):
    id: int
    name: str
    version: str
    type: str
    date: date
    quality: float
    user_grade: float
    dataVolume: int
    gtm: Dict[str, Any]
    confisionMatrix: Dict[str, Any]
    roc: Dict[str, Any]
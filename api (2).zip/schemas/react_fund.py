from pydantic import BaseModel, validator

from logic.dictionary_enums import SolidEnum, WellPurposeEnum


class ReactFundScheme(BaseModel):
    class Config:
        use_enum_values = True
    center_well_id: int
    around_well_id: int
    solid_id: int
    center_well_purpose: WellPurposeEnum
    user_id: int
    for_delete: bool = False

    # TO DO: найти способ привести к DRY-принципу
    @validator("center_well_id", pre=True)
    def validate_null_center_well_id(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id центральной скважины из мониторинга")
        return id

    @validator("around_well_id", pre=True)
    def validate_null_around_well_id(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id скважины, действующей на центральную, из мониторинга")
        return id

    @validator("solid_id", pre=True)
    def validate_null_solid_id(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id пласта")
        return id

    @validator("center_well_purpose", pre=True)
    def validate_center_well_purpose(cls, purpose: str, values: dict):
        valid_names = {'Добывающая', 'Нагнетательная'}
        if purpose is None:
            raise ValueError(f"Пропущенное значение в назначении центровой скважины")
        if purpose not in valid_names:
            raise ValueError(f"Отсутствует название назначения скважины в списке {valid_names}")
        return purpose

    @validator("user_id", pre=True)
    def validate_null_user(cls, id: int, values: dict):
        if id is None:
            raise ValueError(f"Пропущенное значение в id пользователя")
        return id


class ReactFundSchemeGet(BaseModel):
    class Config:
        use_enum_values = True
    id: int
    center_well_id: int
    center_well: str
    around_well_id: int
    around_well: str
    solid_id: int
    solid_name: SolidEnum
    center_well_purpose: WellPurposeEnum
    for_delete: bool = False

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'center_well_id': 'ID центральной скважины',
            'center_well': 'Центральная скважина',
            'around_well_id': 'ID влияющей скважины',
            'around_well': 'Влияющая скважина',
            'solid_id': 'ID пласта',
            'solid_name': 'Пласт',
            'center_well_purpose': 'Назначение центральной скважины',
            'for_delete': 'Для удаления',
        }
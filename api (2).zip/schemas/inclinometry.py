import pdb

from pydantic import BaseModel, validator
from pydantic.schema import Optional


class InclinometriesScheme(BaseModel):
    well_id: Optional[int]
    x: float
    y: float
    z: float
    md: float
    well_name: str

    # TO DO: найти способ привести к DRY-принципу
    @validator("x", pre=True)
    def validate_null_name(cls, x: float, values: dict):
        if x is None:
            raise ValueError(f"Пропущенное значение в координате X для скважины {values.get('well_name')}")
        return x

    @validator("y", pre=True)
    def validate_null_solid(cls, y: float, values: dict):
        if y is None:
            raise ValueError(f"Пропущенное значение в координате Y для скважины {values.get('well_name')}")
        return y

    @validator("z", pre=True)
    def validate_null_char_work(cls, z: float, values: dict):
        if z is None:
            raise ValueError(f"Пропущенное значение в координате Z для скважины {values.get('well_name')}")
        return z

    @validator("md", pre=True)
    def validate_null_date_drilled(cls, md: float, values: dict):
        if md is None:
            raise ValueError(f"Пропущенное значение в координате MD для скважины {values.get('well_name')}")
        return md

    @validator("well_name", pre=True)
    def validate_null_main_trunk(cls, name: str, values: dict):
        if name is None:
            raise ValueError("Пропущенное значение в имени скважины")
        return name


class InclinometriesSchemeGet(BaseModel):
    id: int
    well_id: Optional[int]
    well_name: str
    x: float
    y: float
    md: float
    z: float

    @staticmethod
    def get_readable_columns():
        return {
            'id': 'ID',
            'well_id': 'ID скважины',
            'well_name': 'Скважина',
            'x': 'X, м',
            'y': 'Y, м',
            'z': 'Z, м',
            'md': 'MD',
        }

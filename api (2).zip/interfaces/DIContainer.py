import pdb

from interfaces.exception import APIException


class InvalidNameService(APIException):
    def __init__(self, name):
        super().__init__(f"Неверное название сервиса для вызова: {name}",
                         data={
                             'name': name,
                         })


class DIContainer:
    def __init__(self):
        self._singletons = {}
        self._factories = {}

    def register_singleton(self, name, instance):
        self._singletons[name] = instance

    def register_factory(self, name, factory_func):
        self._factories[name] = factory_func

    def __getitem__(self, name):
        if name in self._singletons:
            return self._singletons[name]
        if name in self._factories:
            return self._factories[name]()
        raise InvalidNameService(name)


service_container = DIContainer()

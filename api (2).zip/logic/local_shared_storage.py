import hashlib
import os
import pdb
import uuid
from datetime import datetime
from os.path import dirname, abspath, join
from typing import Union

import aiofiles
from fastapi import UploadFile
from pathlib import Path

from settings import settings

ROOT_DIR = dirname(dirname(abspath(__file__)))

class LocalFileStorage:
    """
    Локальное хранилище данных для передачи между процессами
    """
    def __init__(self):
        self.folder = settings.TEMPDIR
        self._chunk_size = 128 * 1024  # 128 КБ

    async def save_upload_file(
        self,
        upload_file: UploadFile,
        mode: Union[str, None] = None
    ):
        """
        Сохраняет загруженные файл от клиента в локальную папку self.folder
        mode = 'cells' - сохраняет имя ячейки для дальнейшего чтения из temp
        """
        temp_filename = self._generate_filename(upload_file.filename, mode)
        file_save_path = join(ROOT_DIR, self.folder, temp_filename)
        await self._save_file(upload_file, file_save_path)
        file_hash = await self.calc_hash(file_save_path)
        return file_save_path, file_hash

    def _generate_filename(self, original_filename: str, mode: str) -> str:
        """Генерирует уникальное имя для файла"""
        file_ext = Path(original_filename).suffix.lower()
        unique_id = uuid.uuid4().hex
        timestamp = datetime.now().strftime("%d_%m_%Y")
        if mode == 'cells':
            cell = '.'.join(original_filename.split('.')[:-1])
            filename = f"{cell}_{timestamp}_{unique_id}{file_ext}"
        else:
            filename = f"{timestamp}_{unique_id}{file_ext}"
        return filename

    async def _save_file(self, upload_file: UploadFile, path: Path):
        async with aiofiles.open(path, 'wb') as buffer:
            while content := await upload_file.read(self._chunk_size):
                await buffer.write(content)
        await upload_file.seek(0)

    async def calc_hash(self, path: Path):
        sha256_hash = hashlib.sha256()

        async with aiofiles.open(path, 'rb') as f:
            while chunk := await f.read(self._chunk_size):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()
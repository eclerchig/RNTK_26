import pdb
from os.path import dirname, abspath
import re

from logic.utilities import remove_spaces, is_date_between
from dateutil.relativedelta import relativedelta


class WellRenamer():

    POSTFIX_NUMBER_TRUNK = {
        'основной': 0,
        'первый': 1,
        'второй': 2,
        'третий': 3,
        'четвертый': 4,
        'пятый': 5,
        'шестой': 6,
        'седьмой': 7,
        'восьмой': 8,
        'девятый': 9,
        'десятый': 10,
    }

    ROOT_DIR = dirname(dirname(dirname(abspath(__file__))))

    class UndefinedWellName(Exception):
        def __init__(self, well):
            self.well = well
            super().__init__(
                f"Не найдена скважина {well} в таблице скважин Wells.xlsx"
            )

    class CantFoundOutTrunkInDatabaseException(Exception):
        def __init__(self, trunk_number, main_trunk):
            self.trunk_number = trunk_number
            self.main_trunk = main_trunk
            super().__init__(
                f"Не найден ствол с порядком {trunk_number} на основном стволе {main_trunk} "
                f"в таблице БД WellsDictionary"
            )

    class IncorrectPerforationException(Exception):
        def __init__(self, trunk_name, date_drilling, date_perforation):
            self.trunk_name = trunk_name
            self.date_perforation = date_perforation
            self.date_drilling = date_drilling
            super().__init__(
                f"Дата проведения перфорации '{date_perforation}' раньше, чем дата бурения {date_drilling} ствола {trunk_name}"
            )

    LATIN_DIGIT_REMOVER = {
        'bis': 'БИС',
        'GN': 'ГН',
        'CB': 'СВ',
        'N': 'Н',
        'P': 'Р',
        'B': 'В',
        'G': 'Г',
        'B3': 'ВЗ',
    }
    GAS_WELLS = ['126', '327', '341', '342', '357', '358']

    def __init__(self, df_wells, df_exceptions):
        self.df_wells = df_wells
        self.df_exceptions = df_exceptions

    def rename_well(self, source_name, actual_date):
        source_name = remove_spaces(source_name)
        exception = self._define_exception(source_name, actual_date)
        if exception is None:
            formatted_name = self._format_name(source_name)
            return self._define_main_trunk_name(formatted_name, actual_date)
        else:
            return exception

    def rename_well_for_perforations(self, source_name, number_trunk, date):
        row = self.df_wells[(self.df_wells['main_trunk'] == source_name) & \
                            (self.df_wells['number_trunk'] == number_trunk)]
        if row.empty:
            raise self.CantFoundOutTrunkInDatabaseException(number_trunk, source_name)
        trunk = row['name'].values[0]
        if row['date_drilled'].values[0] > date:
            raise self.IncorrectPerforationException(trunk, row['date_drilled'].values[0], date)
        parent_trunk = self._define_parent_trunk_name(trunk, row['main_trunk'], date)
        return trunk, parent_trunk
        # if number_trunk == 'основной':
        #     return source_name, source_name
        # else:
        #     # получаем список стволов, которые пробурены вместе с основным стволом (включительно осн. ствол)
        #     df = self.df_wells
        #     match_rows = df[(~df['name'].str.contains(f"{main_trunk_name}", regex=True))]
        #     trunk = match_rows[match_rows['number_trunk'] == number_trunk]['name']
        #     main_trunk = match_rows[match_rows['number_trunk'] == number_trunk]['main_trunk']
        #     return trunk, main_trunk

    def _format_name(self, name):
        patterns = (letters for letters in self.LATIN_DIGIT_REMOVER.keys())
        total_pattern = '|'.join(patterns)
        match = re.search(total_pattern, str(name))
        while match is not None:
            name = name[:match.start()] + self.LATIN_DIGIT_REMOVER[match[0]] + name[match.end():]
            match = re.search(total_pattern, str(name))
        return name

    def _define_exception(self, name, actual_date):
        df = self.df_exceptions
        match_row = df.loc[(df['dev_name'] == name) &
                           (df['date_entry_encoding'] <= actual_date) &
                           (actual_date < df['date_end_encoding'])]
        if not match_row.empty:
            return match_row.loc["kin_name"]
        return None

    def _define_parent_trunk_name(self, well_name, main_trunk, date):
        exception = self._define_exception(main_trunk, date)
        if exception or not '-' in well_name:
            return well_name
        else:
            return well_name[:well_name.find('-')]

    def _define_parent_trunk_name2(self, source_name, actual_date, for_perfs=False, is_closed=False):

        source_name = remove_spaces(source_name)
        exception = self._define_exception(source_name, actual_date)

        if exception is None:
            formatted_name = self._format_name(source_name)
        else:
            return exception

        exclude_symbols = '-|_'
        df = self.df_wells
        try:
            match_rows = df[(df['main_trunk'] == str(formatted_name)) &
                            (~df['name'].str.contains(exclude_symbols, regex=True)) &
                            (~df['drilling_status'])]
            match_rows.sort_values(by="date_drilled", inplace=False)
            if is_closed:
                # если закрытая перфорация - убираем скважины, которые в ближайшее время были забурены (+/- 1 месяц)
                match_rows = match_rows[~(is_date_between(match_rows['date_drilled'] + relativedelta(months=1),
                                                          match_rows['date_drilled'] - relativedelta(months=1),
                                                          match_rows['date_drilled']))]

            return match_rows.iloc[-1]['name']

        except IndexError:
            print(f"Не найдена скважина {source_name} в таблице скважин Wells.xlsx на дату {actual_date}")
            return None

    def _define_main_trunk_name(self, name, actual_date):
        df = self.df_wells
        exclude_symbols = '-|_'
        try:
            match_rows = df[(df['main_trunk'] == str(name)) &
                            (df['date_drilled'] <= actual_date) &
                            (~df['name'].str.contains(exclude_symbols, regex=True)) &
                            (~df['drilling_status'])]
            return match_rows.sort_values(by="date_drilled", inplace=False).iloc[-1]['name']
        except IndexError:
            print(f"Не найдена скважина {name} в таблице скважин Wells.xlsx на дату {actual_date}")
            return None

    # def _set_priority_for_trunc_by_name(self, well_name, main_trunks):
    #     matcher = re.compile("\d+$")
    #     is_matched = matcher.search(well_name)
    #     if is_matched:
    #         return is_matched
    #     else:
    #         return 0
import pandas as pd


class FileCollector():
    def __init__(self):
        self.pathes_to_file = dict()
        self.dfs = dict()
        self.dfs_processed = dict()
        self.exclude_load_files = ['Мониторинг', 'Перфорации', 'Инклинометрия']

    def update_paths_to_file(self, key, new_path):
        self.pathes_to_file[key] = new_path

    def update_dataframes(self):
        for key in self.pathes_to_file:
            if key not in self.exclude_load_files:
                self.dfs[key] = pd.read_excel(self.pathes_to_file[key])
                print(f"{key} was load")
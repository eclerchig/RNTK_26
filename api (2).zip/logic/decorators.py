import contextvars
import functools
import time
from typing import Callable, Any
import pandas as pd

from interfaces.exception import APIException
from interfaces.DIContainer import service_container as services


def async_timed():
    def wrapper(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapped(*args, **kwargs) -> Any:
            print(f'Выполняется {func} с аргументами {args} {kwargs}')
            start = time.time()
            try:
                return await func(*args, **kwargs)
            finally:
                end = time.time()
                total = end - start
                print(f'{func} завершилась за {total:.4f} с')
        return wrapped
    return wrapper


def timed():
    def wrapper(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapped(*args, **kwargs) -> Any:
            print(f'Выполняется {func} с аргументами {args} {kwargs}')
            start = time.time()
            try:
                return func(*args, **kwargs)
            finally:
                end = time.time()
                total = end - start
                print(f'{func} завершилась за {total:.4f} с')
        return wrapped
    return wrapper


# Обработчик ошибок APIException для каждой функции класса Service (async)
def async_service_error_handler(func: Callable, service: str) -> Callable:
    @functools.wraps(func)
    async def wrapped(*args, **kwargs) -> Any:
        try:
            return await func(*args, **kwargs)
        except APIException as e:
            e.set_service(service)
            raise e
        except Exception as e:
            raise e
    return wrapped


# Обработчик ошибок APIException для каждой функции класса Service
def service_error_handler(func: Callable, service: str) -> Callable:
    @functools.wraps(func)
    def wrapped(*args, **kwargs) -> Any:
        try:
            return func(*args, **kwargs)
        except APIException as e:
            e.set_service(service)
            raise e
        except Exception as e:
            raise e
    return wrapped


# Обработчик ошибок APIException для каждой функции класса AbstractRepository (async)
def async_repository_error_handler(func: Callable) -> Callable:
    @functools.wraps(func)
    async def wrapped(*args, **kwargs) -> Any:
        try:
            return await func(*args, **kwargs)
        except APIException as e:
            e.set_source('Репозиторий')
            raise e
        except Exception as e:
            raise e
    return wrapped


# Обработчик ошибок APIException для каждой функции класса AbstractRepository
def repository_error_handler(func: Callable) -> Callable:
    @functools.wraps(func)
    def wrapped(*args, **kwargs) -> Any:
        try:
            return func(*args, **kwargs)
        except APIException as e:
            e.set_source('Репозиторий')
            raise e
        except Exception as e:
            raise e
    return wrapped


def append_cells_coeffs_to_dataframe(func: Callable) -> Callable:
    """
        Декоратор, который добавляет к датафрейму, полученному из func, строку с КУ (по ячейкам)
    согласно фильтрам filters:
    если в filters указан cell_id, то КУ добавляются, иначе dataframe не преобразовывается.
    """
    @functools.wraps(func)
    async def wrapped(self, uow,  *args, cell_id=None, **kwargs) -> Any:
        if cell_id:
            coeff_service = services['participation_coefficient']
            df = await func(self, uow, *args, **kwargs)
            df_coeffs = await coeff_service.get_data(uow,
                                                     result_type='dataframe',
                                                     cell_id=cell_id,
                                                     solid_id=kwargs.get('solid_id'),
                                                     from_cell=True)
            df = df.merge(
                df_coeffs[['center_well_id', 'solid_id', 'date', 'distance_coefficient']],
                left_on=['well_id', 'solid_id', 'date'], right_on=['center_well_id', 'solid_id', 'date'],
                how='left'
            )
            return df[~pd.isnull(df['center_well_id'])]
        else:
            return await func(self, uow, *args, **kwargs)
    return wrapped


def keep_context_in_loop(func: Callable) -> Callable:
    """
        Декоратор для сохранения контекста в синхронных функциях при использовании loop
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        all_vars = {var: var.get() for var in contextvars.copy_context()}

        def sync_wrapper():
            for var, value in all_vars.items():
                var.set(value)
            return func(*args, **kwargs)

        return sync_wrapper
    return wrapper


def api_exception_handler_for_tasks(func: Callable):
    """
        Декоратор для перехватывания APIException и др. exceptions
        для сохранения ошибки в метаданных задачи
    """
    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            self.update_state(
                state=states.FAILURE,
                meta={
                    "user_friendly": isinstance(e, APIException),
                    "message": str(e),
                }
            )
    return wrapper
import pdb

import pandas as pd
import datetime

from logic.file_upload_processors.FileUploadProcessor import FileUploadProcessor
from logic.utilities import convert_multi_index_to_single_index, lead_date_to_one_date_format, rename_solid


class TechmodeFileUploadProcessor(FileUploadProcessor):

    COLUMNS_PROD = {
        'Общие Скв №': 'well_name',
        'Общие Куст': 'pad_name',
        'Пласт Пласт': 'solid_name',
        'Общие Дата': 'date',
        'Режим Qзак': 'q_injection',
        'Режим Рзаб': 'bottomhole_pressure',
        'Режим Pпл': 'solid_pressure',
    }

    COLUMNS_INJ = {
        'Общие Скв №': 'well_name',
        'Общие Куст': 'pad_name',
        'Пласт Пласт': 'solid_name',
        'Общие Дата': 'date',
        'Режим Qзак': 'q_injection',
        'Режим Рзаб': 'bottomhole_pressure',
        'Режим Pпл': 'solid_pressure',
        'Давление Pбг': 'bg_fact_pressure',
        'Давление P устья': 'wellhead_pressure'
    }

    REQUIRED_NOT_ZERO_COLUMNS_INJ = ['q_injection', 'bottomhole_pressure', 'solid_pressure', 'wellhead_pressure', 'bg_fact_pressure']
    REQUIRED_NOT_ZERO_COLUMNS_PROD = ['q_injection', 'bottomhole_pressure', 'solid_pressure', 'wellhead_pressure']

    COLUMNS_TYPES = {
        'well_name': str,
        'pad_name': str,
        'solid_name': str,
        'date': datetime.date,
        'purpose': str,
        'q_injection': float,
        'bottomhole_pressure': float,
        'solid_pressure': float,
        'bg_fact_pressure': float,
        'wellhead_pressure': float,
    }

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df, purpose_techmode='Добывающая', **kwargs):
        df = convert_multi_index_to_single_index(df)

        check_columns = self.COLUMNS_PROD if purpose_techmode == 'Добывающая' else self.COLUMNS_INJ
        df = self.check_missing_columns(check_columns, df)

        if purpose_techmode == 'Добывающая':
            df[['bg_fact_pressure', 'wellhead_pressure']] = 0
        df['purpose'] = purpose_techmode

        return df

    def remove_na(self, df):
        df['q_injection'].fillna(0, inplace=True)
        df['bottomhole_pressure'].fillna(0, inplace=True)
        df['solid_pressure'].fillna(0, inplace=True)
        df['bg_fact_pressure'].fillna(0, inplace=True)
        df['wellhead_pressure'].fillna(0, inplace=True)
        df = df.where(pd.notnull(df), None)
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            else:
                df[col] = df[col].astype(type_)
        return df

    def additional_processing(self, df, purpose_techmode=None, **kwargs):
        # Написать проверку на отсутствие необходимых показателей
        # check_not_null_columns = ['q_injection', 'bottomhole_pressure', 'solid_pressure', 'wellhead_pressure'] if purpose_techmode == 'Добывающая' else \
        #     self.COLUMNS_INJ

        df['solid_name'] = df['solid_name'].apply(lambda x: rename_solid(x))
        return df


import pdb
from abc import ABC

import pandas as pd
import datetime

from interfaces.exception import APIException
from logic.file_upload_processors.FileUploadProcessor import FileUploadProcessor
from logic.utilities import remove_spaces, lead_date_to_one_date_format


class MissingWellsInMonitoringException(APIException, ABC):
    def __init__(self, missing_prod_wells: list = None, missing_inj_wells: list = None):
        super().__init__(
            f"Не найдены скважины в мониторинге:{f' {missing_prod_wells} (доб)' if len(missing_prod_wells) > 0 else ''}"
            f"{'и' if not (len(missing_prod_wells) == 0 or len(missing_inj_wells) == 0) else ''}"
            f"{ f' {missing_inj_wells} (наг)' if len(missing_inj_wells) > 0 else ''}",
            source="Обработчик реаг. фонда",
            data={
                'missing_prod_wells': missing_prod_wells,
                'missing_inj_wells': missing_inj_wells,
            }
        )


class ReactFundFileUploadProcessor(FileUploadProcessor):

    COLUMNS = {
        'Добывающая скважина': 'prod_well',
        'Нагнетательные скважины в окружении': 'inj_wells',
    }

    COLUMNS_TYPES = {
        'prod_well': str,
        'inj_wells': str,
    }

    def __init__(self, file_converter=None):
        super().__init__(file_converter)

    def select_columns(self, df, **kwargs):
        missing_columns = [col for col in self.COLUMNS.keys() if col not in df.columns]
        if missing_columns:
            raise KeyError("Отсутствуют необходимые колонки", missing_columns, list(self.COLUMNS.keys()))
        else:
            df = df[self.COLUMNS.keys()]
            df = df.rename(columns=self.COLUMNS)
            return df

    def remove_na(self, df):
        df = df[df["prod_well"].notna()]
        df = df[df["inj_wells"].notna()]
        return df

    def convert_data_types(self, df):
        for col, type_ in self.COLUMNS_TYPES.items():
            if type_ == datetime.date:
                df[col] = df[col].apply(lambda x: lead_date_to_one_date_format(x))
            else:
                df[col] = df[col].astype(type_)
        return df

    def additional_processing(self, df, user_id=None, wells_monitoring_df=None, **kwargs):
        combinations_center_prod = []
        combinations_center_inj = []

        for row in df.itertuples(name=None, index=False):
            row = (tuple(remove_spaces(x) for x in row))
            df_piece = pd.DataFrame([row], columns=df.columns)
            df_piece = df_piece.reset_index(drop=True)

            prod_well = df_piece.at[0, 'prod_well']
            inj_wells = df_piece.at[0, 'inj_wells']

            [combinations_center_prod.append((prod_well, inj_well)) for inj_well in inj_wells.replace(" ", "").split(",")]
            [combinations_center_inj.append((inj_well, prod_well)) for inj_well in inj_wells.replace(" ", "").split(",")]

        df_center_prod = pd.DataFrame(combinations_center_prod, columns=['center_well', 'around_well']).astype(str)
        df_center_prod['center_well_purpose'] = 'Добывающая'
        df_center_prod = df_center_prod.merge(
            wells_monitoring_df[
                wells_monitoring_df['purpose'].isin(['Добывающая', 'Нагнетательная с отработкой'])]
            [['id', 'well_name', 'solid_id']],
            left_on=['center_well'],
            right_on=['well_name'],
            how='left')

        df_center_inj = pd.DataFrame(combinations_center_inj, columns=['center_well', 'around_well']).astype(str)
        df_center_inj['center_well_purpose'] = 'Нагнетательная'
        df_center_inj = df_center_inj.merge(
            wells_monitoring_df[
                wells_monitoring_df['purpose'].isin(['Нагнетательная', 'Нагнетательная с отработкой'])]
            [['id', 'well_name', 'solid_id']],
            left_on=['center_well'],
            right_on=['well_name'],
            how='left')

        missing_prod_wells = df_center_prod[df_center_prod['id'].isnull()]['center_well'].unique()
        missing_inj_wells = df_center_inj[df_center_inj['id'].isnull()]['center_well'].unique()

        if len(missing_prod_wells) > 0 or len(missing_inj_wells):
            raise MissingWellsInMonitoringException(missing_prod_wells, missing_inj_wells)
        df = pd.concat([df_center_prod, df_center_inj], ignore_index=True)
        df = df.drop(['well_name'], axis=1)
        df = df.rename(columns={'id': 'center_well_id'})

        df = df.merge(wells_monitoring_df[['id', 'well_name']],
                      left_on=['around_well'],
                      right_on=['well_name'],
                      how='left')
        df = df.drop(['center_well', 'around_well', 'well_name'], axis=1)
        df = df.rename(columns={'id': 'around_well_id'})
        df['user_id'] = user_id
        return df


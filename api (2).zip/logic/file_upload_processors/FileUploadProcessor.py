import pdb
from pathlib import Path

from typing import List, Union
from abc import ABC, abstractmethod
from io import BytesIO

import celery
import pandas as pd
from anyio import current_effective_deadline
from celery import current_task
from celery.contrib import rdb

from schemas.celery import UpdateProgressMeta
from tasks.progress_tracker import task_progress_tracker

from interfaces.exception import APIException


class NotValidColumnsNamesException(APIException):
    def __init__(self, missing_columns: List, valid_columns: List):
        super().__init__(
            description=f"Пропущены колонки в исходном файле: {', '.join(missing_columns)}; \n "
                        f"Полный список колонок: {', '.join(valid_columns)}",
            data={
                'missing_columns': missing_columns,
                'valid_columns': valid_columns,
            })

    def __str__(self):
        return super().__str__()


class ErrorInTimeConvertTypesException(APIException):
    def __init__(self, error_msg: str):
        super().__init__(
            description=f"Ошибка во время приведения типов данных: {error_msg}",
            data={
                'error_msg': error_msg,
            })

    def __str__(self):
        return super().__str__()


class NotExistSheetInExcelFileException(APIException):
    def __init__(self, sheet_name: str):
        super().__init__(
            description=f"Отсутствует лист в файле с названием '{sheet_name}'",
            data={
                'sheet_name': sheet_name,
            })
        self.sheet_name = sheet_name

    def __str__(self):
        return super().__str__()


class FileConverterToDataFrame(ABC):
    @abstractmethod
    def convert(self, file_content: bytes):
        pass


class ExcelConverter(FileConverterToDataFrame):
    def __init__(self, header=0, skiprows=0, sheet_name: Union[int, str]=0):
        self.header = header
        self.skiprows = skiprows
        self.sheet_name = sheet_name

    def convert(self, file_path: Path):
        try:
            return pd.read_excel(
                file_path,
                header=self.header,
                skiprows=self.skiprows,
                sheet_name=self.sheet_name
            )
        except ValueError:
            raise NotExistSheetInExcelFileException(str(self.sheet_name))


class FileUploadProcessor(ABC):
    def __init__(self, file_converter=None):
        self.converter = file_converter

    def process(self, file_path, *args, task_id:str=None, **kwargs):
        '''
            Позволяет создать датафрейм из файла
            :param task_id:
            :param file:
            :param kwargs: побочные данные, которые могут быть необходимы при обработке
            :return: pd.DataFrame
        '''
        # Загрузка данных в датафрейм (если не назначен конвертер, исх. данные - датафрейм)
        if task_id:
            task_progress_tracker.update_meta(
                task_id=task_id,
                data=UpdateProgressMeta(
                    alert_msg="Чтение файла",
                    current=0,
                    total=100,
                )
            )

        if self.converter:
            df = self.converter.convert(file_path)
        else:
            df = file_path

        if task_id:
            task_progress_tracker.update_meta(
                task_id=task_id,
                data=UpdateProgressMeta(
                    alert_msg="Выбор колонок",
                    current=15,
                    total=100,
                )
            )

        try:
            df = self.select_columns(df, **kwargs)
        except KeyError as e:
            _, missing_columns, valid_columns = e.args
            raise NotValidColumnsNamesException(missing_columns, valid_columns)

        if task_id:
            task_progress_tracker.update_meta(
                task_id=task_id,
                data=UpdateProgressMeta(
                    alert_msg="Удаление пустых строк",
                    current=30,
                    total=100,
                )
            )

        df = self.remove_na(df)

        if task_id:
            task_progress_tracker.update_meta(
                task_id=task_id,
                data=UpdateProgressMeta(
                    alert_msg="Приведение типов данных",
                    current=45,
                    total=100,
                )
            )

        try:
            df = self.convert_data_types(df)
        except Exception as e:
            raise ErrorInTimeConvertTypesException(e.__str__())

        if task_id:
            task_progress_tracker.update_meta(
                task_id=task_id,
                data=UpdateProgressMeta(
                    alert_msg="Валидация данных",
                    current=60,
                    total=100,
                )
            )

        df = self.additional_processing(df, task_id=task_id, **kwargs)
        df = self.validate(df)
        return df

    @abstractmethod
    def select_columns(self, df, *args, **kwargs):
        pass

    @abstractmethod
    def remove_na(self, df):
        pass

    @abstractmethod
    def convert_data_types(self, df):
        pass

    @abstractmethod
    def additional_processing(self, df, *args, **kwargs):
        pass

    def validate(self, df):
        # Нужно придумать валидацию общую для всех таблиц
        return df

    def check_missing_columns(self, columns, df):
        missing_columns = [col for col in columns.keys() if col not in df.columns]
        if missing_columns:
            raise KeyError("Отсутствуют необходимые колонки", missing_columns, list(columns.keys()))
        df = df[columns.keys()]
        df = df.rename(columns=columns)
        return df

from interfaces.exception import APIException


class ValidationDataException(APIException):
    def __init__(self, data, model, loc, msg):
        super().__init__(f"Ошибка при валидации строки в pydentic: {model}, {loc}: {msg}",
                         data={
                             'row': data,
                             'model': model,
                             'loc': loc,
                             'msg': msg,
                         })

    def __str__(self):
        return super().__str__()


class DublicateRowException(APIException):
    def __init__(self, data: dict = None):
        super().__init__("Обнаружен дубликат строки в БД", data=data)

    def __str__(self):
        return super().__str__()
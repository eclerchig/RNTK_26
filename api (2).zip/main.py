import datetime
import os
import pdb

from fastapi import FastAPI, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi import UploadFile
from starlette.responses import JSONResponse

from database.session import init_models, async_engine
from services.DataProcessService import DataProcessService
from interfaces.unit_of_work import IUnitOfWork
from routes.dependencies import UOWDep


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Response-For-User"]
)

@app.on_event("startup")
async def on_startup():
    await init_models()

@app.on_event("shutdown")
async def shutdown():
    await async_engine.dispose()


@app.get("/test")
async def test():
    return {"status": "Working"}


@app.get("/routes")
async def get_routes():
    routes = {}
    for route in app.routes:
        routes[route.path] = {
            'methods': getattr(route, 'methods', 'N/A'),
            'name': getattr(route, 'name', 'N/A'),
            'endpoint': getattr(route, 'endpoint', 'N/A'),
        }
    return routes


@app.post("/files")
async def upload_data(
    predict_date: datetime.date = Form(...),
    file_mer: UploadFile = File(...),
    file_geology: UploadFile = File(...),
    uow: IUnitOfWork = UOWDep,
):
    pdb.set_trace()
    await DataProcessService().process_file(uow, predict_date, file_mer, file_geology)
    df = await DataProcessService().get_data(uow, result_type='json', is_calculated=False)
    return JSONResponse(status_code=200, content=df.to_json(orient='records'))

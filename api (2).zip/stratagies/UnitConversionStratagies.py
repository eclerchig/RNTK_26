class UnitConversionStrategy:
    def convert(self, *kwargs):
        raise NotImplementedError


class ThousandTonsToCubicMetersPerDayStrategy(UnitConversionStrategy):
    def __init__(self, density):
        self.density = density

    def convert(self, value, days, **kwargs):
        return value * 1000 / self.density / days


class ThousandTonsToThousandCubicMetersStrategy(UnitConversionStrategy):
    def __init__(self, density):
        self.density = density

    def convert(self, value, **kwargs):
        return value / self.density


class ThousandCubicMetersToCubicMetersPerDayStrategy(UnitConversionStrategy):
    def __init__(self):
        pass

    def convert(self, value, days, **kwargs):
        return value * 1000 / days


class MillionCubicMetersToThousandCubicMetersStrategy(UnitConversionStrategy):
    def __init__(self):
        pass

    def convert(self, value, days, **kwargs):
        return value / 1000


class MillionCubicMetersToThousandToCubicMetersPerDayStrategy(UnitConversionStrategy):
    def __init__(self):
        pass

    def convert(self, value, days, **kwargs):
        return value / 1000 / days



import contextvars
import logging
import os
import pdb
import asyncio
import itertools
import functools
import math
from typing import List
import threading

import pandas as pd
import numpy as np
from celery.contrib import rdb
from dateutil.relativedelta import relativedelta
from scipy.spatial import distance
from scipy.stats import pearsonr
import concurrent.futures
import traceback
import warnings

import matplotlib.pyplot as plt

from shapely.geometry import Point, Polygon


from exceptions.business import NotExistCoordinatesForPerforationError, \
    ErrorInTimeParallelCalculationTargetInjException, ErrorInTimeParallelCalculationCoeffsException, \
    NotExistCoordinatesForCenterPerforationError
from interfaces.exception import APIException
from interfaces.logging_ import calc_logger, general_logger, user_id_ctx, create_logger_for_parallel_calc
from logic.decorators import async_timed
from logic.utilities import preserve_context

lock = threading.Lock()

column_value_by_purpose = {
    'Добывающая': 'oil_production',
    'Нагнетательная': 'water_injection'
}

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)


def log_message_with_lock(logger: logging.Logger, msg, *args, level=logging.INFO):
    with lock:
        logger.log(level, msg, *args)


def collapse_table_with_wells_monitoring_table_by_well_name(df, wells_monitoring_df, first_key_column,
                                                            second_key_column):
    wells_monitoring_df["id"] = wells_monitoring_df["id"].replace(np.nan, None)

    df = df.merge(wells_monitoring_df[['id', 'well_name']],
                  left_on=first_key_column,
                  right_on=second_key_column,
                  how='left')
    df = df.drop(['well_id'], axis=1)
    df = df.rename(columns={'id_y': 'well_id', 'id_x': 'id'})
    return df


def add_coords_to_perforation_table(perf_df, incl_df):
    # Перебираем уникальные названия скважин
    for well in perf_df['well_name'].unique():
        well_perf = perf_df[perf_df['well_name'] == well]
        well_incl = incl_df[incl_df['well_name'] == well]
        add_coords_to_perf(well_perf.index, perf_df, well_incl)
    return perf_df


def add_coords_to_perf(idxs_row_upd, perf_df, incl_df):
    accuracy = 1
    for idx in idxs_row_upd:
        df_piece = perf_df.iloc[idx]
        try:
            near_coord_roof = incl_df[(incl_df['md'] >= int(df_piece['top_interval_depth']) - accuracy)].iloc[0]
            near_coord_bottom = incl_df[(incl_df['md'] >= int(df_piece['bottom_interval_depth']) - accuracy)].iloc[0]
            if near_coord_roof.empty:
                near_coord_roof = incl_df[(incl_df['md'] >= int(df_piece['top_interval_depth']) - accuracy) &
                                          (incl_df['md'] <= int(df_piece['top_interval_depth']) + accuracy)].iloc[0]
            if near_coord_bottom.empty:
                near_coord_bottom = incl_df[(incl_df['md'] >= int(df_piece['bottom_interval_depth']) - accuracy) &
                                            (incl_df['md'] <= int(df_piece['bottom_interval_depth']) + accuracy)].iloc[
                    0]

            perf_df.loc[idx, 'x1'] = near_coord_roof['x']
            perf_df.loc[idx, 'y1'] = near_coord_roof['y']
            perf_df.loc[idx, 'z1'] = near_coord_roof['z']
            perf_df.loc[idx, 'md1'] = near_coord_roof['md']
            perf_df.loc[idx, 'x2'] = near_coord_bottom['x']
            perf_df.loc[idx, 'y2'] = near_coord_bottom['y']
            perf_df.loc[idx, 'z2'] = near_coord_bottom['z']
            perf_df.loc[idx, 'md2'] = near_coord_bottom['md']

        except IndexError:
            raise NotExistCoordinatesForPerforationError(well=df_piece['well_name'],
                                                         top_md=df_piece['top_interval_depth'],
                                                         bottom_md=df_piece['bottom_interval_depth'],
                                                         source='func add_coords_to_perf')


# def process_perforation_row(df_total, df_row, end_date_border):
#     closed_perf_kinds = ['отсеч.пакером', 'отсеч.мостом', 'отсеч.стаканом']
#     if df_row['well_name'] is None or df_row['perforation_kind'] is None or df_row['date'] is None:
#         df_row['for_delete'] = True
#         return df_row
#     if df_row['date'] > end_date_border:
#         df_row['for_delete'] = True
#         return df_row
#
#     df_matches = df_total[
#         (df_total['well_name'] == df_row['well_name']) &
#         (df_total['date'] == df_row['date']) &
#         (df_total['top_interval_depth'] == df_row['top_interval_depth']) &
#         (df_total['number_holes'] == df_row['number_holes'])]
#     idx_matches = df_matches.index
#     if not df_matches.empty and len(idx_matches) > 1:
#         if df_row['perforation_kind'] != 'первич. перф.':
#             df_row['for_delete'] = True
#
#     if df_row['perforation_kind'] in closed_perf_kinds: df_row['for_delete'] = True
#
#     return df_row


# TRUNK_ORDER_TRUNK = ['основной', 'первый', 'второй', 'третий', 'четвертый',
#                      'пятый', 'шестой', 'седьмой', 'восьмой', 'девятый', 'десятый',
#                      'одиннадцатый', 'двенадцатый', 'тринадцатый',
#                      ]
#
#
# class CantFindPreviousTrunkInWellsDataframeException(Exception):
#     def __init__(self, previous_trunk, trunk):
#         self.previous_trunk = previous_trunk
#         self.trunk = trunk
#
#     def __str__(self):
#         return f"Can't find out previous trunk {self.previous_trunk} for {self.trunk} in Wells table"
#
#
# def update_number_trunk(wells_df, well_name_excps_df):
#     wells_df = wells_df.sort_values(by=['name'])
#     wells_without_number_df = wells_df[wells_df['number_trunk'].isnull()]
#
#     for idx, _ in wells_without_number_df.iterrows():
#
#         trunk = wells_without_number_df.loc[idx, :]['name']
#         main_trunk = wells_without_number_df.loc[idx, :]['main_trunk']
#
#         # if trunk == '11А':
#         #     pdb.set_trace()
#
#         # Нет ствола в исключениях
#         if not well_name_excps_df[well_name_excps_df['dev_name'] == main_trunk].empty or '_' in trunk:
#             pass
#             # Реализовать логирование, уведомляющее о необходиомости ручного описания стволов
#         else:
#             by_main_trunk_df = wells_df[(wells_df['main_trunk'] == main_trunk) & ~(wells_df['number_trunk'].isnull())]
#             parent_trunk = trunk[:trunk.find('-')] if trunk.find('-') != -1 else trunk
#             wells_df.loc[idx, 'number_trunk'] = define_number_trunk(trunk, parent_trunk, main_trunk, by_main_trunk_df)
#     return wells_df
#
#
# def define_number_trunk(trunk, parent_trunk, main_trunk, wells_df):
#     # Это не МЗС
#     if parent_trunk == trunk:
#         # Это основной ствол
#         if trunk == main_trunk or main_trunk + 'Н' == trunk or main_trunk + 'ГН' == trunk:
#             return 'основной'
#         else:
#             # Это первый ЗБС
#             if trunk[-1] == 'А':
#                 prev_zbs = main_trunk
#             # Это другой ЗБС
#             else:
#                 prev_zbs = trunk[:trunk.find('А') + 1] + str(int(trunk[trunk.find('А') + 1:]) - 1) \
#                     if int(trunk[trunk.find('А') + 1:]) != 2 else trunk[:trunk.find('А') + 1]
#             trunks_mzs = wells_df[(wells_df['name'].str.contains(prev_zbs)) & (wells_df['name'].str.contains('-'))]
#             if trunks_mzs.empty:
#                 prev_trunk = prev_zbs
#             else:
#                 last_trunk_order = max([TRUNK_ORDER_TRUNK.index(order) for order in trunks_mzs['number_trunk'].values])
#                 prev_trunk = \
#                 trunks_mzs[(trunks_mzs['number_trunk'] == TRUNK_ORDER_TRUNK[last_trunk_order])]['name'].values[0]
#             try:
#                 return return_next_number_trunk_name(
#                     wells_df[wells_df['name'] == prev_trunk]['number_trunk'].values[0])
#             except Exception:
#                 raise CantFindPreviousTrunkInWellsDataframeException(prev_trunk, trunk)
#     # Это МЗС
#     else:
#         # Это первый МЗС
#         if trunk[-2:] == '-2':
#             try:
#                 return return_next_number_trunk_name(
#                     wells_df[wells_df['name'] == parent_trunk]['number_trunk'].values[0])
#             except Exception:
#                 raise CantFindPreviousTrunkInWellsDataframeException(parent_trunk, trunk)
#         # Это другой МЗС
#         else:
#             prev_trunk = trunk[:trunk.find('-') + 1] + str(int(trunk[trunk.find('-') + 1:]) - 1)
#             try:
#                 return return_next_number_trunk_name(
#                     wells_df[wells_df['name'] == prev_trunk]['number_trunk'].values[0])
#             except Exception:
#                 raise CantFindPreviousTrunkInWellsDataframeException(parent_trunk, trunk)
#
#
# def return_next_number_trunk_name(name):
#     return TRUNK_ORDER_TRUNK[TRUNK_ORDER_TRUNK.index(name) + 1]


def rename_well_and_define_main_trunk(df_row, well_renamer):
    trunk, main_trunk = well_renamer.rename_well_for_perforations(df_row["Скважина"],
                                                                  df_row["Номер ствола"],
                                                                  df_row["Дата проведения перфорации"])
    df_row["Главный ствол"] = main_trunk
    df_row["Скважина"] = trunk


def calc_reservoir_sampling(oil, liq, gas, days, oil_density, oil_vol_coeff,
                            water_density, water_vol_coeff, gas_vol_coeff):
    q_oil = oil / days
    q_liq = liq / days
    q_gas = gas / days

    return ((q_oil / oil_density) * oil_vol_coeff +
            ((q_liq - q_oil) / water_density) * water_vol_coeff +
            q_gas * 1000 * gas_vol_coeff) * 1000


@async_timed()
async def create_coeffs_df(perf_df, incl_df, wells_monitoring, monitoring_by_date,
                           begin_date, end_date, react_radius, last_fact,
                           delete_zero_coeff=False, calc_by_cells=False, react_fund_df=None,
                           cells_df=None, polygons_df=None):
    logger = calc_logger if user_id_ctx.get() else general_logger

    tasks = []
    loop = asyncio.get_running_loop()

    results = []

    with concurrent.futures.ProcessPoolExecutor() as pool:
        if calc_by_cells:
            prod_wells = list(wells_monitoring[wells_monitoring['purpose'] == 'Добывающая']['well_name'].unique())
            inj_wells = list(wells_monitoring[wells_monitoring['purpose'].isin(["Нагнетательная"])]['well_name'].unique())

            logger.info(
                "Начало расчета коэффицентов по ячейкам на объекте %s на период прогноза с %s по %s.",
                wells_monitoring['solid_name'].values[0],
                begin_date,
                end_date,
            )

            for chunk_wells_list in partition_list(prod_wells, len(prod_wells) // 4):
                partial_func = functools.partial(map_create_coeffs_df_by_cells, chunk_wells_list,
                                                 "Добывающая", perf_df, incl_df,
                                                 monitoring_by_date, begin_date,
                                                 end_date, react_radius, cells_df, polygons_df,
                                                 delete_zero_coeff)
                tasks.append(loop.run_in_executor(pool, preserve_context(partial_func)))
            for chunk_wells_list in partition_list(inj_wells, len(inj_wells) // 4):
                partial_func = functools.partial(map_create_coeffs_df_by_cells, chunk_wells_list,
                                                 "Нагнетательная", perf_df, incl_df,
                                                 monitoring_by_date, begin_date,
                                                 end_date, react_radius, cells_df, polygons_df,
                                                 delete_zero_coeff)
                tasks.append(loop.run_in_executor(pool, preserve_context(partial_func)))
        else:
            react_fund_df = filter_fund_by_available_in_monitoring(react_fund_df, monitoring_by_date)
            purpose_center = react_fund_df['center_well_purpose'].values[0]
            logger.info(
                "Начало расчета коэффицентов на объекте %s на период прогноза с %s по %s. "
                "Назначение центральных скважин: %s",
                react_fund_df['solid_name'].values[0],
                begin_date,
                end_date,
                purpose_center,
            )
            for chunk_df in partition_df(react_fund_df, react_fund_df.shape[0] // 4):
                partial_func = functools.partial(map_create_coeffs_df,
                                                 chunk_df,
                                                 perf_df, incl_df, monitoring_by_date,
                                                 begin_date, end_date, last_fact,
                                                 delete_zero_coeff, react_radius)
                tasks.append(loop.run_in_executor(pool, preserve_context(partial_func)))

        done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)

        for task in done:
            exc = task.exception()
            if exc:
                for pending_task in pending:
                    pending_task.cancel()
                logger.warning("Было прервано вычисление коэффициентов с ошибкой")
                if isinstance(exc, APIException):
                    raise ErrorInTimeParallelCalculationCoeffsException(parent_exc=task.exception())
                else:
                    logger.exception(exc)
                    raise exc
            else:
                results.append(task.result())

        total_coeffs_df = functools.reduce(merge_dataframes, [coeffs for coeffs, _ in results])
        total_removes_fund_df = functools.reduce(merge_dataframes, [removes_fund for _, removes_fund in results])

    if delete_zero_coeff:
        total_coeffs_df.drop(total_coeffs_df[total_coeffs_df['distance_coefficient'] == 0].index, inplace=True)

    # prod_wells = list(wells_monitoring[wells_monitoring['purpose'] == 'Добывающая']['well_name'].unique())
    # inj_wells = list(wells_monitoring[wells_monitoring['purpose'].isin(["Нагнетательная"])]['well_name'].unique())
    #
    # total_coeffs_df_center, total_removes_fund_df = map_create_coeffs_df_by_cells(prod_wells,
    #                                                                               "Добывающая", perf_df, incl_df,
    #                                                                               monitoring_by_date, begin_date,
    #                                                                               end_date, react_radius, cells_df,
    #                                                                               polygons_df, delete_zero_coeff)
    # total_coeffs_df_around, total_removes_fund_df = map_create_coeffs_df_by_cells(inj_wells,
    #                                                                               "Нагнетательная", perf_df, incl_df,
    #                                                                               monitoring_by_date, begin_date,
    #                                                                               end_date, react_radius, cells_df,
    #                                                                               polygons_df, delete_zero_coeff)
    #
    # total_coeffs_df = pd.concat([total_coeffs_df_center, total_coeffs_df_around], ignore_index=True)
    # total_coeffs_df, total_removes_fund_df = map_create_coeffs_df(react_fund_df, perf_df, incl_df,
    #                                                                   monitoring_by_date,
    #                                                                   begin_date, end_date, last_fact,
    #                                                                   delete_zero_coeff, react_radius)

    logger.info("Вычисление коэффициентов завершено")
    return total_coeffs_df, total_removes_fund_df


def get_actual_perfs(perfs, well_name, purpose="Добывающая"):
    if purpose == "Добывающая":
        return perfs[(perfs['well_name'] == well_name) & ~(perfs['date_open'] is None)].reset_index(drop=True)
    else:
        return perfs[perfs['main_trunk_name'] == well_name].reset_index(drop=True)


def map_create_coeffs_df(react_fund_df: pd.DataFrame,
                         perf_df: pd.DataFrame,
                         incl_df: pd.DataFrame,
                         monitoring_by_date: pd.DataFrame,
                         begin_date, end_date, last_fact,
                         delete_zero_coeff, react_radius):
    logger = create_logger_for_parallel_calc(f"calc_logger_{os.getpid()}")
    purpose_center = react_fund_df['center_well_purpose'].values[0]
    purpose_around = list({'Добывающая', 'Нагнетательная'} - {purpose_center})[0]
    coeffs_df = pd.DataFrame(columns=['center_well', 'around_well',
                                      'date', 'distance', 'distance_coefficient',
                                      'correlation_coefficient'])
    coeffs_by_well = pd.DataFrame(columns=coeffs_df.columns)
    remove_fund_df = pd.DataFrame(columns=['center_well', 'around_well', 'center_well_purpose'])
    perf_df.drop(perf_df[np.isnan(perf_df['md1'])].index, inplace=True)

    begin_date = begin_date if begin_date > min(monitoring_by_date['date']) else min(monitoring_by_date['date'])
    end_date = end_date if end_date < max(monitoring_by_date['date']) else max(monitoring_by_date['date'])

    center_wells = react_fund_df['center_well'].unique()

    # Перестановка всех скважин
    for c_well in center_wells:
        start = begin_date
        end = end_date
        current = start

        center_perf = get_actual_perfs(perf_df, c_well, purpose_center)

        if not center_perf.empty:

            while current <= end:

                center_open_perfs = center_perf[(center_perf['date_open'] <= current) &
                                                ((current <= center_perf['date_close']) |
                                                 ~(center_perf['date_close'] is None))]
                if not center_open_perfs.empty:
                    around_wells = react_fund_df[react_fund_df['center_well'] == c_well]['around_well'].values

                    for a_well in around_wells:
                        around_perf = get_actual_perfs(perf_df, a_well, purpose_around)
                        around_open_perfs = around_perf[(around_perf['date_open'] <= current) &
                                                        ((current <= around_perf['date_close']) |
                                                         (center_perf['date_close'].isin([None])))]

                        if not around_open_perfs.empty:
                            coeffs = build_coeffs_df_by_date(c_well, a_well,
                                                             center_open_perfs, around_open_perfs,
                                                             incl_df, current,
                                                             react_radius, purpose_center, delete_zero_coeff)

                            # записываем скважины, которые можно удалить из фонда
                            if coeffs.empty or coeffs['distance'].values[0] > react_radius:
                                remove_fund_df = pd.concat([remove_fund_df,
                                                            pd.DataFrame({"center_well": [c_well],
                                                                          "around_well": [a_well],
                                                                          "center_well_purpose": [purpose_center]})],
                                                           ignore_index=True)

                            coeffs_by_well = pd.concat([coeffs_by_well, coeffs], ignore_index=True)

                            center_well_work = check_value_available_in_monitoring(monitoring_by_date, c_well, current,
                                                                                   purpose_center)
                            around_well_work = check_value_available_in_monitoring(monitoring_by_date, a_well, current,
                                                                                   purpose_around)

                            # Если коэффициенты посчитались, но одна из скважин не работает
                            if not (center_well_work and around_well_work) and not coeffs.empty:
                                if delete_zero_coeff:
                                    coeffs_by_well.drop(coeffs_by_well.index[-1], inplace=True)
                                    log_message_with_lock(logger,
                                                          'Для %s и %s на дату %s удален КУ, т.к. одна из скважин '
                                                          'не работает по мониторингу',
                                                          c_well, a_well,
                                                          current.strftime("%d.%m.%Y"),
                                                          level=logging.INFO,
                                                          )
                                else:
                                    coeffs_by_well.loc[coeffs_by_well.index[-1], 'distance_coefficient'] = 0.0
                                    log_message_with_lock(logger,
                                                          'Для %s и %s на дату %s КУ исправлен на 0, '
                                                          'т.к. одна из скважин не работает по мониторингу',
                                                          c_well, a_well,
                                                          current.strftime("%d.%m.%Y"),
                                                          level=logging.INFO,
                                                          )

                    if not coeffs_by_well.empty:
                        total_coeff = sum(coeffs_by_well['distance_coefficient'])
                        coeffs_by_well['distance_coefficient'] = coeffs_by_well.apply(
                            lambda row: row['distance_coefficient'] / total_coeff if total_coeff != 0 else row[
                                'distance_coefficient'],
                            axis=1)
                        coeffs_df = pd.concat([coeffs_df, coeffs_by_well], ignore_index=True)
                else:
                    log_message_with_lock(logger,
                                          'Нет открытых перфораций на скважине %s на дату %s',
                                          c_well,
                                          current.strftime("%d.%m.%Y"),
                                          level=logging.INFO,
                                          )

                coeffs_by_well = pd.DataFrame(columns=coeffs_df.columns)
                current += relativedelta(months=1)
        else:
            log_message_with_lock(logger,
                                  'Нет открытых перфораций %s',
                                  c_well,
                                  level=logging.INFO,
                                  )
            logger.info('Нет открытых перфораций %s', c_well)

    if not coeffs_df.empty:
        coeffs_df["correlation_coefficient"] = coeffs_df.apply(lambda row:
                                                                   define_correlation_coeff(
                                                                       row['center_well'],
                                                                       row['around_well'],
                                                                       monitoring_by_date,
                                                                       last_fact,
                                                                       purpose_center,
                                                                       purpose_around,
                                                                   )[0], axis=1)

    coeffs_df = coeffs_df.merge(react_fund_df[['id', 'center_well', 'around_well',
                                               'center_well_id', 'around_well_id',
                                               'center_well_purpose']],
                                on=['center_well', 'around_well'],
                                how='left')
    coeffs_df = coeffs_df.rename(columns={'id': 'react_fund_id'})
    coeffs_df = coeffs_df.drop(['center_well', 'around_well'], axis=1)
    coeffs_df['cell_id'] = None

    return coeffs_df, remove_fund_df


def map_create_coeffs_df_by_cells(wells: List[str],
                                  purpose: str,
                                  perf_df: pd.DataFrame,
                                  incl_df: pd.DataFrame,
                                  monitoring_by_date: pd.DataFrame,
                                  begin_date, end_date, react_radius,
                                  cells_df: pd.DataFrame,
                                  polygons_df: pd.DataFrame,
                                  delete_zero_coeff: bool):
    logger = create_logger_for_parallel_calc(f"calc_logger_{os.getpid()}")
    cells_df['polygon'] = cells_df.apply(lambda row: Polygon(
        [(x, y) for x, y in polygons_df[polygons_df['cell_id'] == row['id']][['x', 'y']].values.tolist()]), axis=1)
    coeffs_df = pd.DataFrame(
        columns=['center_well', 'date', 'distance_coefficient', 'cell_name', 'center_well_purpose'])
    perf_df.drop(perf_df[np.isnan(perf_df['md1'])].index, inplace=True)

    begin_date = begin_date if begin_date > min(monitoring_by_date['date']) else min(monitoring_by_date['date'])
    end_date = end_date if end_date < max(monitoring_by_date['date']) else max(monitoring_by_date['date'])

    for well in wells:
        start = begin_date
        end = end_date
        current = start

        center_perf = perf_df[(perf_df['well_name'] == well) & ~(perf_df['date_open'] is None)].reset_index(drop=True)

        if not center_perf.empty:
            while current <= end:
                center_open_perfs = center_perf[(center_perf['date_open'] <= current) &
                                                ((current <= center_perf['date_close']) |
                                                 (center_perf['date_close'].isin([None])))]

                if not center_open_perfs.empty:  # and check_value_available_in_monitoring(monitoring_by_date, well, current, purpose):
                    coeffs = build_coeffs_df_by_ellipse(well, purpose,
                                                        center_open_perfs, incl_df[incl_df['well_name'] == well],
                                                        current, react_radius, cells_df, delete_zero_coeff)

                    coeffs_df = pd.concat([coeffs_df, coeffs], ignore_index=True)
                else:
                    log_message_with_lock(
                        logger, 'Нет открытых перфораций на скважине %s на дату %s',
                        well, current.strftime("%d.%m.%Y"),
                        level=logging.INFO,
                    )
                current += relativedelta(months=1)
        else:
            log_message_with_lock(
                logger, 'Нет открытых перфораций на скважине %s', well,
                level=logging.INFO,
            )
    return coeffs_df, pd.DataFrame()


def check_value_available_in_monitoring(monitoring_df, well_name, date, purpose):
    try:
        value = monitoring_df[(monitoring_df['well_name'] == well_name) & (monitoring_df['date'] == date)][
            column_value_by_purpose[purpose]].values[0]
        return value > 0
    except IndexError:
        return False


def create_react_fund_df_from_monitoring(wells_monitoring, solid_id):
    prod_monitoring_df = wells_monitoring[~(wells_monitoring['purpose'].isin(["Нагнетательная"]))]
    inj_monitoring_df = wells_monitoring[~(wells_monitoring['purpose'].isin(["Добывающая"]))]
    prod_wells_ids = prod_monitoring_df['id'].unique()
    inj_wells_ids = inj_monitoring_df['id'].unique()

    rf_prod_center_df = pd.DataFrame(list(itertools.product(prod_wells_ids, inj_wells_ids)),
                                     columns=['center_well_id', 'around_well_id'])
    rf_prod_center_df['center_well_purpose'] = 'Добывающая'
    rf_inj_center_df = pd.DataFrame(list(itertools.product(inj_wells_ids, prod_wells_ids)),
                                    columns=['center_well_id', 'around_well_id'])
    rf_inj_center_df['center_well_purpose'] = 'Нагнетательная'

    react_fund_df = pd.concat([rf_prod_center_df, rf_inj_center_df], ignore_index=True)
    react_fund_df['solid_id'] = solid_id

    return react_fund_df


def create_react_fund_df_from_cells(wells_monitoring, cells_df, purpose_center='Добывающая'):
    purpose_around = list(set(column_value_by_purpose.keys()) - {purpose_center})[0]

    cells = cells_df['cell_name'].unique()
    react_fund_df = pd.DataFrame(columns=['center_well_id', 'around_well_id', 'cell_name'])

    for cell in cells:
        wells_in_cell = cells_df[cells_df['cell_name'] == cell]['well_name'].unique()
        ids_center_wells = wells_monitoring[
            (wells_monitoring['purpose'].isin([purpose_center, "Нагнетательная с отработкой"]) &
             (wells_monitoring['well_name'].isin(wells_in_cell)))
        ]['id'].unique()
        ids_around_wells = wells_monitoring[
            (wells_monitoring['purpose'].isin([purpose_around, "Нагнетательная с отработкой"]) &
             (wells_monitoring['well_name'].isin(wells_in_cell)))
        ]['id'].unique()
        temp_df = pd.DataFrame(list(itertools.product(ids_center_wells, ids_around_wells)),
                               columns=['center_well_id', 'around_well_id'])
        temp_df['cell_name'] = cell
        react_fund_df = pd.concat([react_fund_df, temp_df], ignore_index=True)

    react_fund_df['solid_id'] = wells_monitoring['solid_id'].values[0]
    react_fund_df['center_well_purpose'] = purpose_center

    react_fund_df['from_cells'] = True
    return react_fund_df


def define_correlation_coeff(center_well, around_well, prod_monitoring, last_fact, purpose_center, purpose_around):
    first_fact = pd.to_datetime(last_fact - relativedelta(months=12))

    center_value = \
        prod_monitoring[(prod_monitoring['well_name'] == center_well) & (prod_monitoring['date'] >= first_fact) &
                        (prod_monitoring['date'] <= last_fact)][column_value_by_purpose[purpose_center]].tolist()

    around_value = \
        prod_monitoring[(prod_monitoring['well_name'] == around_well) & (prod_monitoring['date'] >= first_fact) &
                        (prod_monitoring['date'] <= last_fact)][column_value_by_purpose[purpose_around]].tolist()

    coeff, p_value = 0.0, 0.0
    if len(center_value) > 2 and len(around_value) > 2:
        try:
            coeff, p_value = pearsonr(center_value, around_value)
            if np.isnan(coeff):
                coeff, p_value = 0.0, 0.0
        except ValueError:
            if not "ValueError: x and y must have the same length" in traceback.format_exc():
                coeff, p_value = 0.0, 0.0
    return coeff, p_value


def filter_fund_by_available_in_monitoring(react_fund_df, prod_monitoring_df):
    CHUNK_NUM = 5
    for chunk_df in partition_df(react_fund_df, react_fund_df.shape[0] // CHUNK_NUM):

        merged_df_center = chunk_df.merge(prod_monitoring_df,
                                          left_on=['center_well_id', 'solid_id'],
                                          right_on=['well_id', 'solid_id'],
                                          how='left')
        merged_df_around = chunk_df.merge(prod_monitoring_df,
                                          left_on=['around_well_id', 'solid_id'],
                                          right_on=['well_id', 'solid_id'],
                                          how='left')

        for _, row in merged_df_center[merged_df_center['well_id'] == np.nan].iterrows():
            react_fund_df.drop(react_fund_df[react_fund_df['center_well_id'] == row['center_well_id']], inplace=True)

        for _, row in merged_df_around[merged_df_around['well_id'] == np.nan].iterrows():
            react_fund_df.drop(react_fund_df[react_fund_df['around_well_id'] == row['around_well_id']], inplace=True)

    return react_fund_df


def build_coeffs_df_by_ellipse(well, purpose, perfs, incl, date, inj_radius, cells_df, delete_zero_coeff):
    coeffs_df = pd.DataFrame(
        columns=['center_well', 'center_well_purpose', 'date', 'cell_name', 'points', 'distance_coefficient'])

    cells = cells_df['name'].unique()

    for idx_row, (_, row) in enumerate(perfs.iterrows()):
        try:
            near_coord_center = incl[incl['md'] >= (row['md1'] + row['md2']) / 2].iloc[0]
        except IndexError:
            raise NotExistCoordinatesForPerforationError(well=well, top_md=row['md1'], bottom_md=row['md2'])

        _b = inj_radius
        _c = distance.euclidean((near_coord_center['x'], near_coord_center['y']), (row['x1'], row['y1']))
        _a = math.sqrt(_b ** 2 + _c ** 2)
        steps_angle = [step * math.pi / 8 for step in range(16)]
        points = [Point(
            near_coord_center['x'] + _a * math.cos(angle), near_coord_center['y'] + _b * math.sin(angle)
        ) for angle in steps_angle]
        points.append(Point(near_coord_center['x'], near_coord_center['y']))
        # plt.plot([near_coord_center['x'] + _a * math.cos(angle) for angle in steps_angle],
        #          [near_coord_center['y'] + _b * math.sin(angle) for angle in steps_angle], color='black')

        for idx, cell in enumerate(cells):
            if idx_row == 0:
                coeffs_df.loc[len(coeffs_df)] = [well, purpose, date, cell, 0, 0]
            polygon = cells_df[cells_df['name'] == cell]['polygon'].values[0]
            points_in_polygon = sum([point.within(polygon) for point in points])
            coeffs_df.loc[coeffs_df['cell_name'] == cell, 'points'] = \
                coeffs_df.loc[coeffs_df['cell_name'] == cell, 'points'].values[0] + points_in_polygon
            if idx_row == 0:
                xx, yy = polygon.exterior.coords.xy
                plt.plot(xx.tolist(), yy.tolist())
    if purpose == 'Нагнетательная':
        coeffs_df.loc[coeffs_df['points'] == coeffs_df['points'].max(), 'distance_coefficient'] = 1.0
        coeffs_df.loc[coeffs_df['points'] != coeffs_df['points'].max(), 'distance_coefficient'] = 0.0
        coeffs_df['distance_coefficient'] = coeffs_df['distance_coefficient'].astype(float)
    else:
        coeffs_df['distance_coefficient'] = coeffs_df.apply(lambda row: row['points'] / (perfs.shape[0] * 17), axis=1)
    coeffs_df = coeffs_df.drop('points', axis=1)
    return coeffs_df


def build_coeffs_df_by_date(center_well, around_well, center_open_perfs, around_open_perfs, incl_df,
                            date, inj_radius, purpose_center, delete_zero_coeff):

    logger = calc_logger if user_id_ctx.get() else general_logger
    coeffs_df = pd.DataFrame(columns=['center_well', 'around_well', 'date', 'distance', 'distance_coefficient'])

    if purpose_center == 'Добывающая':
        incl_by_well = incl_df[(incl_df['well_name'] == center_well)].reset_index(drop=True)
        if incl_by_well.empty:
            log_message_with_lock(logger, 'Не загружена инклинометрия на скважине %s', center_well, level=logging.INFO)
            return coeffs_df
        else:
            coeff, distance = find_coeff_distance(center_open_perfs, incl_by_well, around_open_perfs, inj_radius)
    else:
        incl_by_well = incl_df[(incl_df['well_name'] == around_well)].reset_index(drop=True)
        if incl_by_well.empty:
            log_message_with_lock(logger, 'Не загружена инклинометрия на скважине %s', around_well, level=logging.INFO)
            return coeffs_df
        else:
            coeff, distance = find_coeff_distance(around_open_perfs, incl_by_well, center_open_perfs, inj_radius)

    log_message_with_lock(
        logger,
        'Для %s и %s на дату %s рассчитан КУ %s и дистанция %s',
        center_well, around_well, date.strftime("%d.%m.%Y"), coeff, distance,
        level=logging.INFO
    )
    if coeff != 0 or not delete_zero_coeff:
        coeffs_df = pd.concat([coeffs_df,
                               pd.DataFrame({
                                   'center_well': center_well,
                                   'around_well': around_well,
                                   'date': [date],
                                   'distance': [distance],
                                   'distance_coefficient': [coeff],
                               })],
                              ignore_index=True)
    else:
        log_message_with_lock(
            logger,
            'Для %s и %s на дату %s удален КУ, т.к. равен 0 и не включен режим записи нулевых КУ',
            center_well, around_well, date.strftime("%d.%m.%Y"),
            level=logging.INFO
        )
    return coeffs_df


# def find_open_perforation(df):
#     closed_perforations = df[df['Открытая перфорация'] == False]
#     if not closed_perforations.empty:
#         for idx, row in enumerate(closed_perforations.itertuples(name=None, index=False)):
#             row = (tuple(remove_spaces(x) for x in row))
#             df_piece = pd.DataFrame([row], columns=closed_perforations.columns)
#             df_piece.reset_index(drop=True)
#
#             idx_open_perf = df[(df['Дата проведения перфорации'] == df_piece.at[0, 'Дата проведения перфорации']) &
#                                 (df['Глубина кровли интервала, м.'] == df_piece.at[
#                                     0, 'Глубина кровли интервала, м.'])] \
#                 .index
#             df.drop(idx_open_perf[0], inplace=True)
#     return df


def find_coeff_distance(prod_well_perfs, prod_well_incl, inj_well_perfs, react_radius):
    min_distance = 100000

    center = define_center_perfs(prod_well_perfs, prod_well_incl)

    for idx, row in enumerate(inj_well_perfs.itertuples(name=None, index=False)):
        df_piece = pd.DataFrame([row], columns=inj_well_perfs.columns).reset_index(drop=True)

        if df_piece.at[0, 'well_name'].find('-') == -1:
            min_distance = min(min_distance,
                               distance.euclidean(center, (
                                   df_piece.at[0, 'x1'], df_piece.at[0, 'y1'], df_piece.at[0, 'z1'])),
                               distance.euclidean(center, (
                                   df_piece.at[0, 'x2'], df_piece.at[0, 'y2'], df_piece.at[0, 'z2']))
                               )
        else:
            min_distance = min(min_distance,
                               distance.euclidean(center, (
                                   df_piece.at[0, 'x2'], df_piece.at[0, 'y2'], df_piece.at[0, 'z2']))
                               )
    return round(1 - (min(min_distance, react_radius) / react_radius), 2), min_distance


def define_center_perfs(perfs, incl):
    first_perf = perfs.sort_values('top_interval_depth').iloc[0]
    last_perf = perfs.sort_values('top_interval_depth').iloc[-1]
    try:
        near_coord_center = incl[incl['md'] >= (first_perf['md1'] + last_perf['md2']) / 2].iloc[0]
    except IndexError:
        raise NotExistCoordinatesForCenterPerforationError(well=first_perf['well_name'],
                                                           center_md=(first_perf['md1'] + last_perf['md2']) / 2)
    return near_coord_center['x'], near_coord_center['y'], near_coord_center['z']


def stretch_techmodes_by_end_date(techmode_df, end_date):
    # Продление строк дат от последней даты ТР до определенной даты
    wells = techmode_df['well_name'].unique()
    for well in wells:
        techmode_df_by_well = techmode_df[techmode_df['well_name'] == well]

        dates = pd.date_range(
            start=techmode_df_by_well.sort_values('date').iloc[-1]['date'],
            end=end_date, freq='MS')
        if len(dates) > 0:
            dates = [dt.date() + relativedelta(days=20) for dt in dates]

            tail_df = pd.concat([techmode_df_by_well.sort_values('date').tail(1)] * len(dates))
            tail_df['date'] = dates
            techmode_df = pd.concat([techmode_df, tail_df], ignore_index=True)
    return techmode_df


def stretch_monitoring_by_end_date(monitoring_by_date, end_date):
    # Продление строк дат до определенной даты
    wells_ids = monitoring_by_date['well_id'].unique()
    for well_id in wells_ids:
        monitoring_df_by_well = monitoring_by_date[monitoring_by_date['well_id'] == well_id]

        dates = pd.date_range(
            start=monitoring_df_by_well.sort_values('date').iloc[-1]['date'] + relativedelta(months=1),
            end=end_date, freq='MS')
        if len(dates) > 0:
            dates = [dt.date() for dt in dates]
            tail_df = pd.concat([monitoring_df_by_well.sort_values('date').tail(1)] * len(dates))
            tail_df['date'] = dates
            monitoring_by_date = pd.concat([monitoring_by_date, tail_df], ignore_index=True)
    return monitoring_by_date


def process_cells_file(df_cells):
    df_cells.columns = ['well_name', 'cell_name']
    df_cells['well_name'] = df_cells['well_name'].astype(str)
    df_cells['cell_name'] = df_cells['cell_name'].astype(str)
    return df_cells


def fill_predict_pbg_column(techmode_df, pbg_df):
    techmode_df = pd.merge(techmode_df, pbg_df[['pad', 'date', 'pressure_bg']], how='left',
                           left_on=['pad_name', 'date'],
                           right_on=['pad', 'date'])
    techmode_df = techmode_df.drop(['pad'], axis=1)
    techmode_df["pressure_bg"] = techmode_df["pressure_bg"].replace(np.nan, None)
    techmode_df["well_id"] = techmode_df["well_id"].replace(np.nan, None)

    techmode_df['pressure_bg'] = techmode_df.apply(lambda row:
                                                   fill_empty_predict_pbg(row['date'],
                                                                          row['pad_name'],
                                                                          row['pressure_bg'],
                                                                          pbg_df), axis=1)

    techmode_df = techmode_df.rename(columns={'pressure_bg': 'bg_forecast_pressure'})
    return techmode_df


def fill_empty_predict_pbg(dt, pad, pbg_source, df_pbg):
    if pbg_source:
        return pbg_source

    first_pbg_date = df_pbg['date'].iloc[0]
    last_pbg_date = df_pbg['date'].iloc[-1]

    pbg = 0

    if df_pbg[df_pbg['pad'] == pad].empty or dt < first_pbg_date:
        return pbg_source
    if dt > last_pbg_date:
        pbg = df_pbg[(df_pbg['date'] == last_pbg_date) & (df_pbg['pad'] == pad)]['pressure_bg'].values[0]
    return pbg


def build_q_inj_potential(tech_mode_df, solid_name, begin_date, end_date):
    logger = calc_logger if user_id_ctx.get() else general_logger
    logger.info(
        "Начало расчета потенциальной закачки на объекте %s на период прогноза с %s по %s.",
        solid_name,
        begin_date.strftime("%d.%m.%Y"),
        end_date.strftime("%d.%m.%Y"),
    )
    # При отсутствии bg_forecast_pressure заменить его на bg_fact_pressure
    tech_mode_df['bg_forecast_pressure'] = tech_mode_df.apply(
        lambda row: row['bg_fact_pressure'] if row['bg_forecast_pressure'] is None or row['bg_forecast_pressure'] == 0
        else row['bg_forecast_pressure'],
        axis=1)
    # Кпр = Qзак/(Рзаб-Pпл)
    tech_mode_df['pickup_rate_coefficient'] = tech_mode_df.apply(
        lambda row: row['q_injection'] / (row['bottomhole_pressure'] - row['solid_pressure']), axis=1)
    # Р АГРП = calc_p_agrp(Pпл, Рзаб)
    tech_mode_df['agrp_pressure'] = tech_mode_df.apply(
        lambda row: calc_p_agrp(row['solid_pressure'], row['bottomhole_pressure']), axis=1)
    # Рз потенциал АГРП = max(Р АГРП, Рзаб)
    tech_mode_df['downhole_press_agrp'] = tech_mode_df.apply(
        lambda row: max(row['agrp_pressure'], row['bottomhole_pressure']), axis=1)
    # Qз потенциал АГРП = Кпр*(Рз потенциал АГРП-Pпл)
    tech_mode_df['inj_agrp_potential'] = tech_mode_df.apply(
        lambda row: row['pickup_rate_coefficient'] * (row['downhole_press_agrp'] - row['solid_pressure']), axis=1)
    # dРинфр = max(0, Pбг прогноз - P устья - 3)
    tech_mode_df['pressure_margin_infr'] = tech_mode_df.apply(
        lambda row: max(0, row['bg_forecast_pressure'] - row['wellhead_pressure'] - 3), axis=1)
    # Рз потенциал инф = Qзак + dРинфр
    tech_mode_df['downhole_press_infr_potential'] = tech_mode_df.apply(
        lambda row: row['q_injection'] + row['pressure_margin_infr'], axis=1)
    # Рз потенциал инф = min(Рз потенциал АГРП, Рз потенциал инф)
    tech_mode_df['downhole_press_infr_potential'] = tech_mode_df.apply(
        lambda row: min(row['downhole_press_agrp'], row['downhole_press_infr_potential']), axis=1)
    # Qз потенциал инф = Кпр * (Рз потенциал инф - Pпл)
    tech_mode_df['inj_infr_potential'] = tech_mode_df.apply(
        lambda row: row['pickup_rate_coefficient'] * (row['downhole_press_infr_potential'] - row['solid_pressure']),
        axis=1)
    # Qз потенциал инф = Qзак, если (Qз потенциал инф - Qзак) < 30, иначе Qз потенциал инф
    tech_mode_df['inj_infr_potential'] = tech_mode_df.apply(
        lambda row: row['q_injection'] if row['inj_infr_potential'] - row['q_injection'] < 30 else row[
            'inj_infr_potential'], axis=1)

    potential_injection_df = tech_mode_df.drop(
        ['pad_name', 'solid_name', 'purpose', 'q_injection', 'bottomhole_pressure',
         'solid_pressure', 'bg_fact_pressure', 'wellhead_pressure',
         'bg_forecast_pressure'], axis=1)
    potential_injection_df = potential_injection_df.rename(columns={'id': 'techmode_id'})
    potential_injection_df["well_id"] = potential_injection_df["well_id"].replace(np.nan, None)

    nan_inj_wells = potential_injection_df[
        (potential_injection_df['inj_infr_potential'] == 0) |
        (potential_injection_df['inj_agrp_potential'] == 0)]['well_name'].unique().tolist()
    if nan_inj_wells:
        logger.warning("Скважины с нулевой расчитанной потенциальной закачкой: %s", nan_inj_wells)
    logger.info("Вычисление потенциальной закачки завершено")
    return potential_injection_df


def calc_p_agrp(P_solid, P_zab):
    COEFF_POISSON = 0.254
    COEFF_ARE = 0.497
    ROCK_PRESSURE = 636.117
    COEFF_BIO = 1

    return (COEFF_POISSON / (1 - COEFF_POISSON)) * (ROCK_PRESSURE - COEFF_BIO * (P_solid + P_zab) / 2) + COEFF_BIO * (
            P_solid + P_zab) / 2


async def build_target_inj(monitoring_by_date, coeffs_dict_df, react_fund_df,
                           begin_date, end_date, cells_df=None):
    logger = calc_logger if user_id_ctx.get() else general_logger

    total_target_inj_df = pd.DataFrame()
    if not cells_df is None:
        logger.info(
            "Начало расчета целевой закачки по ячейкам на объекте %s на период прогноза с %s по %s.",
            monitoring_by_date['solid_name'].values[0],
            begin_date.strftime("%d.%m.%Y"),
            end_date.strftime("%d.%m.%Y"),
        )
        total_target_inj_df = build_target_inj_by_cell(monitoring_by_date, coeffs_dict_df,
                                                       begin_date, end_date, cells_df)

    else:
        logger.info(
            "Начало расчета целевой закачки на объекте %s на период прогноза с %s по %s.",
            monitoring_by_date['solid_name'].values[0],
            begin_date.strftime("%d.%m.%Y"),
            end_date.strftime("%d.%m.%Y"),
        )
        inj_wells_fund = react_fund_df.loc[
            react_fund_df['center_well_purpose'] == "Нагнетательная"]['center_well'].unique().tolist()

        tasks = []
        loop = asyncio.get_running_loop()
        results = []

        with concurrent.futures.ProcessPoolExecutor() as pool:
            for chunk_list in partition_list(inj_wells_fund, len(inj_wells_fund) // 4):
                partial_func = functools.partial(map_build_target_inj,
                                                 monitoring_by_date,
                                                 coeffs_dict_df, react_fund_df,
                                                 begin_date, end_date,
                                                 chunk_list)
                tasks.append(loop.run_in_executor(pool, preserve_context(partial_func)))

            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)

            for task in done:
                exc = task.exception()
                if exc:
                    for pending_task in pending:
                        pending_task.cancel()
                    logger.warning("Было прервано вычисление коэффициентов с ошибкой")
                    raise ErrorInTimeParallelCalculationTargetInjException(parent_exc=task.exception())
                else:
                    results.append(task.result())

            total_target_inj_df = functools.reduce(merge_dataframes, results)

        # total_target_inj_df = map_build_target_inj(monitoring_by_date, coeffs_dict_df,
        #                                            react_fund_df, begin_date, end_date,
        #                                            inj_wells_fund)

    nan_inj_wells = total_target_inj_df[(total_target_inj_df['target_inj'] == 0) |
                                        (total_target_inj_df['target_inj'] == 0)]['well_name'].unique().tolist()
    if nan_inj_wells:
        logger.warning("Скважины с нулевой расчитанной целевой закачкой: %s", nan_inj_wells)

    total_target_inj_df = total_target_inj_df[total_target_inj_df['target_inj'] != 0.0]
    logger.info("Вычисление целевой закачки завершено")
    return total_target_inj_df


def build_target_inj_by_cell(monitoring_by_date, coeffs_df,
                             begin_date, end_date, cells_df):
    monitoring_by_date = monitoring_by_date[(monitoring_by_date['date'] >= begin_date) &
                                            (monitoring_by_date['date'] <= end_date)]
    coeffs_df = coeffs_df[(coeffs_df['date'] >= begin_date) & (coeffs_df['date'] <= end_date) &
                          (coeffs_df['from_cell'])]
    df_target_inj = coeffs_df[['center_well', 'center_well_id', 'solid_id', 'date', 'center_well_purpose', 'cell_id',
                               'distance_coefficient']].merge(
        monitoring_by_date[['well_id', 'date', 'solid_id', 'water_injection', 'reservoir_sampling', 'days']],
        how='left', left_on=['center_well_id', 'solid_id', 'date'], right_on=['well_id', 'solid_id', 'date']
    )

    df_target_inj = df_target_inj.merge(cells_df.drop('name', axis=1), how='left',
                                        left_on=['solid_id', 'cell_id'],
                                        right_on=['solid_id', 'id'])

    df_target_inj['target_inj'] = df_target_inj.apply(lambda row:
                                                      row['reservoir_sampling'] * row['distance_coefficient'] * row[
                                                          'purpose_comp_coeff']
                                                      if row['center_well_purpose'] == 'Добывающая'
                                                      else row['water_injection'] * 1000 / row['days'] * row[
                                                          'distance_coefficient'] * row['purpose_comp_coeff'],
                                                      axis=1)

    df_target_inj = df_target_inj.rename(columns={'center_well': 'well_name', 'center_well_purpose': 'purpose'})
    df_target_inj.drop(['distance_coefficient',
                        'center_well_id',
                        'water_injection',
                        'reservoir_sampling',
                        'days',
                        'id',
                        'solid_name',
                        'purpose_comp_coeff'], axis=1, inplace=True)

    df_target_inj['from_cell'] = True

    return df_target_inj


def map_build_target_inj(monitoring_by_date, coeffs_dict_df, react_fund_with_purpose,
                         begin_date, end_date, inj_wells_fund):
    logger = create_logger_for_parallel_calc(f"calc_logger_{os.getpid()}")
    df_target_inj = pd.DataFrame(columns=['well_id', 'well_name', 'solid_id', 'date', 'target_inj'])
    coeffs_dict_df = coeffs_dict_df[~(coeffs_dict_df['from_cell'])]

    for idx, inj_well in enumerate(inj_wells_fund):

        react_fund_row = [tuple(row) for row in
                          react_fund_with_purpose.loc[react_fund_with_purpose['around_well'] == inj_well,
                                                      ['id', 'around_well', 'center_well', 'solid_id',
                                                       'around_well_id']]
                              .itertuples(name=None, index=False)]

        current = begin_date
        total_target_inj = 0

        while current <= end_date:

            for id, around_well, center_well, solid_id, around_well_id in react_fund_row:

                reservoir_sampling = monitoring_by_date[
                    (monitoring_by_date['well_name'] == center_well) &
                    (monitoring_by_date['solid_id'] == solid_id) &
                    (monitoring_by_date['date'] == current)]['reservoir_sampling'].iloc[0]

                coeff_row = coeffs_dict_df[(coeffs_dict_df['center_well'] == center_well) &
                                           (coeffs_dict_df['around_well'] == around_well) &
                                           (coeffs_dict_df['date'] == current)]
                if not coeff_row.empty:
                    total_target_inj += reservoir_sampling * coeff_row['distance_coefficient'].values[0]
                else:
                    logger.warning("Нет коэффициента участия для %s и %s на дату %s", around_well, center_well, current)

            total_target_inj *= 1.2

            df_concate = pd.DataFrame({'well_id': [around_well_id],
                                       'well_name': [around_well],
                                       'date': [current],
                                       'target_inj': [total_target_inj],
                                       'solid_id': [solid_id],
                                       'from_cell': False,
                                       'cell_id': None,
                                       'purpose': 'Нагнетательная',
                                       })

            if current == begin_date and idx == 0:
                df_target_inj = df_concate.copy()
            else:
                df_target_inj = pd.concat([df_target_inj, df_concate], ignore_index=True)
            current += relativedelta(months=1)
            total_target_inj = 0

    return df_target_inj


def build_recommended_injection_by_cells(target_injection_df, potential_injection_df, monitoring_by_date,
                                         begin_date, end_date):
    logger = calc_logger if user_id_ctx.get() else general_logger
    logger.info(
        "Начало расчета рекомендованной закачки по ячейкам на объекте %s на период прогноза с %s по %s.",
        target_injection_df['solid_name'].values[0],
        begin_date,
        end_date,
    )
    monitoring_by_date['water_injection'] = monitoring_by_date.apply(
        lambda row: round(row['water_injection'] * 1000 / row['days'], 3), axis=1)
    monitoring_by_date = monitoring_by_date[(monitoring_by_date['date'] >= begin_date) &
                                            (monitoring_by_date['date'] <= end_date)]
    monitoring_by_date = stretch_monitoring_by_end_date(monitoring_by_date, end_date)

    monitoring_by_date = target_injection_df[(target_injection_df['purpose'] == 'Нагнетательная') &
                                             (target_injection_df['target_inj'] > 0.0)][
        ['well_name', 'well_id', 'solid_id', 'cell_id', 'cell_name', 'date']] \
        .merge(monitoring_by_date[['well_id', 'date', 'water_injection']], how='left', on=['well_id', 'date'])
    # monitoring_by_date['water_injection'] = monitoring_by_date['water_injection'].apply(lambda x: round(x, 3))
    monitoring_by_date['sum_inj'] = monitoring_by_date.groupby(['date', 'cell_name'])['water_injection'].transform('sum')

    potential_injection_df = target_injection_df[(target_injection_df['purpose'] == 'Нагнетательная') &
                                                 (target_injection_df['target_inj'] > 0.0)][
        ['well_name', 'well_id', 'solid_id', 'cell_id', 'cell_name', 'date']] \
        .merge(potential_injection_df[['well_name', 'date', 'inj_agrp_potential', 'inj_infr_potential']],
               how='left', on=['well_name', 'date'])
    potential_injection_df['inj_agrp_potential'] = potential_injection_df['inj_agrp_potential'].apply(
        lambda x: round(x, 3))
    potential_injection_df['inj_infr_potential'] = potential_injection_df['inj_infr_potential'].apply(
        lambda x: round(x, 3))
    potential_injection_df['sum_inj_agrp_potential'] = potential_injection_df.groupby(['date', 'cell_name']
                                                                                      )['inj_agrp_potential'].transform(
        'sum')
    potential_injection_df['sum_inj_infr_potential'] = potential_injection_df.groupby(['date', 'cell_name']
                                                                                      )['inj_infr_potential'].transform(
        'sum')

    cells = target_injection_df[target_injection_df['purpose'] == 'Нагнетательная']['cell_name'].unique()

    target_injection_df = target_injection_df[target_injection_df['purpose'] == 'Добывающая']
    target_injection_df['target_inj'] = target_injection_df['target_inj'].apply(lambda x: round(x, 3))
    target_injection_df['sum_target_inj'] = target_injection_df.groupby(['date', 'cell_name'])['target_inj'].transform(
        'sum')

    recommended_inj = pd.DataFrame(columns=['well_name', 'well_id', 'solid_id', 'cell_name', 'cell_id', 'date',
                                            'inj_agrp_recommended', 'inj_infr_recommended'])

    for cell in cells:
        current = begin_date
        while current <= end_date:
            if not target_injection_df[(target_injection_df['date'] == current) &
                                       (target_injection_df['cell_name'] == cell)].empty and \
                    not monitoring_by_date[(monitoring_by_date['date'] == current) &
                                           (monitoring_by_date['cell_name'] == cell)].empty:

                sum_inj = monitoring_by_date[(monitoring_by_date['date'] == current) &
                                             (monitoring_by_date['cell_name'] == cell)]['sum_inj'].values[0]
                sum_target_inj = target_injection_df[(target_injection_df['date'] == current) &
                                                     (target_injection_df['cell_name'] == cell)][
                    'sum_target_inj'].values[0]
                if sum_inj > sum_target_inj:
                    logger.warning("Суммарная закачка мониторинга превысила суммарную целевую закачку на ячейке %s "
                                   "на дату %s. Уменьшаем закачку мониторинга и преобразуем в рекомендованную",
                                   cell, current)
                    upd_inj = decrease_dicrtribution_injection(
                        source_data=monitoring_by_date[
                            (monitoring_by_date['date'] == current) & (monitoring_by_date['cell_name'] == cell)],
                        threashold=sum_target_inj,
                        column='water_injection'
                    )
                    upd_inj['inj_agrp_recommended'] = upd_inj['water_injection']
                    upd_inj['inj_infr_recommended'] = upd_inj['water_injection']
                    upd_inj.drop(['sum_inj', 'water_injection'], axis=1, inplace=True)
                    recommended_inj = pd.concat([upd_inj, recommended_inj], ignore_index=True)
                else:
                    upd_inj = potential_injection_df[
                        (potential_injection_df['date'] == current) & (potential_injection_df['cell_name'] == cell)]

                    for inj_type in ['inj_agrp', 'inj_infr']:

                        sum_inj = potential_injection_df[
                            (potential_injection_df['date'] == current) &
                            (potential_injection_df['cell_name'] == cell)
                            ][f'sum_{inj_type}_potential'].values[0]

                        if sum_inj > sum_target_inj:
                            logger.warning(
                                "Суммарная закачка мониторинга ниже суммарной целевой закачки на ячейке, "
                                "но суммарная потенциальная закачка выше целевой на ячейке %s "
                                "на дату %s. Уменьшаем целевую закачку и преобразуем в рекомендованную",
                                cell, current)
                            upd_inj_peace = decrease_dicrtribution_injection(
                                source_data=upd_inj,
                                threashold=sum_target_inj,
                                column=f'{inj_type}_potential'
                            )
                            upd_inj[f'{inj_type}_recommended'] = upd_inj_peace[f'{inj_type}_potential']
                        else:
                            logger.warning(
                                "Суммарная закачка мониторинга ниже суммарной целевой закачки на ячейке, "
                                "но суммарная целевой закачка выше потенциальной на ячейке %s "
                                "на дату %s. Рекомендованная закачка равно потенциальной",
                                cell, current)
                            upd_inj[f'{inj_type}_recommended'] = upd_inj[f'{inj_type}_potential']

                    upd_inj.drop(['inj_agrp_potential', 'inj_infr_potential',
                                  'sum_inj_agrp_potential', 'sum_inj_infr_potential'], axis=1, inplace=True)
                    recommended_inj = pd.concat([upd_inj, recommended_inj], ignore_index=True)
            else:
                logger.warning("Пропущено вычисление рек. закачки на ячейке %s из-за отсутствия данных "
                               "по целевой закачке и/или данных мониторинга на дату %s", cell, current)
            current += relativedelta(months=1)
    logger.info("Вычисление рекомендованной закачки завершено")
    return recommended_inj


def decrease_dicrtribution_injection(source_data, threashold, column):
    while round(threashold, 3) < round(source_data[column].sum(), 3):
        max_first_idxes = source_data[source_data[column] == source_data[column].max()].index

        if len(max_first_idxes) == source_data.shape[0]:
            diff = source_data[column].sum() - threashold
            source_data[column] = source_data.apply(lambda row: row[column] - diff / source_data.shape[0], axis=1)
        else:
            source_data_wthout_first_max = source_data.drop(max_first_idxes, axis='index')
            max_second_value = source_data_wthout_first_max[
                source_data_wthout_first_max[column] == source_data_wthout_first_max[column].max()][column].values[0]

            source_data.loc[max_first_idxes, column] = max_second_value

            if source_data[column].sum() < threashold:
                diff = threashold - source_data[column].sum()
                source_data.loc[max_first_idxes, column] = max_second_value + diff / len(max_first_idxes)

    return source_data


def build_recommended_injection(target_injection_df, potential_injection_df, begin_date, end_date):
    logger = calc_logger if user_id_ctx.get() else general_logger
    logger.info(
        "Начало расчета рекомендованной закачки на объекте %s на период прогноза с %s по %s.",
        target_injection_df['solid_name'].values[0],
        begin_date,
        end_date,
    )
    q_inj_recommended = target_injection_df[
        ['id', 'well_id', 'well_name', 'solid_id', 'solid_name', 'date', 'target_inj']]
    q_inj_recommended = q_inj_recommended.rename(columns={'id': 'record_target_injection_id'})
    q_inj_recommended = pd.merge(q_inj_recommended,
                                 potential_injection_df[['id', 'well_name', 'solid_id',
                                                         'date', 'techmode_id',
                                                         'inj_agrp_potential',
                                                         'inj_infr_potential']],
                                 how='left', on=['well_name', 'solid_id', 'date'])
    q_inj_recommended = q_inj_recommended[~(q_inj_recommended['techmode_id'].isnull())]
    q_inj_recommended = q_inj_recommended.rename(columns={'id': 'record_potential_injection_id'})
    q_inj_recommended['inj_agrp_recommended'] = q_inj_recommended.apply(
        lambda row: calc_q_inj_rec(row['target_inj'], row['inj_agrp_potential']), axis=1)

    q_inj_recommended['inj_infr_recommended'] = q_inj_recommended.apply(
        lambda row: calc_q_inj_rec(row['target_inj'], row['inj_infr_potential']), axis=1)

    q_inj_recommended.drop(['target_inj', 'inj_agrp_potential', 'inj_infr_potential', 'solid_name'], axis=1,
                           inplace=True)

    q_inj_recommended["techmode_id"] = q_inj_recommended["techmode_id"].replace(np.nan, None)

    logger.info("Вычисление рекомендованной закачки завершено")
    return q_inj_recommended


def define_main_trunk_by_kin_name(well_name, wells_df):
    try:
        return wells_df.loc[wells_df['name'] == well_name, 'main_trunk'].values[0]
    except Exception:
        return None


def calc_q_inj_rec(purpose_injection, potential_injection):
    if potential_injection:
        value = min(purpose_injection, potential_injection)
    else:
        value = purpose_injection
    return value


def partition_df(df: pd.DataFrame,
                 chunk_size: int) -> pd.DataFrame:
    for i in range(0, df.shape[0], chunk_size):
        yield df.iloc[i:i + chunk_size]


def partition_list(records,
                   chunk_size: int):
    for i in range(0, len(records), chunk_size):
        yield records[i:i + chunk_size]


def merge_dataframes(first_df: pd.DataFrame,
                     second_df: pd.DataFrame) -> pd.DataFrame:
    total_df = first_df.append(second_df, ignore_index=True)
    return total_df


def merge_ids(first_id_list: List, second_id_list: List) -> List:
    return first_id_list + second_id_list

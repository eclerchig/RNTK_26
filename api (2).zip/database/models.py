from sqlalchemy import Boolean, Column, Integer, String, Date, Float, ForeignKey, JSON, DateTime
from sqlalchemy.orm import relationship

from schemas.MonthReport import MonthReportSchemeGet, MonthReportScheme
from schemas.calculations import CalculationsSchemeGet, CalculationsScheme
from schemas.geology import GeologySchemeGet, GeologyScheme
from schemas.models import MLModelsSchemeGet, MLModelsScheme
from schemas.statistics import StatisticsSchemeGet, StatisticsScheme
from .base import Base


class MonthReport(Base):
    __tablename__ = 'month_report'

    id = Column(Integer, primary_key=True)
    well = Column(String, nullable=False)
    wellMain = Column(String, nullable=False)
    date = Column(Date)
    debitOil = Column(Float)
    debitLiq = Column(Float)
    watercut = Column(Float)
    cumOil = Column(Float)
    cumLiq = Column(Float)
    timeWorkProd = Column(Float)
    solidPress = Column(Float)
    wellheadPress = Column(Float)
    debitOilFirst = Column(Float)
    debitLiqFirst = Column(Float)
    dynLevel = Column(Float)
    pushTR = Column(Float)

    rateDebitOilFallForYear = Column(Float)
    rateDebitOilFallForMonth = Column(Float)
    numMonthsWithoutWork = Column(Float)

    debitOilMedian = Column(Float)
    debitLiqMedian = Column(Float)
    watercutMedian = Column(Float)
    timeWorkProdMedian = Column(Float)
    solidPressMedian = Column(Float)
    downholePressMedian = Column(Float)
    dynLevelMedian = Column(Float)

    is_calculated = Column(Boolean, default=True)

    statistics_id = Column(Integer, ForeignKey('statistics.id'))
    geology_id = Column(Integer, ForeignKey('geology.id'))
    calc_id = Column(Integer, ForeignKey('calculations.id'))

    geology = relationship("Geology", foreign_keys=['geology_id'], lazy="selectin")
    calculation = relationship("Calculations", foreign_keys=['calc_id'], lazy="selectin")

    def to_read_model(self) -> MonthReportSchemeGet:
        return MonthReportSchemeGet.model_validate(self)

    @staticmethod
    def get_dublicate_filter(data: MonthReportScheme):
        return {
            'well': data.well,
            'date': data.date,
        }


class Geology(Base):
    __tablename__ = 'geology'

    id = Column(Integer, primary_key=True)
    well = Column(String, nullable=False)
    porosity = Column(Float)
    permeability = Column(Float)
    kh = Column(Float)
    onntDensity = Column(Float)
    onnt = Column(Float)
    initOilSaturation = Column(Float)
    nnt = Column(Float)

    def to_read_model(self) -> GeologySchemeGet:
        return GeologySchemeGet.model_validate(self)

    @staticmethod
    def get_dublicate_filter(data: GeologyScheme):
        return {
            'well': data.well,
        }

class Statistics(Base):
    __tablename__ = 'statistics'

    id = Column(Integer, primary_key=True)

    well = Column(String, nullable=False)
    rateDebitOilFallForYear = Column(Float)
    rateDebitOilFallForMonth = Column(Float)
    numMonthsWithoutWork = Column(Float)

    debitOilMedian = Column(Float)
    debitLiqMedian = Column(Float)
    watercutMedian = Column(Float)
    timeWorkProdMedian = Column(Float)
    solidPressMedian = Column(Float)
    downholePressMedian = Column(Float)
    dynLevelMedian = Column(Float)

    calculate_id = Column(Integer, ForeignKey('calculations.id'))
    calculation = relationship("Calculations", foreign_keys=['calculate_id'], lazy="selectin")

    def to_read_model(self) -> StatisticsSchemeGet:
        return StatisticsSchemeGet.model_validate(self)

    @staticmethod
    def get_dublicate_filter(data: StatisticsScheme):
        return {
            'well': data.well,
            'calculate_id' : data.calculate_id,
        }


class Calculations(Base):
    __tablename__ = 'calculations'

    id = Column(Integer, primary_key=True)

    well = Column(String, nullable=False)
    createAt = Column(DateTime)
    predictDate = Column(Date)
    gtm = Column(JSON, nullable=True)

    def to_read_model(self) -> CalculationsSchemeGet:
        return CalculationsSchemeGet.model_validate(self)

    @staticmethod
    def get_dublicate_filter(data: CalculationsScheme):
        return {
            'well': data.well,
            'predictDate': data.predictDate,
        }



class MLModels(Base):
    __tablename__ = 'models'

    id = Column(Integer, primary_key=True)

    name = Column(String, nullable=False)
    version = Column(String, nullable=False)
    type = Column(String, nullable=False)
    date = Column(Date, nullable=False)
    quality = Column(Float, nullable=False)
    user_grade = Column(Float)
    dataVolume = Column(Integer)
    gtm = Column(JSON)
    confisionMatrix = Column(JSON)
    roc = Column(JSON)

    def to_read_model(self) -> MLModelsSchemeGet:
        return MLModelsSchemeGet.model_validate(self)

    @staticmethod
    def get_dublicate_filter(data: MLModelsScheme):
        return {
            'name': data.name,
            'type': data.type,
        }
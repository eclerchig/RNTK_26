import pdb
from typing import List
from pathlib import Path
from asgiref.sync import async_to_sync
from celery.contrib import rdb

from api.celery import celery_app
from interfaces.unit_of_work import UnitOfWork
from logic.chunk_manager import chunk_storage
from schemas.celery import UpdateInfoMeta, UpdateProgressMeta
from schemas.general import SchemeGetFile, SchemeGetData
from services.OptionsStorage import optionsService
from services.cells import CellsService
from tasks.progress_tracker import task_progress_tracker

update_cache = optionsService().update_cache_on_success
uow = UnitOfWork()

@celery_app.task(bind=True)
def get_coeffs_data(self, params: dict):
    params = SchemeGetData(**params)
    solid_id = optionsService().check_value_in_options(params.solid, 'solids')
    json_str = async_to_sync(CellsService().get_data)(uow,
                                                    result_type='json',
                                                    solid_id=solid_id,)
    chunk_storage().parse_json_to_chunks(self.request.id, json_str)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
        )
    )

@celery_app.task(bind=True)
def get_polygons_data(self, params: dict):
    params = SchemeGetData(**params)
    cell_id = optionsService().check_value_in_options(params.cell, 'cells')
    json_str = async_to_sync(CellsService().get_data)(uow,
                                                      result_type='json',
                                                      repository_name="cell_polygons",
                                                      cell_id=cell_id,)
    chunk_storage().parse_json_to_chunks(self.request.id, json_str)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
        )
    )

@celery_app.task(bind=True)
@update_cache(tables=['cells'])
def upload_polygon_files(self, polygon_files_paths: List[Path], solid: str):
    solid_id = optionsService().check_value_in_options(solid, 'solids')
    async_to_sync(CellsService().upload_polygons_files)(uow, polygon_files_paths, solid_id, task_id=self.request.id)
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateProgressMeta(
            alert_msg="Загрузка данных завершена",
            current=100,
            total=100,
        )
    )

@celery_app.task(bind=True)
def upload_coeffs_file(self, coeffs_file_path: Path, solid: str):
    solid_id = optionsService().check_value_in_options(solid, 'solids')
    async_to_sync(CellsService().upload_comp_coeffs_file)(uow, coeffs_file_path, solid_id, task_id=self.request.id)
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateProgressMeta(
            alert_msg="Загрузка данных завершена",
            current=100,
            total=100,
        )
    )

@celery_app.task(bind=True)
def get_coeffs_file(self, params: dict):
    params = SchemeGetFile(**params)
    solid_id = optionsService().check_value_in_options(params.well, 'solids')
    bytes_ = async_to_sync(CellsService().get_data)(uow,
                                                    result_type=params.file_type,
                                                    readable=True,
                                                    solid_id=solid_id,)
    chunk_storage().parse_file_to_chunks(self.request.id, bytes_)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            file_name=f"Ячейки объекта {params.solid}" if params.solid else "Ячейки",
            file_type=params.file_type,
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
        )
    )

@celery_app.task(bind=True)
def get_polygons_file(self, params: dict):
    params = SchemeGetFile(**params)
    cell_id = optionsService().check_value_in_options(params.cell, 'cells')
    solid_id = optionsService().check_value_in_options(params.solid, 'solids')
    bytes_ = async_to_sync(CellsService().get_data)(uow,
                                                    result_type=params.file_type,
                                                    readable=True,
                                                    solid_id=solid_id,
                                                    cell_id=cell_id,)
    chunk_storage().parse_file_to_chunks(self.request.id, bytes_)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            file_name=f"Полигон ячейки {params.cell}" if params.cell \
                    else f"Полигоны ячеек",
            file_type=params.file_type,
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
        )
    )
import os
import shutil

from celery.contrib import rdb

from api.celery import celery_app
from settings import settings


@celery_app.task()
def cleanup_temp():
    folder = settings.TEMPDIR
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            pass
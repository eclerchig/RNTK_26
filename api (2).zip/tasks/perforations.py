import pdb

from celery.contrib import rdb
from pathlib import Path
from asgiref.sync import async_to_sync

from api.celery import celery_app
from interfaces.unit_of_work import UnitOfWork
from logic.chunk_manager import chunk_storage
from schemas.celery import UpdateInfoMeta, UpdateProgressMeta
from schemas.general import SchemeGetFile, SchemeGetData

from services.OptionsStorage import optionsService
from services.perforations import PerforationsService
from tasks.progress_tracker import task_progress_tracker

update_cache = optionsService().update_cache_on_success
uow = UnitOfWork()

@celery_app.task(bind=True)
def get_data(self, params: dict):
    params = SchemeGetData(**params)
    solid_id = optionsService().check_value_in_options(params.solid, 'solids')

    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateProgressMeta(
            alert_msg="Получение даных из БД",
            current=15,
            total=100,
        )
    )
    json_str = async_to_sync(PerforationsService().get_data)(uow,
                                                             result_type='json',
                                                             well_name=params.well,
                                                             solid_id=solid_id,)
    chunk_storage().parse_json_to_chunks(self.request.id, json_str)
    chunk_storage().save_chunks_in_cache(self.request.id)

    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
            begin_current=50,
        )
    )

@celery_app.task(bind=True)
def upload_file(self, file_path: Path, calc_coords_only_new):
    async_to_sync(PerforationsService().upload_perforations_file)(uow, file_path, calc_coords_only_new,
                                                                  task_id=self.request.id)
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateProgressMeta(
            alert_msg="Загрузка данных завершена",
            current=100,
            total=100,
        )
    )

@celery_app.task(bind=True)
def get_file(self, params: dict):
    params = SchemeGetFile(**params)
    solid_id = optionsService().check_value_in_options(params.solid, 'solids')

    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateProgressMeta(
            alert_msg="Получение даных из БД",
            current=15,
            total=100,
        )
    )

    bytes_ = async_to_sync(PerforationsService().get_data)(uow,
                                                           result_type=params.file_type,
                                                           readable=True,
                                                           well_name=params.well,
                                                           solid_id=solid_id,)
    chunk_storage().parse_file_to_chunks(self.request.id, bytes_)
    chunk_storage().save_chunks_in_cache(self.request.id)

    file_name = "Перфорации"
    if params.well and params.solid:
        file_name = f"Перфорации скважины {params.well} на объекте {params.solid}"
    elif params.well:
        file_name = f"Перфорации скважины {params.well}"
    elif params.solid:
        file_name = f"Перфорации на объекте {params.solid}"
    # Сохранение метаданных для клиента
    task_progress_tracker.update_meta(
        task_id=self.request.id,
        data=UpdateInfoMeta(
            file_name=file_name,
            file_type=params.file_type,
            total_chunks=chunk_storage().get_len_chunks(self.request.id),
            begin_current=50,
        )
    )
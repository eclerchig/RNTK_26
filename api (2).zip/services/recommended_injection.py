import pdb

from interfaces.DIContainer import service_container as services
from interfaces.service import BaseDataService
from logic.decorators import append_cells_coeffs_to_dataframe

from stratagies.LoadTable import build_recommended_injection, build_recommended_injection_by_cells


class RecommendedInjectionService(BaseDataService):
    def __init__(self):
        super().__init__(repository_name='recommended_injections')

    async def calculate_recommended_injection(self, uow, user_id,
                                              begin_monitoring,
                                              end_monitoring,
                                              solid,
                                              calc_by_cell=False):

        solid_df = await services['solids'].get_data(uow, result_type='dataframe', name=solid)
        solid_id = solid_df['id'].values[0]

        monitoring_by_date = await services['monitoring'].get_data(
            uow, result_type='dataframe',
            solid_id=solid_df['id'].values[0],
            user_id=user_id,
            repository_name='prod_monitoring',
        )

        await services['target_injection'].calculate_target_injection(
            uow, user_id,
            begin_monitoring, end_monitoring,
            solid,
            prod_monitoring_df=monitoring_by_date,
            calc_by_cell=calc_by_cell,
        )

        await services['potential_injection'].calculate_potential_injection(
            uow, user_id, begin_monitoring,
            end_monitoring,
            solid
        )

        target_inj_df = await services['target_injection'].get_data(uow, result_type='dataframe',
                                                                    from_cell=calc_by_cell,
                                                                    solid_id=solid_id,
                                                                    user_id=user_id,
                                                                    )
        potential_inj_df = await services['potential_injection'].get_data(uow, result_type='dataframe',
                                                                          solid_id=solid_id,
                                                                          user_id=user_id,
                                                                          )

        async with uow:
            if calc_by_cell:
                recommended_inj_df = build_recommended_injection_by_cells(
                    target_inj_df, potential_inj_df, monitoring_by_date,
                    begin_monitoring, end_monitoring
                )
                recommended_inj_df[['record_target_injection_id', 'record_potential_injection_id', 'techmode_id']] = None
                recommended_inj_df['from_cell'] = True
                recommended_inj_df.drop('cell_name', axis=1, inplace=True)
            else:
                recommended_inj_df = build_recommended_injection(target_inj_df, potential_inj_df,
                                                                 begin_monitoring, end_monitoring)
                recommended_inj_df['from_cell'] = False
                recommended_inj_df['cell_id'] = None

            recommended_inj_df.drop('well_name', axis=1, inplace=True)
            recommended_inj_df['user_id'] = user_id

            recommended_inj_recs = recommended_inj_df.to_dict(orient='records')

            ids = [await uow.recommended_injections.add_one(rec, check_dublicate=True) for rec in recommended_inj_recs]
            ids = [id for id in ids if id is not None]
            await uow.commit()
            return ids

    @append_cells_coeffs_to_dataframe
    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        return await super().get_data(uow, result_type=result_type, readable=readable,
                                      repository_name=repository_name,
                                      config_sort=[('date', False)], **filter_by)

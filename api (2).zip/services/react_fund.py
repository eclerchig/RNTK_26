import pdb

from fastapi import UploadFile, File

from exceptions.services import ServiceFileUploadException
from interfaces.service import BaseDataService
from logic.file_upload_processors.FileUploadProcessor import ExcelConverter
from logic.file_upload_processors.ReactFundFileUploadProcessor import ReactFundFileUploadProcessor
from services.monitoring import MonitoringService
from services.solids import SolidsService


class ReactFundService(BaseDataService):
    def __init__(self):
        super().__init__(repository_name='react_fund')

    async def upload_react_fund_file(self, uow, solid_name, user_id, file: UploadFile = File(...)):
        content = await file.read()
        async with uow:
            solids_df = await SolidsService().get_data(uow, result_type='dataframe', name=solid_name)
            wells_monitoring_df = await MonitoringService().get_data(uow, result_type='dataframe',
                                                                     solid_id=solids_df['id'].values[0])
        try:
            react_fund_df = ReactFundFileUploadProcessor(ExcelConverter())\
                .process(content, wells_monitoring_df=wells_monitoring_df, user_id=user_id)
        except Exception as e:
            raise ServiceFileUploadException(e)

        react_fund_recs = react_fund_df.to_dict(orient='records')

        async with uow:
            await self.delete_react_fund(uow, solid_id=solids_df['id'].values[0])

            ids = [await uow.react_fund.add_one(fund) for fund in react_fund_recs]
            ids = [id for id in ids if id is not None]
            await uow.commit()
            return ids

    async def upload_react_fund_df(self, uow, df, **delete_filters_by):
        react_fund_recs = df.to_dict(orient='records')

        async with uow:
            await self.delete_react_fund(uow, **delete_filters_by)
            ids = [await uow.react_fund.add_one(fund, check_dublicate=False) for fund in react_fund_recs]
            ids = [id for id in ids if id is not None]
            await uow.commit()
            return ids

    async def delete_react_fund(self, uow, mode='upd_delete_status', **delete_filter_by):
        '''
        params:
            mode - принимает 2 значения: {
                'upd_delete_status' - просто меняет статус for_delete на True,
                'delete_rows' - удаляет строки с for_delete=True из БД
            }
        '''
        if mode == 'upd_delete_status':
            if uow.is_open:
                await uow.react_fund.update_by_filter(
                    filter_by=delete_filter_by,
                    values={
                        'for_delete': True
                    }
                )
            else:
                async with uow:
                    await uow.react_fund.update_by_filter(
                        filter_by=delete_filter_by,
                        values={
                            'for_delete': True
                        }
                    )
                    await uow.commit()
        elif mode == 'delete_rows':
            async with uow:
                await uow.react_fund.delete_all(for_delete=True)
                await uow.commit()

    async def get_data(self, uow, result_type='scheme', readable=False, **filter_by):
        filter_by['for_delete'] = False
        data = await super().get_data(uow=uow,
                                      result_type=result_type,
                                      readable=readable,
                                      repository_name=self.repository_name,
                                      **filter_by,
                                      )
        return data
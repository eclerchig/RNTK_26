import pdb

import os
from os.path import dirname, abspath
import tempfile
from settings import settings

from exceptions.business import NotExistFundForSolidException, \
    NotExistCellsDataForSolidException, NotExistCellsPolygonsDataForSolidException
from interfaces.service import BaseDataService
from services.OptionsStorage import OptionsCacheService
from stratagies.LoadTable import create_coeffs_df, create_react_fund_df_from_monitoring

from interfaces.DIContainer import service_container as services

ROOT_DIR = dirname(dirname(abspath(__file__)))

class ParticipationCoefficientService(BaseDataService):
    tempfile.tempdir = os.path.join(ROOT_DIR, settings.TEMPDIR)

    def __init__(self):
        super().__init__(repository_name='participation_coeffs')

    async def build_participation_coeffs_df(self, uow, user_id,
                                            begin_monitoring, end_monitoring, solid_name, react_radius,
                                            last_fact_date, calc_by_cells=False, auto_react_fund=False,
                                            delete_zero_coeff=False, purpose_center='Добывающая',
                                            remove_very_remote_fund=False):
        if calc_by_cells:
            purpose_center = 'Нагнетательная'

        solid_id = OptionsCacheService().check_value_in_options(solid_name, 'solids')

        perfs_df = await services['perforations'].get_data(uow, result_type='dataframe', solid_id=solid_id)
        incls_df = await services['inclinometry'].get_data(uow, result_type='dataframe')
        prod_monitoring_df = await services['monitoring'].get_data(uow,
                                                                   result_type='dataframe',
                                                                   solid_id=solid_id,
                                                                   user_id=user_id,
                                                                   repository_name='prod_monitoring')
        wells_monitoring_df = await services['monitoring'].get_data(uow,
                                                                    result_type='dataframe',
                                                                    solid_id=solid_id,
                                                                    user_id=user_id,
                                                                    repository_name='wells_monitoring')

        react_fund_df = None
        if auto_react_fund and not calc_by_cells:
            react_fund_df = create_react_fund_df_from_monitoring(wells_monitoring_df, solid_id)
            react_fund_df['user_id'] = user_id
            await services['react_fund'].upload_react_fund_df(uow,
                                                              react_fund_df,
                                                              solid_id=solid_id,
                                                              user_id=user_id)
        if not calc_by_cells:
            react_fund_df = await services['react_fund'].get_data(uow,
                                                                  result_type='dataframe',
                                                                  solid_id=solid_id,
                                                                  center_well_purpose=purpose_center,
                                                                  user_id=user_id)
            if react_fund_df.empty:
                raise NotExistFundForSolidException(solid_name)

        cells_df, polygons_df = None, None
        if calc_by_cells:
            cells_df = await services['cells'].get_data(uow,
                                                        result_type='dataframe',
                                                        solid_id=solid_id,
                                                        repository_name='cells')
            if cells_df.empty:
                raise NotExistCellsDataForSolidException(solid_name)
            polygons_df = await services['cells'].get_data(uow,
                                                           result_type='dataframe',
                                                           repository_name='cell_polygons')
            if polygons_df.empty:
                raise NotExistCellsPolygonsDataForSolidException(solid_name)

        coeffs_df, removes_fund_df = await create_coeffs_df(perfs_df, incls_df, wells_monitoring_df, prod_monitoring_df,
                                                            begin_monitoring, end_monitoring, react_radius,
                                                            last_fact_date, delete_zero_coeff,
                                                            calc_by_cells, react_fund_df, cells_df, polygons_df)
        if calc_by_cells:
            coeffs_df = coeffs_df.merge(wells_monitoring_df[['id', 'well_name']],
                                        left_on=['center_well'], right_on=['well_name'], how='left')
            coeffs_df.rename(columns={'id': 'center_well_id'}, inplace=True)
            coeffs_df.drop(columns=['well_name', 'center_well'], axis=1, inplace=True)

            coeffs_df = coeffs_df.merge(cells_df[['id', 'name']],
                                        left_on=['cell_name'], right_on=['name'], how='left')
            coeffs_df.rename(columns={'id': 'cell_id'}, inplace=True)
            coeffs_df.drop(columns=['cell_name', 'name'], axis=1, inplace=True)

            coeffs_df[['react_fund_id', 'around_well_id']] = None
            coeffs_df[['distance', 'correlation_coefficient']] = 0.0

        coeffs_df['solid_id'] = solid_id
        coeffs_df['from_cell'] = calc_by_cells
        coeffs_df['user_id'] = user_id
        coeffs_recs = coeffs_df.to_dict(orient='records')

        async with uow:
            if remove_very_remote_fund:
                removes_fund_df = removes_fund_df.merge(react_fund_df[['center_well_id',
                                                                       'around_well_id',
                                                                       'center_well',
                                                                       'around_well',
                                                                       'center_well_purpose']],
                                                        on=['center_well', 'around_well', 'center_well_purpose'],
                                                        how='left')
                for _, row in removes_fund_df.iterrows():
                    await services['react_fund_service'].delete_react_fund(uow,
                                                                           center_well_id=row['center_well_id'],
                                                                           around_well_id=row['around_well_id'],
                                                                           center_well_purpose=row['center_well_purpose'])

            [await uow.participation_coeffs.delete_all(solid_id=solid_id,
                                                       date=dt,
                                                       center_well_purpose=purpose_center,
                                                       from_cell=calc_by_cells,
                                                       )
             for dt in coeffs_df['date'].unique()]

            [await uow.participation_coeffs.add_one(rec, check_dublicate=True) for rec in coeffs_recs]
            await uow.commit()

    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        config_sort = [
            ('date', False),
        ]
        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      config_sort=config_sort,
                                      **filter_by,
                                      )
        return data
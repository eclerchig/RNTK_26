import asyncio
import pdb
import datetime
from io import BytesIO
from os.path import dirname, abspath

import pandas as pd
from fastapi import UploadFile

from interfaces.unit_of_work import UnitOfWork

from interfaces.service import BaseDataService

ROOT_DIR = dirname(dirname(abspath(__file__)))


class DataProcessService(BaseDataService):

    CONTINIOUS_VARS = ['debitOil', 'debitLiq', 'watercut', 'timeWorkProd', 'solidPress', 'downholePress', 'dynLevel']

    async def process_mer(self, file: UploadFile):
        contents = await file.read()
        excel_file = BytesIO(contents)
        df = pd.read_excel(excel_file, sheet_name='МЭР')
        df = df.drop(df.columns[[14, 15]], axis=1)
        df.columns = ['date', 'well', 'mainWell', 'debitOil', 'debitLiq', 'watercut',
                      'cumOil','cumLiq', 'timeWorkProd', 'solidPress',
                      'downholePress', 'debitOilFirst', 'debitLiqFirst', 'dynLevel', 'pushTR']
        df['date'] = pd.to_datetime(df['date'], format='%d.%m.%Y')
        df['well'] = df['well'].astype(str)
        df['mainWell'] = df['mainWell'].astype(str)
        return df

    async def process_geology(self, file: UploadFile):
        contents = await file.read()
        excel_file = BytesIO(contents)
        df = pd.read_excel(excel_file, sheet_name='Геология')
        df = df.drop(df.columns[1], axis=1)
        df.columns = ['well', 'porosity', 'permeability', 'kh',
                      'onntDensity', 'onnt', 'initOilSaturation', 'nnt']
        df['well'] = df['well'].astype(str)
        return df

    async def create_stat_df(self, df_mer, prediction_date):
        df_mer['rateDebitOilFallForYear'] = df_mer.apply(
            lambda row:
            df_mer[(df_mer['date'] == (row['date'] - pd.DateOffset(months=12))) &
                   (df_mer['well'] == row['well'])]['debitOil'].iloc[0] - row['debitOil']
            if df_mer[(df_mer['date'] == (row['date'] - pd.DateOffset(months=12))) &
                      (df_mer['well'] == row['well'])].shape[0] != 0
            else None,
            axis=1)
        df_mer['dateYearBefore'] = df_mer.apply(lambda row: row['date'] - pd.DateOffset(months=12), axis=1)
        df_mer['rateDebitOilFallForMonth'] = df_mer.apply(
            lambda row:
            df_mer[(df_mer['date'] == (row['date'] - pd.DateOffset(months=1))) &
                   (df_mer['well'] == row['well'])]
            ['debitOil'].iloc[0] - row['debitOil']
            if df_mer[(df_mer['date'] == (row['date'] - pd.DateOffset(months=1))) &
                      (df_mer['debitOil'] == row['debitOil'])].shape[0] != 0
            else None,
            axis=1)
        df_mer = df_mer[df_mer.groupby(['well'])['well'].transform('count') >= 12].copy()
        for col in self.CONTINIOUS_VARS:
            df_mer[f'{col} median'] = df_mer.groupby(['well'])[col].transform('median')
        zero_days_counts = df_mer.groupby(['well'])['timeWorkProd'].apply(
            lambda x: (x == 0).sum()).reset_index(name='numMonthsWithoutWork')
        df_mer = df_mer.merge(zero_days_counts, on=['wells'], how='left')
        df_mer = df_mer.drop(df_mer[(df_mer['date'].dt.year != prediction_date.year) |
                              (df_mer['date'].dt.month != prediction_date.month)].index)
        return df_mer

    async def process_file(self, uow: UnitOfWork, predict_date: datetime.date, file_mer: UploadFile, file_geology: UploadFile):
        '''
        Обновляет таблицы МЭР, Геологии и Статистики.
        :param uow: UnitOfWork - работает с сессиями в БД
        :param predict_date: дата прогноза - от нее отсчитывается 12 мес назад для прогноза
        :param file_mer: Файл с листом МЭР и соответствующими колонками
        :param file_geology: Файл с листом Геология и соответствующими колонками
        :return: id записи Calculation для дальнейщего вывода
        '''

        # Чтение файлов
        tasks = [
            asyncio.create_task(self.process_mer(file_mer), name="proc_mer"),
            asyncio.create_task(self.process_geology(file_geology), name="proc_geo"),
        ]

        await asyncio.wait(tasks, return_when=asyncio.ALL_COMPLETED)

        results = []
        for task in tasks:
            results.append(task.result())

        df_mer, df_geo = results

        df_statistics = await self.create_stat_df(df_mer, predict_date)
        calculation_rec = [{
            'predictDate': predict_date,
        }]

        # Сначала загрузка всех данных для внешних ключей перед загрузкой МЭР
        async with uow:
            # Сохранение геологии
            [await uow.geology.add_one(rec, check_dublicate=True) for rec in df_geo.to_dict(orient='records')]
            await uow.commit()

        async with uow:
            # Сохранение записей о будущем расчете и статистических данных
            id_calc = await uow.calculations.add_one(calculation_rec, check_dublicate=True)

            df_statistics['calculation_id'] = id_calc
            [await uow.statistics.add_one(rec, check_dublicate=True) for rec in df_statistics.to_dict(orient='records')]

            await uow.commit()

        # Сохранение МЭР со всеми внешними ключами
        async with uow:
            geology = await uow.geology.find_all(mode='scheme', config_sort=[('well', True),], )
            geology_df = uow.geology.schemes_to_dataframe(geology)
            df_mer = df_mer.merge(geology_df[['id', 'well']], how='left', on='well')
            df_mer = df_mer.rename(columns={'id': 'geology_id'})
            df_mer['calculation_id'] = id_calc

            [await uow.mer.add_one(rec, check_dublicate=True) for rec in df_mer.to_dict(orient='records')]
            await uow.commit()

        return id_calc

    async def get_uploaded_well_data(self, uow: UnitOfWork, calc_id):
        df_mer = await self.get_data(uow,
                                     result_type='dataframe',
                                     repository_name='month_report',
                                     calculation_id=calc_id,
                                     )
        geology = await uow.geology.find_all(mode='scheme')
        df_geology = uow.geology.schemes_to_dataframe(geology)

        df_total = df_mer.merge(df_geology, how='left', on=['well'])

        statistics = await uow.statistics.find_all(mode='scheme', calculation_id=calc_id,)
        df_statistics = uow.statistics.schemes_to_dataframe(statistics)

        df_total = df_total.merge(df_statistics, how='left', on=['well', 'date'])

        return df_total

    async def get_data(self, uow, result_type='scheme', readable=False, repository_name=None, **filter_by):
        config_sort = [
            ('well', True),
            ('date', True),
        ]

        data = await super().get_data(uow,
                                      result_type=result_type,
                                      readable=readable,
                                      config_sort=config_sort,
                                      repository_name='',
                                      **filter_by,
                                      )
        return data
import catGif from './pixel-duck.gif'
import './ProgressScreen.css'

const ProgressScreen = ({ progress, totalProgress, title}) => {

    let letters = title.split("")

    return (
        <div className='overlay'>
            <img src={catGif} alt="Loading..." className='loading-gif'/>

            <div className='progress-conteiner'>
                <div className='title'>
                    {
                        letters.map((l, index) => <span style={{'--i': index}}>{l}</span>)
                    }
                </div>
                <span className='percent'>{progress}/{totalProgress}</span>
            </div>
        </div>
    )
}

export default ProgressScreen
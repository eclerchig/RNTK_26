import {Box, Paper} from "@mui/material";
import Typography from "@mui/material/Typography";

const matrix = [
  [30, 10, 7],
  [5, 15, 7],
  [5, 5, 40],
]
const classes = ['ОПЗ', 'ИДН', 'ЛНЭК']

const getColor = (value, numRow) => {
  const maxValue = Math.max(...matrix[numRow])
  console.log(matrix[numRow])
  const intensity = value/maxValue
  switch (numRow) {
    case 0: {
      return `rgba(250, 79, 88, ${intensity})`
    }
    case 1: {
      return `rgba(255, 180, 34, ${intensity})`
    }
    case 2: {
      return `rgba(66, 84, 251, ${intensity})`
    }
  }
}

const getFontColor = (value, numRow) => {
  const maxValue = Math.max(...matrix[numRow])
  return value > maxValue / 2 ? 'white' : 'black'
}

export default function ChartConfusionMatrix() {
    return (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1}}>
              {/* Заголовки столбцов */}
              <Box sx={{ display: 'grid', gridTemplateColumns: '50px repeat(3, 1fr)', gap: 1, mb: 1 }}>
                <Box/>
                {classes.map((label, idx) => (
                  <Typography key={idx} variant="subtitle2" align="center">{label}</Typography>
                ))}
              </Box>
              {/* Строки матрицы */}
              { matrix.map((row, i) => (
                <Box key={i} sx={{ display: 'grid', gridTemplateColumns: '50px repeat(3, 1fr)', gap: 1, alignItems: 'center' }}>
                  <Typography key={i} variant="subtitle2" align="right" sx={{ pr: 2}}>{classes[i]}</Typography>
                {/* Ячейки матрицы */}
                {
                  row.map((value, j) => (
                    <Paper 
                      key={j} 
                      elevation={0} 
                      sx={{ 
                        p: 2, 
                        textAlign: 'center', 
                        backgroundColor: getColor(value, i),
                        color: getFontColor(value, i),
                        fontWeight: 'bold',
                        transition: 'all 0.3s',
                        '&.:hover': {
                          transform: 'scale(1.05)',
                          boxShadow: 3,
                        }
                        }}>
                      {value}
                    </Paper>
                  ))
                }
                </Box>
              ))}
            </Box>
    )
}
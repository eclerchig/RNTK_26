import { useState, useEffect } from "react";
import { TextField, ThemeProvider } from "@mui/material";
import { rosneftTextFieldTheme, rosneftBtnTheme } from "./themes";
import './wellSelector.css';

const WellSelector = ({ wellOptions = [], handleSelectWell, selectedWell }) => {
    const [filteredWells, setFilteredWells] = useState([])

    const filterHandler = (substring = "") => {
        if (substring === "") {
            setFilteredWells(wellOptions)
        } else {
            setFilteredWells(wellOptions.filter(well => well.name.startsWith(substring)))
        }
    }

    useEffect(() => {
        filterHandler("")
    }, [wellOptions])

    return <div className='wellSelectedGroupBlock mt-3'>
        <ThemeProvider theme={rosneftTextFieldTheme}>
            <TextField 
                variant="outlined" 
                label="Поиск скважины" 
                size="small" 
                margin="dense"
                onChange={(e) => {filterHandler(e.target.value)}}
            />
        </ThemeProvider>
        <ul>
            {filteredWells.map((well) => (
                <li
                    key={well.id}
                    onClick={() => handleSelectWell(well)}
                        style={{
                            backgroundColor: selectedWell?.id === well.id ? rosneftBtnTheme.palette.orange.dark : 'white',
                            border: selectedWell?.id === well.id ? `solid 2px white` : null,
                            color: selectedWell?.id === well.id ? 'white' : '#333',
                        }}
                >
                    <span>{well.name}</span>
                </li>
            ))}
        </ul>
    </div>
}

export default WellSelector
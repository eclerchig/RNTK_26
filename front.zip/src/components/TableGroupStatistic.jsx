import dayjs from "dayjs";
import './TableGroupStatistic.css'

const columns = [
    {
        accessorKey: 'debitOil',
        header: 'Дебит нефти, т/сут'
    },
    {
        accessorKey: 'debitLiq',
        header: 'Дебит жидкости, т/сут'
    },
    {
        accessorKey: 'watercut',
        header: 'Обводненность, %'
    },
    {
        accessorKey: 'cumOil',
        header: 'Накопленный отбор нефти, т'
    },
    {
        accessorKey: 'cumLiq',
        header: 'Накопленный отбор жидкости, т'
    },
    {
        accessorKey: 'timeWorkProd',
        header: 'Время работы в добыче, часы'
    },
    {
        accessorKey: 'solidPress',
        header: 'Пластовое давление (ТР), атм'
    },
    {
        accessorKey: 'downholePress',
        header: 'Забойное давление (замер), атм'
    },
    {
        accessorKey: 'debitOilFirst',
        header: 'Дебит нефти за первый раб.месяц, т/сут'
    },
    {
        accessorKey: 'debitLiqFirst',
        header: 'Дебит жидкости за первый раб.месяц, т/сут'
    },
    {
        accessorKey: 'dynLevel',
        header: 'Динамический уровень (ТР), м'
    },
    {
        accessorKey: 'depthPump',
        header: 'Глубина спуска насоса, м'
    },
    {
        accessorKey: 'depthPerf',
        header: 'Глубина верхних дыр перфорации (ТР), м'
    },
    {
        accessorKey: 'pushTR',
        header: 'Напор (ТР)'
    },
    {
        accessorKey: 'geology.porosity',
        header: 'Пористость'
    },
    {
        accessorKey: 'geology.permeability',
        header: 'Проницаемость'
    },
    {
        accessorKey: 'geology.kh',
        header: 'Геология - KH проводимость'
    },
    {
        accessorKey: 'geology.onntDensity',
        header: 'Геология - Плотность ОННТ'
    },
    {
        accessorKey: 'geology.onnt',
        header: 'Геология - ОННТ'
    },
    {
        accessorKey: 'geology.initOilSaturation',
        header: 'Геология - Нач. нефтенасыщенность'
    },
    {
        accessorKey: 'geology.nnt',
        header: 'Геология - ННТ'
    }
]

export const example_data = [
    {
        well: '100',
        mainWell: '100',
        date: dayjs('01-10-2010', 'DD-MM-YYYY'),
        debitOil: 206,
        debitLiq: 231,
        watercut: 10,
        cumOil: 6651,
        cumLiq: 7422,
        timeWorkProd: 744,
        solidPress: 265,
        downholePress: 128,
        debitOilFirst: 289,
        debitLiqFirst: 304,
        dynLevel: 1446,
        depthPump: 3550,
        depthPerf: 3763,
        pushTR: 1567,
        geology: {
            porosity: 0.24,
            permeability: 164,
            kh: 16713,
            onntDensity: 0,
            onnt: 5,
            initOilSaturation: 0,
            nnt: 6,
        }
    },
    {
        well: '100',
        mainWell: '100',
        date: dayjs('01-11-2010', 'DD-MM-YYYY'),
        debitOil: 101,
        debitLiq: 130,
        watercut: 22,
        cumOil: 9685,
        cumLiq: 11349,
        timeWorkProd: 720,
        solidPress: 265,
        wellheadPress: 117,
        debitOilFirst: 289,
        debitLiqFirst: 304,
        dynLevel: 1446,
        depthPump: 3550,
        depthPerf: 3763,
        pushTR: 1567,
        geology: {
            porosity: 0.24,
            permeability: 164,
            kh: 16713,
            onntDensity: 0,
            onnt: 5,
            initOilSaturation: 0,
            nnt: 6,
        }
    },
    {
        well: '1001А',
        mainWell: '1001',
        date: dayjs('01-05-2018', 'DD-MM-YYYY'),
        debitOil: 87,
        debitLiq: 148,
        watercut: 40,
        cumOil: 1532,
        cumLiq: 2594,
        timeWorkProd: 419,
        solidPress: 125,
        wellheadPress: 88,
        debitOilFirst: 87,
        debitLiqFirst: 148,
        dynLevel: 818,
        depthPump: 1350,
        depthPerf: 1800,
        pushTR: 1605,
        geology: {
            porosity: 0.27,
            permeability: 338,
            kh: 28108,
            onntDensity: 0.88,
            onnt: 11,
            initOilSaturation: 0.58,
            nnt: 12,
        }
    },
    {
        well: '1001А',
        mainWell: '1001',
        date: dayjs('01-06-2018', 'DD-MM-YYYY'),
        debitOil: 0,
        debitLiq: 0,
        watercut: 0,
        cumOil: 29882,
        cumLiq: 48678,
        timeWorkProd: 419,
        solidPress: 135,
        wellheadPress: 131,
        debitOilFirst: 87,
        debitLiqFirst: 148,
        dynLevel: 1207,
        depthPump: 1338,
        depthPerf: 1800,
        pushTR: 2046,
        geology: {
            porosity: 0.27,
            permeability: 338,
            kh: 28108,
            onntDensity: 0.88,
            onnt: 11,
            initOilSaturation: 0.58,
            nnt: 12,
        }
    },
    {
        well: '1010А',
        mainWell: '1010',
        date: dayjs('01-10-2021', 'DD-MM-YYYY'),
        debitOil: 0,
        debitLiq: 0,
        watercut: 0,
        cumOil: 5,
        cumLiq: 271,
        timeWorkProd: 0,
        solidPress: 160,
        wellheadPress: 72,
        debitOilFirst: 0,
        debitLiqFirst: 35,
        dynLevel: 0,
        depthPump: 2512,
        depthPerf: 3629,
        pushTR: null,
        geology: {
            porosity: 0.26,
            permeability: 476,
            kh: 40251,
            onntDensity: 0.21,
            onnt: 8,
            initOilSaturation: 0.41,
            nnt: 10,
        }
    },
    {
        well: '1010А',
        mainWell: '1010',
        date: dayjs('01-11-2021', 'DD-MM-YYYY'),
        debitOil: 0,
        debitLiq: 35,
        watercut: 0,
        cumOil: 28,
        cumLiq: 1345,
        timeWorkProd: 720,
        solidPress: 160,
        wellheadPress: 134,
        debitOilFirst: 0,
        debitLiqFirst: 35,
        dynLevel: 0,
        depthPump: 2512,
        depthPerf: 3629,
        pushTR: null,
        geology: {
            porosity: 0.26,
            permeability: 476,
            kh: 40251,
            onntDensity: 0.21,
            onnt: 8,
            initOilSaturation: 0.41,
            nnt: 10,
        }
    }
]

function getMedian(arr) {
    // 1. Сортировка массива (обязательно с функцией сравнения)
    const sorted = [...arr].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);

    // 2. Проверка на четность
    if (sorted.length % 2 !== 0) {
        // Нечетное: средний элемент
        return sorted[mid];
    } else {
        // Четное: среднее арифметическое двух средних
        return (sorted[mid - 1] + sorted[mid]) / 2;
    }
}

function calculateSD(array) {
    const n = array.length;
    if (n === 0) return 0;

    // 1. Находим среднее значение (mean)
    const mean = array.reduce((a, b) => a + b) / n;

    // 2. Находим сумму квадратов отклонений от среднего
    // 3. Делим на n (для генеральной совокупности) или n-1 (для выборки)
    const variance = array.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n;

    // 4. Берем квадратный корень
    return Math.sqrt(variance);
}


const TableGroupStatistic = ({data = [], indexies}) => {

    const getStatValues = (values) => {
        const mediate = values.length > 0 ? getMedian(values) : 0
        const minimum = values.length > 0 ? Math.min(...values) : 0
        const maximum = values.length > 0 ? Math.max(...values) : 0
        const sd = values.length > 0 ? calculateSD(values).toFixed(2) : 0
        return [mediate, minimum, maximum, sd]
    }
    indexies = columns;

    return (
        <div className='stat-table'>
            <table>

                <thead>
                    <tr>
                        <th colSpan="100%">
                            Показатели скважин в группе ГТМ
                        </th>
                    </tr>
                    <tr>
                        <th className='center-align-th'>Показатель</th>
                        <th className='center-align-th'>Медиана</th>
                        <th className='center-align-th'>Мин.</th>
                        <th className='center-align-th'>Макс.</th>
                        <th className='center-align-th'>Среднекв. отклонение</th>
                    </tr>
                </thead>

                <tbody >
                    {
                        indexies.map((row) => {
                            const variableName = row.accessorKey;
                            const displayName = row.header;

                            var values = data.length > 0 ? data.map((col) => {
                                var path = variableName.split('.');
                                let value = col;
                                path.forEach(element => {
                                    value = value[element]
                                });
                                return value;
                            }).filter(item => typeof item === 'number' && !isNaN(item)) : []

                            const [mediate, minimum, maximum, sd] = getStatValues(values);
                            return <tr>
                                <td className='left-align-th' style={{fontWeight: 'bold', paddingLeft:'20px'}}>{displayName}</td>
                                <td className='center-align-th' >{mediate}</td>
                                <td className='center-align-th' >{minimum}</td>
                                <td className='center-align-th' >{maximum}</td> 
                                <td className='center-align-th' >{sd}</td>
                            </tr>
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}

export default TableGroupStatistic
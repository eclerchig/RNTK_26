import {useState, useMemo, useEffect, useRef} from "react"
import {FormControl, Grid, InputLabel, MenuItem, Select, Typography, Paper, Popper} from "@mui/material"
import {LineChart, useItemTooltip, useAxisTooltip} from "@mui/x-charts"
import dayjs from "dayjs";
import {rosneftBtnTheme} from "./themes.jsx";

const colors = [
    'rgb(250, 79, 88)',
    'rgb(66, 84, 251)',
    'rgb(255, 180, 34)',
]

const CustomItemTooltip = ({ chartRef }) => {
  const tooltip = useItemTooltip()

    // Состояние для позиции мыши
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  // Отслеживаем движение мыши по графику
  useEffect(() => {
    const svgElement = chartRef?.current;
    if (!svgElement) return;

    const handleMouseMove = (event) => {
      // Получаем координаты мыши относительно окна
        setMousePosition({
            x: event.clientX,
            y: event.clientY,
        });
        };
        svgElement.addEventListener('mousemove', handleMouseMove);
        return () => {
        svgElement.removeEventListener('mousemove', handleMouseMove);
        };
    }, []);

    console.log(tooltip)

    if (!tooltip) {
        return null
    }

    const virtualElement = {
        getBoundingClientRect: () => ({
          width: 0,
          height: 0,
          x: mousePosition.x,
          y: mousePosition.y,
          left: mousePosition.x,
          right: mousePosition.x,
          top: mousePosition.y,
          bottom: mousePosition.y,
        }),
    };

    return (
        <Popper
          open={true}
          anchorEl={virtualElement}
          placement="top-start"
          modifiers={[
            {
              name: 'flip',
              enabled: true,
              options: {
                padding: 8,
              },
            },
            {
              name: 'preventOverflow',
              enabled: true,
              options: {
                padding: 8,
              },
            },
            {
              name: 'offset',
              options: {
                offset: [10, -130], // [горизонталь, вертикаль] - смещаем на 10px вниз
              },
            },
          ]}
          // Важно! Отключаем портал, чтобы тултип был в том же контексте
          disablePortal={true}
          // Добавляем стили для правильного позиционирования
          style={{ zIndex: 9999 }}
        >
            <Paper elevation={0}
                sx={{
                    m: 1,
                    p: 1.5,
                    border: 'solid',
                    borderWidth: 1,
                    borderColor: 'divider',
                    table: { borderSpacing: 0 },
                    thead: {
                        td: {
                            px: 1.5,
                            py: 0.75,
                            border: 'none',
                            // borderBottom: 'solid',
                            // borderWidth: 1,
                            // borderColor: 'divider',
                        }
                    },
                    tbody: {
                        'tr:first-of-type' : { td: { paddingTop: 1.5 } },
                        'tr:last-of-type' : { td: { paddingBottom: 1.5 } },
                        tr: {
                            'td:first-of-type' : { td: { paddingLeft: 1.5 } },
                            'td:last-of-type' : { td: { paddingRight: 1.5 } },
                            td: {
                                paddingLeft: '12px',
                                paddingRight: '7px',
                                paddingBottom: '10px'
                            }
                        }
                    }
                }}>
                <table>
                    <thead>
                        <tr>
                            <td colSpan={1}>
                                <div
                                style={{
                                    width: 10,
                                    height: 2,
                                    backgroundColor: tooltip.color
                                }}/>
                            </td>
                            <td>
                                <Typography fontWeight={600}>{tooltip.formattedValue}{` ${tooltip.value?.unit}`}</Typography>
                            </td>
                            <td/>
                            <td/>
                            <td/>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colSpan={5}>
                                <Typography>
                                    {tooltip.value.x.format('DD-MM-YYYY')}
                                </Typography>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </Paper>
        </Popper>
    )
}

export default function ChartWell({data, columns}) {
    const [selectedValue, setSelectedValue] = useState(null)

    const chartData = useMemo(() => {
        const data_ = data.map(row => {
            const currentAccessorKey = selectedValue?.value
            const filteredColumns = columns.filter(col => col.accessorKey === currentAccessorKey)
            return {
                x: row.date,
                y: String(currentAccessorKey).startsWith('geology') 
                   ? row['geology'][String(currentAccessorKey).split('.')[1]] 
                   : row[currentAccessorKey],
                well: row.well,
                unit: filteredColumns.length > 0 && filteredColumns[0]?.unit ? filteredColumns[0].unit : '' 
            }
        })
        return data_
    }, [data, selectedValue])

    const chartRef = useRef(null);
    
    const handleChangeSelector = (e) => {
        const value = e.target.value
        const label = columns.find(col => col.accessorKey === value,).header
        setSelectedValue({
            value: value,
            label: label,
        })
    }

    return (
        <Grid container spacing={3} width="100%" mb={3}>
            <Grid item size={12}>
                <Typography variant="h5">Инфографика скважины</Typography>
            </Grid>
            <Grid item size={6}>
                <FormControl
                    fullWidth
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            '&.Mui-focused fieldset': {
                                borderColor: rosneftBtnTheme.palette.orange.main,
                            }},
                        '& .MuiFormLabel-root': {
                            top: '-7px',
                            '&.Mui-focused': {
                                color: rosneftBtnTheme.palette.orange.main,
                                transform: 'translate(15px, -3px) scale(0.75)',
                            }},
                    }}
                >
                    <InputLabel>Показатель</InputLabel>
                    <Select
                        value={selectedValue?.value}
                        label="Показатель"
                        onChange={(e) => handleChangeSelector(e)}
                        size='small'
                        MenuProps={{
                            PaperProps: {
                                style: {
                                    maxHeight: '200px',
                                }
                            }
                        }}
                    >
                        {
                            columns
                            .filter(col => !['well', 'mainWell', 'date'].includes(col.accessorKey))
                            .map(col => (
                                <MenuItem key={col.accessorKey} value={col.accessorKey}>
                                    {col.header}
                                </MenuItem> 
                            ))
                        }
                    </Select>
                </FormControl>
            </Grid>
            { chartData && Object.keys(chartData).length > 0 
                ?
                <Grid item size={12} height={'400px'} ref={chartRef}>
                    <LineChart
                        dataset={chartData}
                        series={[
                            {
                                dataKey: 'y',
                                color: colors[0],
                                curve: "monotoneX",
                                showMark: false,
                            }
                        ]}
                        xAxis={[{
                            dataKey: 'x',
                            label: 'Дата',
                            scaleType: 'time',
                            valueFormatter: (value) => {
                                return dayjs(value).format('DD-MM-YYYY')
                            },
                            // tickInterval: (date, index) => {
                            //     return dayjs(date).date() === 1;
                            // },
                            height: 90,
                            // tickMaxStep: 26 * 60 * 60 * 1000 * 28 * 1.5 , // месяц в миллисекундах

                            tickLabelStyle: {
                                angle: 45,
                            }
                        }]}
                        yAxis={[{
                            label: selectedValue?.label,
                        }]}
                        slots={{
                            tooltip: (props) => <CustomItemTooltip {...props} chartRef={chartRef}/>,
                        }}
                        slotProps={{
                            tooltip: {
                              trigger: 'item',
                            //   anchor: 'pointer',
                          },
                        }}
                        grid={{vertical: true, horizontal: true}}
                    />
                </Grid>
            : null}
        </Grid>
    )
}
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
    Box, Button, IconButton,
    Paper,
    Rating,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Tooltip
} from "@mui/material";
import Grid from '@mui/material/Grid';
import { PieChart } from '@mui/x-charts/PieChart';
import dayjs from "dayjs";

import './AccordionModelInfo.css'
import {pieArcLabelClasses} from "@mui/x-charts";
import {rosneftBtnTheme} from "./themes.jsx";
import {ThemeProvider} from "@mui/material/styles";
import ChartROCAUC from "./ChartROCAUC.jsx";
import ChartConfusionMatrix from './ChartConfusionMatrix.jsx';

const data = [
    {
        version: "v1",
        date: dayjs('01-05-2025', 'DD-MM-YYYY'),
        accuracy: 0.8,
        rate: 4.5,
        volumeTrain: 210,
        isWork: false,
    },
    {
        version: "v2",
        date: dayjs('01-02-2025', 'DD-MM-YYYY'),
        accuracy: 0.85,
        rate: 4,
        volumeTrain: 450,
        isWork: true,
    },
];

const DiffComponent = ({ value, text='с пред. версии' }) => {
    if (value > 0) {
        const icon =
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                 aria-hidden="true" role="img"
                 className="diff-icon-success iconify iconify--solar minimal__iconify__root" width="1em"
                 height="1em" viewBox="0 0 24 24">
                <path fill="currentColor"
                      d="M5 17.75a.75.75 0 0 1-.488-1.32l7-6a.75.75 0 0 1 .976 0l7 6A.75.75 0 0 1 19 17.75z"
                      opacity="0.4"></path>
                <path fill="currentColor" fillRule="evenodd"
                      d="M4.43 13.488a.75.75 0 0 0 1.058.081L12 7.988l6.512 5.581a.75.75 0 1 0 .976-1.138l-7-6a.75.75 0 0 0-.976 0l-7 6a.75.75 0 0 0-.081 1.057"
                      clipRule="evenodd"></path>
            </svg>
        return (
            <>
                {icon}
                <span className='value'> +{ value.toFixed(2) }</span>
                <span className='text'> {text}</span>
            </>
        )
    } else if (value < 0) {
        const icon =
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true"
                 role="img" className="diff-icon-unsuccess iconify iconify--solar minimal__iconify__root" width="1em"
                 height="1em" viewBox="0 0 24 24">
                <path fill="currentColor"
                      d="M5 6.25a.75.75 0 0 0-.488 1.32l7 6c.28.24.695.24.976 0l7-6A.75.75 0 0 0 19 6.25z"
                      opacity="0.4"></path>
                <path fill="currentColor" fillRule="evenodd"
                      d="M4.43 10.512a.75.75 0 0 1 1.058-.081L12 16.012l6.512-5.581a.75.75 0 1 1 .976 1.139l-7 6a.75.75 0 0 1-.976 0l-7-6a.75.75 0 0 1-.081-1.058"
                      clipRule="evenodd"></path>
            </svg>
        return (
            <>
                {icon}
                <span className='value'>{value.toFixed(2)}</span>
                <span className='text'>{text}</span>
            </>
        )
    } else return null

}

export default function AccordionModelInfo() {
    return (
        <div className='accordion-model-info'>
            <Accordion>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon/>}
                    aria-controls="panel-model-current"
                    id="panel-model-current-header"
                >
                    <Typography component="span">Текущая модель прогноза</Typography>
                </AccordionSummary>
                <AccordionDetails sx={{padding: '50px 200px', backgroundColor: '#efefef'}}>
                    <Grid container spacing={2}>
                    <Grid size={3}>
                          <Paper className="model-info-card" elevation={4}>
                              <Box>
                                  <div className="model-info-card-title">Название версии</div>
                                  <div className="model-info-card-value">{data[1].version}</div>
                              </Box>
                          </Paper>
                      </Grid>
                      <Grid size={3}>
                        <Paper className="model-info-card" elevation={4}>
                            <Box>
                                <div className="model-info-card-title">Дата обновления</div>
                                <div className="model-info-card-value">{data[1].date.format('DD-MM-YYYY')}</div>
                            </Box>
                        </Paper>
                      </Grid>
                      <Grid size={3}>
                        <Paper className="model-info-card" elevation={4}>
                            <Box>
                                <div className="model-info-card-title">Точность прогноза</div>
                                <div className="model-info-card-value">{data[1].accuracy}</div>
                                <div className="model-info-card-diff">
                                    <DiffComponent value={data[1].accuracy - data[0].accuracy}/>
                                </div>
                            </Box>
                        </Paper>
                      </Grid>
                      <Grid size={3}>
                        <Paper className="model-info-card" elevation={4}>
                            <Box>
                                <div className="model-info-card-title">Оценка экспертов</div>
                                <div className="model-info-card-value">
                                    <Rating readOnly name="half-rating" defaultValue={0} value={data[1].rate}/>
                                </div>
                                <div className="model-info-card-diff">
                                    <DiffComponent value={data[1].rate - data[0].rate}/>
                                </div>
                            </Box>
                        </Paper>
                      </Grid>
                      <Grid size={3}>
                        <Paper className="model-info-card" elevation={4}>
                            <Box>
                                <div className="model-info-card-title">Объем данных для обучения</div>
                                <div className="model-info-card-value">{data[1].volumeTrain}</div>
                                <div className="model-info-card-diff">
                                    <DiffComponent value={data[1].volumeTrain - data[0].volumeTrain}/>
                                </div>
                            </Box>
                        </Paper>
                      </Grid>
                      <Grid size={4}>
                        <Paper className="model-info-card" elevation={4}>
                            <Box>
                                <div className="model-info-card-title">Распределение ГТМ</div>
                                <div className="model-info-card-value">
                                    <PieChart
                                        series={[
                                          {
                                            paddingAngle: 5,
                                            innerRadius: '60%',
                                            outerRadius: '90%',
                                            data: [
                                              { value: 80, label: 'ОПЗ' },
                                              { value: 120, label: 'ИДН' },
                                              { value: 200, label: 'ЛНЭК' },
                                            ],
                                            arcLabel: 'value'
                                          },
                                        ]}
                                        sx={{
                                            [`& .${pieArcLabelClasses.root}`]: {
                                              fill: 'white',
                                              fontSize: 14,
                                            },
                                        }}
                                        height={200}
                                        width={200}
                                    />
                                </div>
                            </Box>
                        </Paper>
                      </Grid>
                      <Grid size={5}>
                        <Paper className="model-info-card" elevation={4}>
                            <Box>
                                <div className="model-info-card-title">Confusion-матрица</div>
                                <div className="model-info-card-value">
                                    <ChartConfusionMatrix/>
                                </div>
                            </Box>
                        </Paper>
                      </Grid>
                      <Grid size={5}>
                        <Paper className="model-info-card" elevation={4}>
                            <Box>
                                <div className="model-info-card-title">ROC-кривая</div>
                                <div className="model-info-card-value">
                                    <ChartROCAUC/>
                                </div>
                            </Box>
                        </Paper>
                      </Grid>
                    </Grid>
                </AccordionDetails>
            </Accordion>
            <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel-models-info"
                  id="panel-models-info-header"
                >
                  <Typography component="span">Версии модели</Typography>
                </AccordionSummary>
                <AccordionDetails sx={{backgroundColor: '#efefef'}}>
                  <TableContainer component={Paper}>
                      <Table sx={{ minWidth: 650 }} aria-label="simple table">
                        <TableHead>
                          <TableRow>
                            <TableCell align="center">Название версии</TableCell>
                            <TableCell align="center">Дата</TableCell>
                            <TableCell align="center">Точность</TableCell>
                            <TableCell align="center">Оценка экспертов</TableCell>
                            <TableCell align="center">Объем данных для обучения</TableCell>
                            <TableCell align="center">Действия</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {
                              data.map((row) => {
                                  return (
                                      <TableRow
                                          key={row.version}
                                          sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                      >
                                          <TableCell component="th" scope="row" align="center">
                                            {row.version}
                                          </TableCell>
                                          <TableCell align="center">{row.date.format('DD-MM-YYYY')}</TableCell>
                                          <TableCell align="center">{row.accuracy}</TableCell>
                                          <TableCell align="center">
                                              <Rating readOnly name="half-rating" defaultValue={0} value={row.rate} />
                                          </TableCell>
                                          <TableCell align="center">{row.volumeTrain}</TableCell>
                                          <TableCell
                                              align="center"
                                              sx={{
                                                display: 'flex',
                                                justifyContent: 'center',
                                              }}>
                                                <ThemeProvider theme={rosneftBtnTheme}>
                                                    <Box sx={{display: 'flex', gap: '1rem'}}>
                                                        <Button
                                                            variant="contained"
                                                            color="orange"
                                                            disabled={row.isWork}
                                                        >
                                                            Назначить текущей
                                                        </Button>
                                                    </Box>
                                                </ThemeProvider>
                                          </TableCell>
                                      </TableRow>
                                  )
                          }
                          )}
                        </TableBody>
                      </Table>
                    </TableContainer>
                </AccordionDetails>
            </Accordion>
        </div>
    )
}

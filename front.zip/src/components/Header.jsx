import './Header.css'
import {Container} from "react-bootstrap";

const Header = () => {
    return (
        <Container fluid id="header" >
            <div className='text'>
                <h1>Инструмент разработки программы ГТМ</h1>
                <h3>Поможет сформировать мероприятие ГТМ для скважины</h3>
            </div>
        </Container>
    )
}

export default Header